import flatpickr from "flatpickr";
import "flatpickr/dist/l10n/ru";
import "flatpickr/dist/l10n/hy";

window.flatpickr                              = flatpickr;
window.flatpickr.l10ns.default.firstDayOfWeek = 1;
switch (document.documentElement.lang) {
    case 'ru':
        window.flatpickrLocale = 'ru';
        break;
    case 'hy':
        window.flatpickrLocale = 'hy';
        break;
    default:
        window.flatpickrLocale = 'en';
        break;
}
window.initDatePickers                        = (pickers = null) => {
    let options = {};
    pickers     = pickers ? pickers : document.querySelectorAll('input[type="datetime-local"], input[type="date"]');
    pickers.forEach(picker => {
        const type = picker.dataset.type;
        switch (type) {
            case "date":
                options = {
                    enableTime: false,
                    altInput: true,
                    altFormat: "F j",
                    dateFormat: "Y-m-d",
                    minDate: picker.getAttribute('min') ?? false,
                    maxDate: picker.getAttribute('max') ?? false,
                    defaultDate: picker.value ?? null,
                    locale: window.flatpickrLocale,
                };
                break;
            case "time":
                options = {
                    enableTime: true,
                    noCalendar: true,
                    dateFormat: "H:i",
                    altFormat: "H:i",
                    altInput: true,
                    time_24hr: true,
                    minTime: picker.getAttribute('min') ?? false,
                    maxDate: picker.getAttribute('max') ?? false,
                    defaultDate: picker.value ?? null,
                    locale: window.flatpickrLocale,
                };
                break;
            case "daterange+time":
                options = {
                    mode: "range",
                    enableTime: true,
                    time_24hr: true,
                    altInput: true,
                    altFormat: "F j, Y - H:i",
                    dateFormat: "Y-m-d H:i:s",
                    minDate: picker.getAttribute('min') ?? false,
                    maxDate: picker.getAttribute('max') ?? false,
                    defaultDate: picker.value ?? null,
                    locale: window.flatpickrLocale,
                };
                break;
            case "daterange":
                options = {
                    mode: "range",
                    enableTime: false,
                    altInput: true,
                    altFormat: "F j, Y",
                    dateFormat: "Y-m-d",
                    minDate: picker.getAttribute('min') ?? false,
                    maxDate: picker.getAttribute('max') ?? false,
                    defaultDate: picker.value ?? null,
                    locale: window.flatpickrLocale,
                };
                break;
            case "multiple":
                options = {
                    mode: "multiple",
                    enableTime: false,
                    altInput: true,
                    altFormat: "F j, Y",
                    dateFormat: "Y-m-d",
                    minDate: picker.getAttribute('min') ?? false,
                    maxDate: picker.getAttribute('max') ?? false,
                    defaultDate: picker.value ?? null,
                    locale: window.flatpickrLocale,
                };
                break;
            default:
                options = {
                    enableTime: true,
                    time_24hr: true,
                    altInput: true,
                    altFormat: "F j, Y | H:i",
                    dateFormat: "Y-m-d H:i:s",
                    minDate: picker.getAttribute('min') ?? false,
                    maxDate: picker.getAttribute('max') ?? false,
                    defaultDate: picker.value ?? null,
                    locale: window.flatpickrLocale,
                };
                break;
        }
        window.flatpickr(picker, options)
    });
}

document.addEventListener('DOMContentLoaded', () => {
    initDatePickers();
});
