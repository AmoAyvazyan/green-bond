String.prototype.slugify = function (separator = "-") {
    return this
        .toString()
        .normalize('NFD')                   // split an accented letter in the base letter and the acent
        .replace(/[\u0300-\u036f]/g, '')   // remove all previously split accents
        .toLowerCase()
        .trim()
        .replace(/[^a-z0-9 ]/g, '')   // remove all chars not letters, numbers and spaces (to be replaced)
        .replace(/\s+/g, separator);
};

document.addEventListener('DOMContentLoaded', function () {
    //**************** RESPONSIVE SIDEBAR FUNCTIONALITY START ********************************//
    document.getElementById('hamburger').addEventListener('click',function () {
       this.querySelectorAll('svg path').forEach(el=> {
           el.classList.toggle('inline-flex');
           el.classList.toggle('hidden');
       });
       document.querySelector('aside').classList.toggle('left-0');
       document.querySelector('aside').classList.toggle('-left-56');
    });
    //**************** RESPONSIVE SIDEBAR FUNCTIONALITY END ********************************//
//**************** SLUG FIELD FUNCTIONALITY START ********************************//
    let titleField = document.querySelector('input#title');
    titleField = titleField || document.querySelector('input#name') || document.querySelector('input#label');
    if (titleField && titleField.dataset.lang === 'en') {
        let slugField = document.querySelector('input#slug');
        if (slugField.dataset.new === 'true') {
            titleField.addEventListener('keyup', function (event) {
                let title       = event.target.value;
                slugField.value = title.slugify();
            });
        }
    }
    //**************** SLUG FIELD FUNCTIONALITY END   ********************************//
});
