import Splide from '@splidejs/splide';
import '@splidejs/splide/css';

window.Splide = Splide;

document.addEventListener('DOMContentLoaded', function () {
    const sliders     = document.querySelectorAll('.splide');
    const jobsSliders = document.querySelectorAll('.jobs-slider');

    if (sliders) {
        sliders.forEach(slider => new Splide(`#${slider.getAttribute('id')}`).mount());
    }

    if (jobsSliders) {
        jobsSliders.forEach(jobsSlider => {
            new Splide(jobsSlider, {
                fixedWidth: '41%',
                fixedHeight: '20rem',
                gap: '1rem',
                type: 'loop',
                pagination: false,
                breakpoints: {
                    1919: {
                        fixedWidth: '55%',
                    },
                    1023: {
                        fixedWidth: '100%',
                    },
                    767: {
                        fixedWidth: '100%',
                        fixedHeight: '30rem',
                    },
                },
            }).mount();
        });
    }
});