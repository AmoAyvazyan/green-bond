<x-pdft-layout>
    <div class="bg-white grid mx-auto rounded-2xl text-black px-4 text-xs md:text-sm">
        <h1 class="text-lg py-4 font-bold">{{$request->loan_type === \App\Models\LoanRequest::LOAN_TYPE_RENOVATION
                                                ? __('loan.title_renovation')
                                                : __('loan.title_construction') }}
            {{$request->status === \App\Models\LoanRequest::STATUS_DRAFT
                ? '('.__('loan.draft_report') . ')'
                : ''}}</h1>
        @switch($request->type)
            @case(\App\Models\LoanRequest::TYPE_GREEN)
                <div class="flex lg:-mx-4 p-3 bg-green-500 font-bold text-light items-center justify-center">
                    {{__('phrases.loan_type_green')}} {{__('loan.loan')}}
                </div>
            @break
            @case(\App\Models\LoanRequest::TYPE_EE)
                <div class="flex lg:-mx-4 p-3 bg-green-400 font-bold text-light items-center justify-center">
                    {{__('phrases.loan_type_ee')}} {{__('loan.loan')}}
                </div>
            @break
            @case(\App\Models\LoanRequest::TYPE_STANDARD)
                <div class="flex lg:-mx-4 p-3 bg-green-300 font-bold text-black items-center justify-center">
                    {{__('phrases.loan_type_standard')}} {{__('loan.loan')}}
                </div>
            @break
            @default
                <div class="flex lg:-mx-4 p-3 bg-yellow-500 font-bold text-light items-center justify-center">
                    {{__('phrases.loan_type_non_standard')}} {{__('loan.loan')}}
                </div>
            @break
        @endswitch
        <div class="text-xs italic text-gray-500 -mx-4 p-4">
            {{__('loan.notice')}}
        </div>
        <h2 class="font-bold py-4 text-lg">
            {{__('loan.info_title')}}
        </h2>
        <div class="grid grid-cols-2 gap-8 py-4 border-b border-gray-200">
            <span>{{__('loan.request_id')}}</span>
            <span class="text-right">{{$request->code}}</span>
        </div>
        <div class="grid grid-cols-2 gap-8 py-4 border-b border-gray-200">
            <span>{{__('loan.loaner')}}</span>
            <span class="text-right">{{$loaner_first_name}} {{$loaner_last_name}}</span>
        </div>
        <div class="grid grid-cols-2 gap-8 py-4 border-b border-gray-200">
            <span>{{__('phrases.property_type')}}</span>
            <span class="text-right">{{__('phrases.property_type_'.$request->property_type)}}</span>
        </div>
        <div class="grid grid-cols-2 gap-8 py-4 border-b border-gray-200">
            <span>{{__('loan.location')}}</span>
            <span class="text-right">{{$request->community ? $request->community->name . ', ' : ''}}
                {{$request->region->name}}</span>
        </div>
        <div class="grid grid-cols-2 gap-8 py-4 border-b border-gray-200">
            <span>{{__('loan.address')}}</span>
            <span class="text-right">{{$request->address}}</span>
        </div>
        <div class="grid grid-cols-2 gap-8 py-4 border-b border-gray-200">
            <span>{{__('loan.area')}} ({{__('phrases.sqm')}})</span>
            <span class="text-right">{{$request->area}}</span>
        </div>
        <h2 class="font-bold py-4 text-lg">
            {{__('loan.ee_measures')}}
        </h2>
        @php( $eeImprovementsTotalAmount = 0 )
        @php( $householdAppliancesTotalAmount = 0 )
        @php( $householdAppliances = \App\Models\EeImprovement::whereSlug(\App\Models\EeImprovement::SLUG_HOUSEHOLD_APPLIANCES)->first()->children->pluck('id') )
        <table class="w-full">
            <thead class="bg-gray-50 text-left">
                <tr>
                    <th scope="col" class="px-1 md:px-6 py-3 overflow-hidden max-w-20 lg:max-w-full break-words"></th>
                    <th scope="col" class="px-1 md:px-6 py-3 overflow-hidden max-w-20 lg:max-w-full break-words"> {{__('phrases.quantity')}}
                        ({{__('phrases.pcs')}})
                    </th>
                    <th scope="col" class="px-1 md:px-6 py-3 overflow-hidden max-w-20 lg:max-w-full break-words"> {{__('phrases.area')}} ({{__('phrases.sqm')}}
                        )
                    </th>
                    <th scope="col" class="px-1 md:px-6 py-3 overflow-hidden max-w-20 lg:max-w-full break-words"> {{__('phrases.thickness')}}
                        ({{__('phrases.cm')}})
                    </th>
                    <th scope="col" class="px-1 md:px-6 py-3 overflow-hidden max-w-20 lg:max-w-full break-words"> {{__('phrases.material')}} </th>
                    <th scope="col" class="px-1 md:px-6 py-3 overflow-hidden max-w-20 lg:max-w-full break-words"> {{__('phrases.power')}} </th>
                    <th scope="col" class="px-1 md:px-6 py-3 overflow-hidden max-w-20 lg:max-w-full break-words"> {{__('phrases.co2_reduction')}} </th>
                    <th scope="col" class="px-1 md:px-6 py-3 overflow-hidden max-w-20 lg:max-w-full break-words"> {{__('phrases.energy_savings')}} </th>
                    <th scope="col" class="px-1 md:px-6 py-3 overflow-hidden max-w-20 lg:max-w-full break-words"> {{__('phrases.price_one')}}
                        ({{__('phrases.amd')}})
                    </th>
                    <th scope="col" class="px-1 md:px-6 py-3 overflow-hidden max-w-20 lg:max-w-full break-words"> {{__('phrases.total_price')}}
                        ({{__('phrases.amd')}})
                    </th>
                </tr>
            </thead>
            <tbody>
            @foreach($request->eeImprovements as $improvement)
                @php($data = json_decode($improvement->pivot->data, true))
                @if($householdAppliances->contains($improvement->id))
                    @php($householdAppliancesTotalAmount += (int) $data['quantity'] * (int) $data['price'])
                @endif
                <tr class="bg-white border-b border-gray-200">
                    <th scope="row" class="px-2 py-4 font-medium text-left"> {{$improvement->name}} </th>
                    <td class="px-2 md:px-6 py-4">
                        @if($improvement->has_quantity)
                            {{$data['quantity']}}
                        @endif
                    </td>
                    <td class="px-2 md:px-6 py-4">
                        @if($improvement->has_area)
                            {{$data['area']}}
                        @endif
                    </td>
                    <td class="px-2 md:px-6 py-4">
                        @if($improvement->has_thickness)
                            {{$data['thickness']}}
                        @endif
                    </td>
                    <td class="px-2 md:px-6 py-4">
                        @if($improvement->materials->isNotEmpty())
                            {{$improvement->materials->find($data['material'])?->name}}
                        @endif
                    </td>
                    <td class="px-2 md:px-6 py-4">
                        @if($improvement->has_power)
                            {{$data['power']}}
                            ({{$improvement->slug === \App\Models\EeImprovement::SLUG_LIGHTING ? __('phrases.Wt') :__('phrases.kWt')}})
                        @endif
                    </td>
                    <td class="px-2 md:px-6 py-4">
                        @if($data['savings'])
                            {{$data['savings']['co2']}}
                        @endif
                    </td>
                    <td class="px-2 md:px-6 py-4">
                        @if($data['savings'])
                            {{number_format($data['savings']['energy'], 0, '.', ' ')}}
                        @endif
                    </td>
                    <td class="px-2 md:px-6 py-4">
                        @if($improvement->has_price)
                            {{number_format($data['price'], 0, '.', ' ')}}
                        @endif
                    </td>
                    <td class="px-2 md:px-6 py-4">
                        {{number_format((float) (($data['quantity'] ?: $data['area']) ?: 1) * (int) $data['price'], 0, '.', ' ')}}
                    </td>
                </tr>
                @php($eeImprovementsTotalAmount += (($data['quantity'] ?: $data['area']) ?: 1) * (int) $data['price'])
            @endforeach
            </tbody>
        </table>
        @php( $improvementsTotalAmount = 0 )
        @if($request->improvements->isNotEmpty())
            <h2 class="font-bold py-4 text-lg">
                {{__('loan.non_ee_measures')}}
            </h2>
            <table class="w-full">
                <thead class="bg-gray-50 text-left">
                    <tr>
                        <th scope="col" class="px-1 md:px-6 py-3"></th>
                        <th scope="col" class="px-1 md:px-6 py-3"> {{__('phrases.quantity')}}</th>
                        <th scope="col" class="px-1 md:px-6 py-3"> {{__('phrases.price_one')}} ({{__('phrases.amd')}})</th>
                        <th scope="col" class="px-1 md:px-6 py-3"> {{__('phrases.total_price')}} ({{__('phrases.amd')}})</th>
                        <th scope="col" class="px-1 md:px-6 py-3"> {{__('phrases.labor_cost')}} ({{__('phrases.amd')}})</th>
                    </tr>
                </thead>
                <tbody>
                @foreach($request->improvements as $improvement)
                    @php($data = json_decode($improvement->pivot->data, true))
                    <tr class="bg-white border-b border-gray-200">
                        <th scope="row" class="px-2 py-4 font-medium text-left"> {{$improvement->name}} </th>
                        @if($improvement->is_countable)
                            <td class="px-2 md:px-6 py-4"> {{$data['quantity']}} ({{$improvement->unit}})</td>
                            <td class="px-2 md:px-6 py-4"> {{$data['price']}} </td>
                            <td class="px-2 md:px-6 py-4"> {{(int) $data['quantity'] * (int) $data['price']}} </td>
                            <td class="px-2 md:px-6 py-4"></td>
                            @php($improvementsTotalAmount += ((int) $data['quantity'] * (int) $data['price']))
                        @elseif(isset($data['total']))
                            <td class="px-2 md:px-6 py-4"></td>
                            <td class="px-2 md:px-6 py-4"></td>
                            <td class="px-2 md:px-6 py-4"> {{number_format($data['total'], 0,'.', ' ')}} </td>
                            <td class="px-2 md:px-6 py-4"></td>
                            @php($improvementsTotalAmount += (float) str_replace(' ','',$data['total']))
                        @endif
                        @if($improvement->include_works)
                            <td class="px-2 md:px-6 py-4"></td>
                            <td class="px-2 md:px-6 py-4"></td>
                            <td class="px-2 md:px-6 py-4"></td>
                            <td class="px-2 md:px-6 py-4"> {{number_format($data['labor_cost'], 0,'.', ' ')}} </td>
                            @php($improvementsTotalAmount += $data['labor_cost'])
                        @endif
                    </tr>
                @endforeach
                </tbody>
            </table>
        @endif
        @php( $customMeasuresTotalAmount = 0 )
        @if($request->custom_measures)
            <h2 class="font-bold py-4 text-lg">
                {{__('loan.custom_measures')}}
            </h2>
            <table class="w-full">
                <tbody>
                @foreach($request->custom_measures as $data)
                    <tr class="bg-white border-b border-gray-200">
                        <th scope="row" class="px-2 py-4 font-medium text-left">
                            {{$data['name']}} ({{__('phrases.amd')}})
                        </th>
                        <td class="px-2 md:px-6 py-4"> {{number_format($data['price'],0,'.',' ')}} </td>
                    </tr>
                    @php($customMeasuresTotalAmount += (int) $data['price'])
                @endforeach
                </tbody>
            </table>
        @endif
        <h2 class="font-bold py-4 text-lg">
            {{__('loan.summary_title')}}
        </h2>
        <div class="grid grid-cols-3 gap-8 py-4 border-b border-gray-200">
            <span class="col-span-2">{{__('loan.energy_label')}}</span>
            <div class="grid grid-cols-2 gap-8">
                <span class="text-right">{{ round(($eeImprovementsTotalAmount / $request->total_amount) * 100) }} %</span>
                <span class="text-right">{{ number_format($eeImprovementsTotalAmount,0,'.',' ') }} {{ __('phrases.amd') }}</span>
            </div>
        </div>
        <div class="grid grid-cols-3 gap-8 py-4 pl-4 border-b border-gray-200">
            <span class="col-span-2 italic">{{__('loan.household_label')}}</span>
            <div class="grid grid-cols-2 gap-8">
                <span class="text-right">{{ round(($householdAppliancesTotalAmount / $request->total_amount) * 100) }} %</span>
                <span class="text-right">{{ number_format($householdAppliancesTotalAmount,0,'.',' ') }} {{ __('phrases.amd') }}</span>
            </div>
        </div>
        <div class="grid grid-cols-3 gap-8 py-4 border-b border-gray-200">
            <span class="col-span-2">{{__('loan.not_energy_label')}}</span>
            <div class="grid grid-cols-2 gap-8">
                <span class="text-right">{{ round(($improvementsTotalAmount / $request->total_amount) * 100) }} %</span>
                <span class="text-right">{{ number_format($improvementsTotalAmount,0,'.',' ') }} {{ __('phrases.amd') }}</span>
            </div>
        </div>
        <div class="grid grid-cols-3 gap-8 py-4 border-b border-gray-200">
            <span class="col-span-2">{{__('loan.other_measures_label')}}</span>
            <div class="grid grid-cols-2 gap-8">
                <span class="text-right">
                    {{ 100 - round(($improvementsTotalAmount / $request->total_amount) * 100)
                           - round(($eeImprovementsTotalAmount / $request->total_amount) * 100) }} %</span>
                <span class="text-right">{{ number_format($customMeasuresTotalAmount,0,'.',' ') }} {{ __('phrases.amd') }}</span>
            </div>
        </div>
        <div class="grid grid-cols-3 gap-8 py-4 items-center">
            <span class="col-span-2"> {{__('phrases.total_calculation')}} </span>
            <span class="text-right">{{ number_format($request->total_amount,0,'.',' ') }} {{ __('phrases.amd') }}</span>
        </div>
        <h2 class="font-bold py-4 text-lg">
            {{__('loan.ee_title')}}
        </h2>
        <div class="grid grid-cols-3 gap-8 py-4 border-b border-gray-200">
            <span class="col-span-2">{{__('loan.co2_label')}}</span>
            <span class="text-right">{{$request->co2_reduction}}</span>
        </div>
        <div class="grid grid-cols-3 gap-8 py-4 border-b border-gray-200">
            <span class="col-span-2">{{__('loan.ee_label')}}</span>
            <span class="text-right">{{number_format($request->energy_savings, 0, '.', ' ')}}</span>
        </div>
    </div>
    @if($print ?? false)
        @push('scripts')
            <script !src="">
                document.addEventListener('DOMContentLoaded', function () {
                    window.print();
                });
            </script>
        @endpush
    @endif
</x-pdft-layout>
