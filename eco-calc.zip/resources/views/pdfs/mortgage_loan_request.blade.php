<x-pdft-layout>
    <div class="bg-white grid mx-auto rounded-2xl text-black px-4 text-sm">
        <h1 class="text-lg py-4 font-bold">{{__('loan.title_mortgage')}}</h1>
        <div class="flex -mx-4 p-3 bg-green-500 font-bold text-light items-center justify-center">
            {{__('loan.green_type')}}
        </div>
        <div class="text-xs italic text-gray-500 -mx-4 p-3">
            {{__('loan.notice')}}
        </div>
        <div class="flex p-4 bg-yellow-500 text-light items-center justify-center -mx-4 text-xs">
            {{__('phrases.mortgage_notice_error')}}
        </div>
        <h2 class="font-bold py-4">
            {{__('loan.info_title')}}
        </h2>
        <div class="grid grid-cols-2 gap-8 py-4 border-b border-gray-200">
            <span>{{__('loan.request_id')}}</span>
            <span class="text-right">{{$request->code}}</span>
        </div>
        <div class="grid grid-cols-2 gap-8 py-4 border-b border-gray-200">
            <span>{{__('loan.loaner')}}</span>
            <span class="text-right">{{$loaner_first_name}} {{$loaner_last_name}}</span>
        </div>
        <div class="grid grid-cols-2 gap-8 py-4 border-b border-gray-200">
            <span>{{__('loan.green_location')}}</span>
            <span class="text-right">
                {{$request->building->complex->community ? $request->building->complex->community->name . ', ' : ''}}
                {{$request->building->complex->region->name}}
            </span>
        </div>
        <div class="grid grid-cols-2 gap-8 py-4 border-b border-gray-200">
            <span>{{__('loan.green_address')}}</span>
            <span
                class="text-right text-xs">{{$request->building->complex->address}}, {{__('phrases.complex_building')}}{{__('phrases.colon')}} {{$request->building->title}}, {{__('loan.apartment_label')}} - {{$request->apartment_number}}</span>
        </div>
        <div class="grid grid-cols-2 gap-8 py-4 border-b border-gray-200">
            <span>{{__('loan.green_area')}} ({{__('phrases.sqm')}})</span>
            <span class="text-right">{{$request->area}}</span>
        </div>
        <h2 class="font-bold py-4">
            {{__('loan.ee_title')}}
        </h2>
        <div class="grid grid-cols-3 gap-8 py-4 border-b border-gray-200">
            <span class="whitespace-nowrap col-span-2">{{__('loan.co2_label')}}</span>
            <span class="text-right">{{$request->co2_reduction}}</span>
        </div>
        <div class="grid grid-cols-3 gap-8 py-4">
            <span class="whitespace-nowrap col-span-2">{{__('loan.ee_label')}}</span>
            <span class="text-right">{{$request->energy_savings}}</span>
        </div>
    </div>
    @if($print ?? false)
        @push('scripts')
            <script !src="">
                document.addEventListener('DOMContentLoaded', function () {
                    window.print();
                });
            </script>
        @endpush
    @endif
</x-pdft-layout>
