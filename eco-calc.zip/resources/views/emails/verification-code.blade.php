@component('mail::message')
# {{ __('emails.hello') }}

{{ __('emails.verification_code') }}{{ __('phrases.colon') }}
## {{ $code }}

{{ __('emails.thanks_from') }},<br>
{{ config('app.name') }}
@endcomponent
