<div {!! $attributes->only('class') !!}>
    <label for="phone_base_{!! $attributes['id'] !!}" class="hidden">{{__('terms.phone_number')}}</label>
    <span wire:ignore>
        <input id="phone_base_{!! $attributes['id'] !!}" type="tel" name="phone_base"
               {!! $attributes->only(['placeholder','required']) !!}
               data-target="{!! $attributes['id'] !!}" autocomplete="off"
               {!! $attributes->merge(['class'=>'block mt-1 w-full rounded-xl px-3 py-3 h-12 border-gray-500
                                                 focus:border-gray-500 placeholder:text-gray-50 bg-white
                                                 focus-visible:outline-none focus:ring focus:ring-gray-200
                                                 focus:ring-opacity-50 disabled:cursor-not-allowed disabled:opacity-75'])
                                                 ->only('class') !!}
               @if ($attributes->has('value'))
                   value="{{ $attributes['value'] ?? old($attributes['name']) }}"
               @endif
        >
    </span>
    <input type="hidden" {!! $attributes->except(['class','placeholder','required']) !!}>
</div>