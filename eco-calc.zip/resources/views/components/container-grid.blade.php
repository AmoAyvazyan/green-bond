<div {!! $attributes->merge(['class'=>'container px-5 lg:px-8 hd:px-16 fhd:px-32 mx-auto grid grid-cols-1 lg:grid-cols-9 gap-6']) !!}>
    {{ $slot }}
</div>
