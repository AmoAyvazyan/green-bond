<span {{ $attributes->merge(['class' => "text-3xl font-bold block font-display text-black leading-tight"])}}>{{ $slot }}</span>
