@props(['active' => false])
@php
    $classes = $active
                ? 'flex items-center lg:pr-8 pl-4 pr-4 py-2 font-semibold bg-yellow-500 text-gray-900 rounded-l-md border-b-4 lg:border-b-0 lg:border-r-4 border-yellow-500 focus:outline-none transition duration-150 ease-in-out'
                : 'flex items-center lg:pr-8 pl-4 pr-4 py-2 font-semibold text-green-500 hover:text-yellow-500 focus:outline-none transition duration-150 ease-in-out cursor-pointer';
@endphp
<a {{ $attributes->merge(['class' => $classes]) }}>
    {{ $slot }}
</a>
