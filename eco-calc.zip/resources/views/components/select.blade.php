@props(['disabled' => false])
<select {{ $disabled ? 'disabled' : '' }} {!! $attributes->merge(['class' => 'rounded-2xl border-transparent focus:border-green-500 bg-white pl-4 h-13 placeholder:text-gray-50 focus-visible:outline-none focus:ring focus:ring-green-200 focus:ring-opacity-50 shadow-md']) !!}>{{$slot}}</select>
