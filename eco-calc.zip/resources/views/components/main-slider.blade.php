<div id="mainSlider" class="splide main-slider relative" data-splide='@json($options)'>
    <div class="splide__track h-full rounded-3xl">
        <ul class="splide__list relative">
            @foreach($slides as $slide)
                @if($slide->is_active)
                    <li class="splide__slide rounded-3xl">
                        @if($slide->url && !$slide->btn_text)
                            <a data-bg="{{$slide->image}}" data-mobile-bg="{{$slide->mobile_image}}"
                               href="{{LaravelLocalization::localizeURL($slide->url)}}"
                               aria-label="{{$slide->heading ?? __('metas.general')}}"
                               class="lazyload w-full h-full main-slider-slide cursor-pointer
                                      {{ $getSlideBgAlignmentClass($slide) }} bg-cover rounded-3xl
                                      bg-no-repeat flex p-6
                                      {{ $getSlidePositionClass($slide) }}
                                      {{ $getSlideVerticalPositionClass($slide) }}">
                               <div class="w-2/3 sm:w-1/2 pb-12.5 {{ $getSlideAlignmentClass($slide) }}">
                                   @if($slide->heading)
                                       <h2 class="text-2xl lg:text-3xl hd:text-4xl text-green-500 font-extrabold uppercase">
                                           {{$slide->heading}}
                                       </h2>
                                   @endif
                               </div>
                            </a>
                        @else
                            <div data-bg="{{$slide->image}}" data-mobile-bg="{{$slide->mobile_image}}"
                                 class="lazyload w-full h-full main-slider-slide {{ $getSlideBgAlignmentClass($slide) }} bg-cover rounded-3xl
                                 bg-no-repeat flex p-6 {{ $getSlidePositionClass($slide) }}">
                                <div class="w-2/3 sm:w-1/2 pb-12.5 {{ $getSlideAlignmentClass($slide) }} {{ $getSlideVerticalPositionClass($slide) }}">
                                    @if($slide->heading)
                                        <h2 class="text-2xl lg:text-3xl hd:text-4xl text-green-500 font-extrabold uppercase">
                                            {{$slide->heading}}
                                        </h2>
                                    @endif
                                    @if($slide->url && $slide->btn_text)
                                        <x-btn color="green" :link="true" size="lg" class="mt-4"
                                               href="{{LaravelLocalization::localizeURL($slide->url)}}"
                                        >{{$slide->btn_text}}</x-btn>
                                    @endif
                                </div>
                            </div>
                        @endif
                    </li>
                @endif
            @endforeach
        </ul>
    </div>
    <div class="absolute bottom-6 left-6 w-full h-12.5 flex space-x-4 items-end">
        <div class="splide__arrows"></div>
        <ul class="splide__pagination"></ul>
    </div>
</div>
<x-slider-assets/>
