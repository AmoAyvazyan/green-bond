@props(['status'])

@if ($status)
    <div {{ $attributes->merge(['class' => 'font-medium text-center text-sm']) }}>
        {{ $status }}
    </div>
@endif
