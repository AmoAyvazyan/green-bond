@props(['active'])

@php
    $commonClasses = ' cursor-pointer inline-flex items-center px-1 py-2 border-b-2 text-sm font-medium leading-5 hover:text-light hover:border-green-500 focus:outline-none focus:text-gray-50 focus:border-green-500 transition duration-150 ease-in-out ';
    $classes = ($active ?? false)
                ? 'border-green-500 text-light'
                : 'border-gray-500 text-gray-500';
@endphp

<a {{ $attributes->merge(['class' => $commonClasses . $classes]) }}>
    {{ $slot }}
</a>
