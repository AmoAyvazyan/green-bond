<a {{ $attributes->merge(['class' => "text-light hover:text-white hover:underline transition duration-150 cursor-pointer"])}}>{{ $slot }}</a>
