<div class="flex items-center {{$attributes['class']}}" {!! $attributes->except(['class', 'checked', 'disabled', 'id','wire:change.prevent']) !!}>
    <input {!! $attributes->except(['class']) !!} type="checkbox"
           class="rounded border border-gray-500 text-green-500 focus:border-green-500 focus:ring focus:ring-green-300
           focus:ring-opacity-50 mr-3 mb-0.5 cursor-pointer">
    <label for="{{$attributes['id']}}" class="block text-gray-500 select-none cursor-pointer">{{$slot??''}}</label>
</div>
