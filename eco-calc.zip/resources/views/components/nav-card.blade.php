<div class="container mx-auto">
    <div class="mx-auto flex justify-between lg:flex-row flex-col">
        <aside class="min-w-[250px] flex flex-col justify-between">
            {{ $navigation }}
        </aside>
        <div
            class="w-full bg-light rounded-md pr-10 py-6 pl-6 md:pl-12 xl:pl-18 overflow-auto min-h-[670px]">
            {{ $content }}
        </div>
    </div>
</div>
