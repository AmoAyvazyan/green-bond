<a {{ $attributes->merge(['class' => "stroke-current inline-flex justify-center items-center hover:opacity-75 transition duration-150 cursor-pointer"])}}>{{ $slot }}</a>
