<div {!! $attributes->merge(['class'=>'container px-4 lg:px-8 hd:px-16 fhd:px-24 mx-auto']) !!}>
    {{ $slot }}
</div>
