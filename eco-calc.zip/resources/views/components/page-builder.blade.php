@props(['disabled' => false])

<textarea
    hidden {{ $disabled ? 'disabled' : '' }} {!! $attributes->merge(['class' => 'rounded-md shadow-sm border-gray-300 focus:border-yellow-300 focus:ring focus:ring-yellow-200 focus:ring-opacity-50 w-full p-3 custom-editor', 'rows'=>3]) !!}>{{$slot}}</textarea>

@push('styles')
    <link rel="stylesheet" href="{{asset('vendor/laraberg/css/laraberg.css')}}">
@endpush
@push('scripts')
    <script defer src="https://unpkg.com/react@16.8.6/umd/react.production.min.js"></script>
    <script defer src="https://unpkg.com/react-dom@16.8.6/umd/react-dom.production.min.js"></script>
    <script defer src="{{ asset('vendor/laraberg/js/laraberg.js') }}"></script>
    <script>
        document.addEventListener('DOMContentLoaded', static function () {
            Laraberg.init('{{$attributes['id'] ?? ''}}', { laravelFilemanager: true });
        })
    </script>
@endpush
