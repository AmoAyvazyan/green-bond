@props(['disabled' => false])

<textarea {{ $disabled ? 'disabled' : '' }} {!! $attributes->merge(['class' => 'rounded-sm shadow-sm border-gray-300 focus:border-yellow-300 focus:ring focus:ring-yellow-200 focus:ring-opacity-50 w-full p-3 custom-editor', 'rows'=>3]) !!}>{{$slot}}</textarea>

@push('scripts')
    <script src="https://cdn.ckeditor.com/4.17.1/standard-all/ckeditor.js"></script>
    <script>
        document.addEventListener('DOMContentLoaded', function () {
            CKEDITOR.replace('{{$attributes['id'] ?? ''}}', {
                language: document.getElementsByTagName('html')[0].getAttribute('lang'),
                uiColor: '#55823B',
            });
            CKEDITOR.instances.content.config.allowedContent = true; //This allows all
        })
    </script>
@endpush
