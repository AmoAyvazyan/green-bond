<h2 {{ $attributes->merge(['class' => "font-mono font-bold text-2xl text-gray-900 mt-20 mb-6 leading-tight"])}}>{{ $slot }}</h2>
