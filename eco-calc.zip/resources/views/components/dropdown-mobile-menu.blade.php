@props(['align' => 'right', 'width' => '48', 'contentClasses' => 'py-0 bg-white'])

@php
    $alignmentClasses = match ($align) {
        'left'  => 'origin-top-left left-0',
        'top'   => 'origin-top',
        default => 'origin-top-right right-0'
    };
    $width = match ($width) {
        'full'  => 'w-full',
        default => 'w-48',
    };
@endphp

<div class="relative" x-data="{ isDropdownMobileOpen: false }" @click.away="isDropdownMobileOpen = false"
     @close.stop="isDropdownMobileOpen = false">
    <div @click="isDropdownMobileOpen = ! isDropdownMobileOpen">
        {{ $trigger }}
    </div>

    <div x-show="isDropdownMobileOpen" x-cloak
         x-transition:enter="transition ease-out duration-300 transform"
         x-transition:enter-start="opacity-0 scale-95 translate-x-full"
         x-transition:enter-end="opacity-100 scale-100 translate-x-0"
         x-transition:leave="transition ease-out duration-300 transform"
         x-transition:leave-start="opacity-100 scale-100 translate-x-0"
         x-transition:leave-end="opacity-100 scale-100 translate-x-full"
         class="fixed z-[-1] -mt-20 {{ $width }} rounded-lg {{ $alignmentClasses }}"
         >
        <div
            class="relative shadow-xl {{ $contentClasses }} h-full bg-black flex flex-col items-center pt-44 pb-20">
            {{ $content }}
        </div>
    </div>
</div>