@props(['disabled' => false, 'value', 'placeholder', 'limit' => 0])
<div class="file-input rounded-2xl flex items-center h-13 border-transparent focus:border-green-500 placeholder:text-gray-50 bg-white focus-visible:outline-none focus:ring focus:ring-green-200 focus:ring-opacity-50 disabled:cursor-not-allowed disabled:opacity-75 shadow-md  {{$attributes['class']}}">
    <label for="{{$attributes['id']}}"
           class="rounded-xl inline-flex cursor-pointer transition duration-150 ease-in file-trigger w-full
                 {{ $disabled ? 'disabled' : '' }}">
        <span
            class="inline-flex text-light bg-gray-500 items-center whitespace-nowrap py-3 h-13 px-3 rounded-l-xl">
            <x-heroicon-o-paper-clip class="w-4 h-4 mr-1 inline-block"/>
            {{$value}}
        </span>
        <span
            class="{{$attributes['class']}} filename inline-flex items-center bg-white w-full active:border-gray-300
                   transition duration-150 ease-in py-3 h-12 px-3 text-gray-500 rounded-r-xl overflow-hidden text-ellipsis"
        >{{ $placeholder ?? '' }}</span>
    </label>
    <input {!! $attributes->except(['class']) !!} class="hidden" type="file" data-size-limit="{{$limit * 1024 * 1024}}">
</div>
