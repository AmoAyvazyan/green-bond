<svg {!! $attributes !!} width="24" height="25" viewBox="0 0 24 25" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path d="M18 10.0008L12 16.0009M12 16.0009L6 10.0008M12 16.0009L12 4.00146" stroke="currentColor" stroke-width="2"
          stroke-linecap="round" stroke-linejoin="round"/>
    <path d="M2 16.9702V19.9702C2 21.0748 2.89543 21.9702 4 21.9702H20C21.1046 21.9702 22 21.0748 22 19.9702V16.9702"
          stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
</svg>
