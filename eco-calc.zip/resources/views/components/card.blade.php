<div class="{!! $attributes['class'] !!} lg:mb-6 p-6 bg-white rounded-3xl shadow-md">
    {{$slot}}
</div>
