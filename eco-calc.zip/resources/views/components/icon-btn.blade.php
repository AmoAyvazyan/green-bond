@props(['color'=>'blue'])
<button {{ $attributes->merge(['class' => "stroke-current inline-flex justify-center items-center text-$color-500 hover:opacity-75 transition duration-150 cursor-pointer"])}}>{{ $slot }}</button>
