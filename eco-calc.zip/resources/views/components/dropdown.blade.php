@props(['align' => 'right', 'width' => 'sm', 'contentClasses' => 'py-0 bg-white rounded-xl'])

@php
    $alignmentClasses = match ($align) {
        'left'  => 'origin-top-left left-0',
        'top'   => 'origin-top',
        'center'   => 'origin-top lg:bottom-16 left-1/2 -translate-x-1/2 lg:left-auto lg:right-0 lg:origin-top-left lg:bottom-auto lg:translate-x-0',
        default => 'origin-top-right xs:right-0 -right-full'
    };
    $width = match ($width) {
        'xs'    => 'w-full',
        'full'  => 'w-screen',
        'sm'    => 'w-48',
        'md'    => 'w-screen max-w-[400px]',
        'lg'    => 'w-screen max-w-[300px] md:max-w-[400px] lg:max-w-[475px] !rounded-3xl',
        default => '',
    };
@endphp

<div class="relative" x-data="{ isDropdownOpen: false }" @click.away="isDropdownOpen = false"
     @close.stop="isDropdownOpen = false">
    <div @click="isDropdownOpen = ! isDropdownOpen">
        {{ $trigger }}
    </div>

    <div x-show="isDropdownOpen"
         x-transition:enter="transition ease-out duration-200"
         x-transition:enter-start="opacity-0 scale-95"
         x-transition:enter-end="opacity-100 scale-100"
         x-transition:leave="transition ease-in duration-75"
         x-transition:leave-start="opacity-100 scale-100"
         x-transition:leave-end="opacity-0 scale-95"
         class="absolute z-50 mt-2 shadow-lg rounded-xl {{ $width }} {{ $alignmentClasses }}"
         x-cloak
         @click="isDropdownOpen = false">
        <div
            class="relative {{ $contentClasses }}">
            {{ $content }}
        </div>
    </div>
</div>