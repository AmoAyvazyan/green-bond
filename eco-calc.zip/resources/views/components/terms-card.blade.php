<x-nav-card>
    <x-slot name="navigation">
        @include('partials.terms-navigation')
    </x-slot>
    <x-slot name="content">
        {{ $slot }}
    </x-slot>
</x-nav-card>
