@props(['last'=>false, 'label'=>''])
<div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4">
    <span class="py-2 {{$last?'':'border-b border-gray-200'}} text-gray-700">{{$label}}</span>
    <span class="col-span-3 py-2 {{$last?'':'border-b border-gray-200'}} text-gray-900 font-bold">{{$slot}}</span>
</div>
