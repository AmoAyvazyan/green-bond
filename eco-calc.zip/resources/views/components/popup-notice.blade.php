@props(['hidingHoursCount' => 2, 'name' => 'info'])
@php($camelName = ucfirst(\Illuminate\Support\Str::camel($name)))
<x-modal x-data="showNotice{{$camelName}}"
         x-cloak x-init="checkCookie()">
    <div class="flex flex-col justify-center items-center">
        <div class="notice-text text-red-500 font-bold text-xl mb-11 text-center">{!! $slot !!}</div>
        <x-btn color="green" class="notice-modal-close"
               x-on:click="setCookie({{$hidingHoursCount}})">{{__('buttons.continue')}}</x-btn>
    </div>
</x-modal>
<script>
    function showNotice{{$camelName}}() {
        return {
            isModalOpen: false,
            cookieName: '{{\Illuminate\Support\Str::slug($name)}}-notice-show',
            setCookie(hours = 2) {
                let d = new Date();
                d.setTime(d.getTime() + (hours * 60 * 60 * 1000));
                let expires     = "expires=" + d.toUTCString();
                document.cookie = this.cookieName + "=" + !this.isModalOpen + ";" + expires + ";path=/";

                this.isModalOpen = false;
            },
            getCookie() {
                let matches = document.cookie.match(new RegExp(
                    "(?:^|; )" + this.cookieName.replace(/([\.$?*|{}\(\)\[\]\\/\+^])/g, '\\') + "=([^;]*)"));
                return matches ? decodeURIComponent(matches[1]) : 'true';
            },
            checkCookie() {
                return this.isModalOpen = (this.getCookie() === "true");
            },
        }
    }
</script>
