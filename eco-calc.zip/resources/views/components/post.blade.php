@props(['post' => null])
<div {{ $attributes->merge(['class' => "rounded-3xl bg-light shadow-xl"])}}>
    <a class="block cursor-pointer" href="{{route('front.blog.show', $post)}}">
        <img data-src="{{$post->image_cover ?? $post->image}}" alt="{{$post->title}}"
             class="lazyload block w-full h-60 object-center object-cover rounded-t-3xl bg-light" width="364"
             height="160">
    </a>
    <h2 class="flex item-center p-4 cursor-pointer">
        <a href="{{route('front.blog.show', $post)}}" class="font-bold text-gray-900 text-xl uppercase">{{Str::limit($post->title, 90)}}</a>
    </h2>
    <div class="flex item-center p-4 rounded-b-3xl bg-light">{{ Str::limit(strip_tags($post->content), 155) }}</div>
</div>