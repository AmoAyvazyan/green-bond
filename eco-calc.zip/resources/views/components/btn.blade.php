@if($link)
    <a {!! $attributes->merge(['class' => $class]) !!}>{{$slot}}</a>
@else
    <button {!! $attributes->merge(['class' => $class]) !!}>
        {{ $slot }}
    </button>
@endif
