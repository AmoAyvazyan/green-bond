<div id="combosSlider" class="splide banners-slider" data-splide='@json($options)'>
    <div class="splide__track">
        <ul class="splide__list">
            @foreach($slides as $slide)
                <li class="splide__slide">
                    <x-combo :combo="$slide" class="splide__slide__container"/>
                </li>
            @endforeach
        </ul>
    </div>
</div>
<x-slider-assets/>
