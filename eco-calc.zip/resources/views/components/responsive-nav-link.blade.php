@props(['active' => false, 'mobile' => false, 'light' => false])

@if($mobile)
    @php
        $textColor = $light ? 'text-white' : 'text-gray-900';
        $classes = $active
                    ? 'flex justify-center items-center capitalize px-4 py-2 text-xl ' . $textColor . ' !text-green-500 font-bold focus:outline-none transition duration-150 ease-in-out'
                    : 'flex justify-center items-center capitalize px-4 py-2 text-xl ' . $textColor . ' hover:font-bold focus:outline-none transition duration-150 ease-in-out cursor-pointer';
    @endphp
@else
    @php
        $textColor = $light ? 'text-white !uppercase' : 'text-gray-900';
        $classes = $active
                    ? 'inline-block text-center capitalize pb-0.5 px-0.5 mr-4 text-sm ' . $textColor . ' !text-green-500 font-semibold focus:outline-none transition duration-150 ease-in-out'
                    : 'inline-block text-center capitalize pb-0.5 px-0.5 mr-4 text-sm ' . $textColor . ' font-semibold hover:text-green-500 focus:outline-none transition duration-150 ease-in-out cursor-pointer';
    @endphp
@endif
<a {{ $attributes->merge(['class' => $classes]) }}>
    {{ $slot }}
</a>
