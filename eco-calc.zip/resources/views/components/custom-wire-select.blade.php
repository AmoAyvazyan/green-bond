@props(['disabled' => false])

<select autocomplete="off" aria-autocomplete="none" {{ $disabled ? 'disabled' : '' }}
    {!! $attributes->merge([
            'class' => 'custom-select rounded-xl border border-transparent focus:border-green-500
                        focus:ring bg-white pl-4 h-13 focus-visible:outline-none focus:ring-green-200
                        focus:ring-opacity-50 block w-full shadow-md focus:outline-none wire-select'
        ]) !!}>{{$slot}}</select>
