@props(['disabled' => false])
<div wire:ignore>
    <select autocomplete="off" aria-autocomplete="none" {{ $disabled ? 'disabled' : '' }}
        {!! $attributes->merge(['class' => 'custom-select rounded-xl border border-transparent focus:border-green-500
                                            focus:ring bg-white pl-4 '. $attributes->has('multiple')?:'!h-13' .' focus-visible:outline-none focus:ring-green-200
                                            focus:ring-opacity-50']) !!}>{{$slot}}</select>
</div>