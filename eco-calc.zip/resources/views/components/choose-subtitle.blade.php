<h3 {{ $attributes->merge(['class' => "mx-auto text-base lg:text-xl hd:text-2xl font-bold"])}}>
    {{ $slot }}
</h3>