<a onclick="javascript.void(0)" {{ $attributes->merge(['class' => "hover:underline hover:text-green-900 text-green-500 transition duration-150 cursor-pointer"])}}>{{ $slot }}</a>
