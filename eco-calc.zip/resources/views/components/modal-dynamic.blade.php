@props([
    'closeButton' => false,
    'name' => null,
    'size' => 'hd:w-1/2',
])
@php($variableName = "is{$name}ModalOpen")
<div class="w-full md:w-auto"
     {{ $attributes->except('class') }}
     x-on:keydown.escape.window="{{$variableName}} = false"
     x-cloak
     x-init="
        $watch('{{$variableName}}', value => {
            if (value === true) {
                document.body.classList.add('overflow-hidden')
            } else {
                document.body.classList.remove('overflow-hidden')
            }
        });
    "
>
    <div
        x-show="{{$variableName}}"
        x-bind:aria-hidden="! {{$variableName}}"
        class="fixed inset-0 z-40 overflow-y-auto"
    >
        <div class="flex items-center justify-center min-h-screen px-4 pt-4 pb-20 text-center cursor-default sm:block sm:p-0">
            <div
                x-show="{{$variableName}}"
                x-transition:enter="ease-out duration-300"
                x-transition:enter-start="opacity-0"
                x-transition:enter-end="opacity-100"
                x-transition:leave="ease-in duration-200"
                x-transition:leave-start="opacity-100"
                x-transition:leave-end="opacity-0"
                aria-hidden="true"
                class="fixed inset-0 transition-opacity"
            >
                <div class="absolute inset-0 bg-gray-500 opacity-75"></div>
            </div>

            <span class="hidden sm:inline-block sm:align-middle sm:h-screen" aria-hidden="true">​</span>

            <div
                x-show="{{$variableName}}"
                x-transition:enter="ease-out duration-300"
                x-transition:enter-start="opacity-0 translate-y-4 sm:translate-y-0 sm:scale-95"
                x-transition:enter-end="opacity-100 translate-y-0 sm:scale-100"
                x-transition:leave="ease-in duration-200"
                x-transition:leave-start="opacity-100 translate-y-0 sm:scale-100"
                x-transition:leave-end="opacity-0 translate-y-4 sm:translate-y-0 sm:scale-95"
                role="dialog"
                aria-modal="true"
                x-on:click.away="{{$variableName}} = false"
                {{ $attributes->only('class')->merge(['class' => 'modal-window inline-block text-left align-bottom transition-all transform mt-[90px] fhd:my-12 sm:align-middle w-11/12 md:w-7/12 '.$size]) }}
            >
                <div x-data="{video: false,}" class="bg-white p-6 rounded-3xl shadow-md relative">
                    @if ($closeButton)
                        <div class="flex items-center justify-end mb-4">
                            <button
                                type="button"
                                x-on:click="{{$variableName}} = false, video = false"
                                class="flex self-center shrink-0 text-gray-900 transition-colors duration-200 hover:text-black"
                            >
                                <x-heroicon-o-x-mark class="w-6 h-6" />
                            </button>
                        </div>
                    @endif
                    {{ $slot }}
                </div>
            </div>
        </div>
    </div>
</div>
