@props(['improvement' => null, 'selected' => false, 'focused' => false])
<div {!! $attributes->merge(['class' => 'rounded-full size-[70px] bg-white flex items-center justify-center p-3 border'
                                    . ($selected ? 'border-green-500 cursor-pointer' : '') . ($focused ? ' outline outline-offset-2 outline-green-500' : '')]) !!}>
    <div class="size-10 flex items-center justify-center {{$selected ? '' : 'grayscale'}}">
        <img src="{{asset('images/loading.svg')}}" wire:ignore data-src="{{$improvement->icon}}?v={{time()}}" alt="{{$improvement->description}}" width="40"
             height="40" class="lazyload w-auto">
    </div>
</div>
