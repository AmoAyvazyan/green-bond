@props(['disabled' => false])
<input {{ $disabled ? 'disabled' : '' }} {!! $attributes->merge(['class' => 'rounded-2xl p-4 h-13 border-transparent focus:border-green-500 placeholder:text-gray-50 bg-white focus-visible:outline-none focus:ring focus:ring-green-200 focus:ring-opacity-50 disabled:cursor-not-allowed disabled:opacity-75 shadow-md']) !!}>

