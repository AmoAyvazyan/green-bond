@props(['locale'=>'hy'])
@switch($locale)
    @case('hy')
    <x-country-flag-hy :class="$attributes['class']"/>
    @break
    @case('ru')
    <x-country-flag-ru :class="$attributes['class']"/>
    @break
    @case('en')
    <x-country-flag-uk :class="$attributes['class']"/>
    @break
@endswitch
