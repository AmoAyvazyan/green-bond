@if($active ?? false)
    <a {{ $attributes->merge(['class' => 'block px-6 py-4 text-sm text-gray-900 font-semibold bg-green-500 cursor-default']) }}>{{ $slot }}</a>
@else
    <a {{ $attributes->merge(['class' => 'block px-6 py-4 text-sm text-gray-900 font-semibold hover:bg-green-50 focus:outline-none focus:bg-gray-50 transition duration-200 ease-in-out']) }}>{{ $slot }}</a>
@endif
