<a {{ $attributes->merge(['class' => "text-gray-900 hover:text-black hover:underline transition duration-150 cursor-pointer"])}}>{{ $slot }}</a>
