<section id="partners" class="splide partner-slider pb-24" aria-label="Partners" data-splide='@json($options)'>
    <div class="splide__track">
        <ul class="splide__list">
            @foreach($partners as $partner)
                <li class="splide__slide">
                    <div>
                        @if($partner->url)
                            <a target="_blank" class="cursor-pointer block" rel="nofollow" href="{{$partner->url}}">
                                <img data-src="{{ $partner->logo }}"
                                     alt="{{ $partner->name }}"
                                     class="lazyload rounded h-[40px] mx-9">
                            </a>
                        @else
                            <div>
                                <img data-src="{{ $partner->logo }}"
                                     alt="{{ $partner->name }}"
                                     class="lazyload rounded h-[40px] mx-9">
                            </div>
                        @endif
                    </div>
                </li>
            @endforeach
        </ul>
    </div>
    <ul class="splide__pagination mt-6"></ul>
</section>
<x-slider-assets/>