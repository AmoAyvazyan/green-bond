<div>
    @if($isImported)
        <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded relative flex flex-col space-y-6 items-center justify-center" role="alert">
            <strong class="font-bold">Հաջողվեց!</strong>
            <span class="text-base">{{$message}}</span>
        </div>
    @else
        <form wire:submit.prevent="submit" class="space-y-7 mt-10 text-base">
            <div class="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
                <div class="flex flex-col">
                    <label for="refinance_file" class="mb-2 font-bold text-lg text-gray-900">Refinance File:</label>
                    <x-input-file class="!bg-gray-50" id="refinance_file" wire:model="refinance_file" value="Browse"
                                  placeholder="Excel file (xls,xlsx)"/>
                    @if($errors->has('refinance_file'))
                        @foreach ($errors->get('refinance_file') as $error)
                            <span class="text-red-500 text-sm">{{ $error }}</span><br>
                        @endforeach
                    @endif
                </div>
                <div class="flex flex-col">
                    <label for="reject_file" class="mb-2 font-bold text-lg text-gray-900">Reject File:</label>
                    <x-input-file class="!bg-gray-50" id="reject_file" wire:model="reject_file" value="Browse"
                                  placeholder="Excel file (xls,xlsx)"/>
                    @if($errors->has('reject_file'))
                        @foreach ($errors->get('reject_file') as $error)
                            <span class="text-red-500 text-sm">{{ $error }}</span><br>
                        @endforeach
                    @endif
                </div>
                <div class="col-span-full">
                    <x-checkbox checked id="need_validation" wire:model="need_validation" value="1">Need Validation
                    </x-checkbox>
                </div>
            </div>
            <div class="flex justify-center">
                <x-btn color="green" class="px-4 py-2 bg-green-500 text-white rounded-lg hover:bg-green-600">Submit
                </x-btn>
            </div>
        </form>
    @endif
</div>