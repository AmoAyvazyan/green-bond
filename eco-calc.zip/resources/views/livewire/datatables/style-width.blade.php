style="
@isset($column['width']) width:{{ $column['width'] }}; @endisset
@isset($column['minWidth']) min-width:{{ $column['minWidth'] }}; @endisset
@isset($column['maxWidth']) max-width:{{ $column['maxWidth'] }}; @endisset
"
