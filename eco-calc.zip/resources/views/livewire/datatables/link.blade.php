<a href="{{ $href }}" class="hover:underline hover:text-yellow-700 font-bold text-blue-500 pr-3">{{ $slot }}</a>
