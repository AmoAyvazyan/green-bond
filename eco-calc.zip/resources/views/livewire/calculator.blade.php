<div class="relative py-8 lg:py-0" x-data="{
        isLoanerEmailModalOpen: false,
        isAuthLoanerModalOpen: false,
        isVerifyLoanerModalOpen: false,
    }">
    @include('livewire.partials.steps-nav')
    @if($step === 1)
        <x-container class="mb-10">
            <x-notice>
                {!! __('phrases.step_1_notice', ['url' => route('front.terms.privacy-policy')]) !!}
            </x-notice>
        </x-container>
        <x-container class="calculation-step">
            <div class="rounded-4xl bg-gray-50 p-2 sm:p-4 lg:p-8 grid grid-cols-1 lg:grid-cols-2 gap-x-28 gap-y-12">
                <div class="grid grid-cols-1 lg:grid-cols-2 gap-y-8 gap-x-4">
                    <div>
                        <x-label for="loaner_first_name" class="mb-4" :value="__('phrases.first_name').' *'"/>
                        <x-input wire:model="loaner_first_name" id="loaner_first_name" class="block w-full"
                                 type="text"
                                 name="loaner_first_name" required autofocus/>
                        @error('loaner_first_name')
                        <p class="text-red-500 text-xs mt-2">{{ $message }}</p>
                        @enderror
                    </div>
                    <div>
                        <x-label for="loaner_last_name" class="mb-4" :value="__('phrases.last_name').' *'"/>
                        <x-input wire:model="loaner_last_name" id="loaner_last_name" class="block w-full"
                                 type="text"
                                 name="loaner_last_name" required/>
                        @error('loaner_last_name')
                        <p class="text-red-500 text-xs mt-2">{{ $message }}</p>
                        @enderror
                    </div>
                    <div class="contains-custom-select">
                        <x-label for="selected_region_id" class="mb-4" :value="__('phrases.property_location').' *'"/>
                        <x-custom-select x-on:change="$wire.set('selected_region_id', event.target.value)"
                                         id="selected_region_id"
                                         data-placeholder="{{__('phrases.select_region')}}" name="selected_region_id">
                            <option value="" selected>{{__('phrases.select_region')}}</option>
                            @foreach($regions as $region)
                                <option {{$region->id == $selected_region_id ? 'selected' : ''}}
                                        value="{{$region->id}}">{{$region->name}}</option>
                            @endforeach
                        </x-custom-select>
                        @error('selected_region_id')
                        <p class="text-red-500 text-xs mt-2">{{ $message }}</p>
                        @enderror
                    </div>
                    <div class="contains-custom-select">
                        <x-label for="selected_community_id" class="mb-4 lg:text-transparent"
                                 :value="__('phrases.select_community')"/>
                        <x-custom-wire-select
                            x-on:change="$wire.set('selected_community_id', event.target.value)"
                            id="selected_community_id"
                            :disabled="$communities->isEmpty() ? 'disabled' : ''"
                            data-placeholder="{{__('phrases.select_community')}}" name="selected_community_id">
                            @foreach($communities as $community)
                                <option {{$community->id == $selected_community_id ? 'selected' : ''}}
                                        value="{{$community->id}}">{{$community->name}}</option>
                            @endforeach
                        </x-custom-wire-select>
                        @error('selected_community_id')
                        <p class="text-red-500 text-xs mt-2">{{ $message }}</p>
                        @enderror
                    </div>
                    <div class="col-span-full">
                        <x-label for="address" class="mb-4" :value="__('phrases.address').' *'"/>
                        <x-input wire:model="address" id="address" class="block w-full" type="text"
                                 name="address" required/>
                        @error('address')
                        <p class="text-red-500 text-xs mt-2">{{ $message }}</p>
                        @enderror
                    </div>
                </div>
                <div class="grid grid-cols-1 lg:grid-cols-2 gap-y-8 gap-x-4">
                    <div class="col-span-full">
                        <x-label class="mb-4" :value="__('phrases.property_type')"/>
                        <div class="flex items-center space-x-4 w-full">
                            @if($this->isConstruction)
                                <div class="rounded-2xl border border-green-500 flex items-center px-4 py-3
                                        space-x-4 bg-white shadow-md">
                                    <x-icons.home class="size-[26px] text-green-500"/>
                                    <span>{{__('phrases.property_type_house')}}</span>
                                </div>
                            @else
                                <label for="loan_property_type_flat" class="rounded-2xl border flex items-center px-4 py-3
                                        space-x-4 bg-white shadow-md {{ $property_type === \App\Models\LoanRequest::PROPERTY_TYPE_APARTMENT
                                         ? 'border-green-500' : 'border-gray-400 cursor-pointer'}}">
                                    <x-icons.flat class="size-[26px] {{ $property_type === \App\Models\LoanRequest::PROPERTY_TYPE_APARTMENT
                                         ? 'text-green-500' : 'text-gray-400'}}"/>
                                    <span>{{__('phrases.property_type_apartment')}}</span>
                                    <input wire:model.live="property_type" id="loan_property_type_flat"
                                           type="radio" value="{{\App\Models\LoanRequest::PROPERTY_TYPE_APARTMENT}}"
                                           class="hidden"/>
                                </label>
                                <label for="loan_property_type_house"
                                       class="rounded-2xl border flex items-center px-4 py-3
                                        space-x-4 bg-white shadow-md {{ $property_type === \App\Models\LoanRequest::PROPERTY_TYPE_HOUSE
                                         ? 'border-green-500' : 'border-gray-400 cursor-pointer'}}">
                                    <x-icons.home class="size-[26px] {{ $property_type === \App\Models\LoanRequest::PROPERTY_TYPE_HOUSE
                                         ? 'text-green-500' : 'text-gray-400'}}"/>
                                    <span>{{__('phrases.property_type_house')}}</span>
                                    <input wire:model.live="property_type" id="loan_property_type_house"
                                           type="radio" value="{{\App\Models\LoanRequest::PROPERTY_TYPE_HOUSE}}"
                                           class="hidden"/>
                                </label>
                            @endif
                        </div>
                        @error('property_type')
                        <p class="text-red-500 text-xs mt-2">{{ $message }}</p>
                        @enderror
                    </div>
                    <div>
                        <x-label for="deadline" class="mb-4" :value="__('phrases.deadline').' *'"/>
                        <div>
                            <x-input-unit inputmode="numeric"
                                          wire:model="deadline" id="deadline" size="w-full"
                                          x-on:input="event.target.value = event.target.value.replace(/[^0-9]/g, '')"
                                          :unit="__('phrases.month')"/>
                            @error('deadline')
                            <p class="text-red-500 col-span-full text-xs mt-2">{{ $message }}</p>
                            @enderror
                        </div>
                    </div>
                    <div>
                        <x-label for="area" class="mb-4" :value="__('phrases.total_area').' *'"/>
                        <x-input-unit inputmode="numeric"
                                      value="{{ $area }}"
                                      :disabled="!$selectedRegion"
                                      x-on:input="event.target.value = event.target.value.replace(/[,․,]/g, '.').replace(/[^0-9.]/g, ''); $wire.set('area', event.target.value)"
                                      id="area" size="w-full"
                                      :unit="__('phrases.sqm')"/>
                        @error('area')
                        <p class="text-red-500 col-span-full text-xs mt-2">{{ $message }}</p>
                        @enderror
                    </div>
                    <div class="col-span-full lg:h-[92px]"></div>
                </div>
                <div class="col-span-full flex flex-col justify-center items-center space-y-4">
                    <x-btn wire:loading.attr="disabled" color="green" class="space-x-4 md:space-x-6"
                           x-on:click="$dispatch('scroll-needed')"
                           wire:click="start">
                        <span>{{__('buttons.start')}}</span>
                        <x-icons.arrow-right class="w-6 h-auto"/>
                    </x-btn>
                    <x-btn wire:loading.attr="disabled" color="green" :outline="true"
                           class="hidden sm:inline-flex"
                           x-on:click="isAuthLoanerModalOpen = true">{{__('buttons.edit')}}</x-btn>
                    <x-link class="sm:hidden text-center"
                            x-on:click="isAuthLoanerModalOpen = true">{{__('buttons.edit')}}</x-link>
                </div>
            </div>
            <x-modal-dynamic name="AuthLoaner" :close-button="false" size="lg:w-4/12">
                <form class="modal-content">
                    <x-label for="auth_email" class="mb-4">{{__('phrases.need_email')}}</x-label>
                    <x-input class="w-full !bg-gray-50" type="email"
                             placeholder="{{__('phrases.email')}}"
                             wire:model="auth_email" id="auth_email"/>
                    @error('auth_email')
                    <p class="text-red-500 col-span-full text-xs mt-2">{{ $message }}</p>
                    @enderror
                    <div class="flex items-center justify-center mt-8">
                        <x-btn color="green" class="justify-between space-x-6"
                               type="button"
                               wire:loading.attr="disabled"
                               x-on:click="isAuthLoanerModalOpen = !(await $wire.sendVerification()); isVerifyLoanerModalOpen = !isAuthLoanerModalOpen;">
                            {{__('buttons.send_verification')}}
                        </x-btn>
                    </div>
                </form>
            </x-modal-dynamic>
            <x-modal-dynamic name="VerifyLoaner" :close-button="false" size="lg:w-4/12">
                <form class="modal-content">
                    <x-label for="verification_code" class="mb-4">{{__('phrases.need_code')}}</x-label>
                    <x-input class="w-full !bg-gray-50" type="text" inputmode="numeric"
                             min="6" max="6" x-on:input="event.target.value = event.target.value.replace(/[^0-9]/g, '')"
                             wire:model="verification_code" id="verification_code"/>
                    @error('verification_code')
                    <p class="text-red-500 col-span-full text-xs mt-2">{{ $message }}</p>
                    @enderror
                    <div class="flex items-center justify-center mt-8 space-x-12">
                        <x-btn color="green" :outline="true" type="button"
                               x-on:click="isVerifyLoanerModalOpen = false; isAuthLoanerModalOpen = true"
                               wire:loading.attr="disabled"
                        >
                            <x-icons.arrow-left class="w-6 h-auto sm:hidden"/>
                            <span class="hidden sm:block">{{__('buttons.back')}}</span>
                        </x-btn>
                        <x-btn color="green" type="button"
                               wire:loading.attr="disabled"
                               x-on:click="isVerifyLoanerModalOpen = !(await $wire.verifyLoaner())">
                            <span class="hidden sm:block">{{__('buttons.continue')}}</span>
                            <x-icons.arrow-right class="w-6 h-auto sm:hidden"/>
                        </x-btn>
                    </div>
                </form>
            </x-modal-dynamic>
        </x-container>
    @elseif($step === 2)
        @if( $this->isRenovation )
            <x-container class="mb-10">
                <x-notice>
                    {{__('phrases.step_2_notice')}}
                </x-notice>
            </x-container>
        @endif
        <x-container class="calculation-step">
            <div class="rounded-4xl bg-gray-50 p-2 sm:p-4 lg:p-8">
                <div class="grid grid-cols-2 gap-4 lg:flex lg:justify-between items-start lg:space-x-2 mb-12">
                    @foreach($eeImprovements as $improvement)
                        <div wire:click="toggleEeImprovement({{$improvement->id}})"
                             class="flex flex-col items-center border p-2 space-y-8 justify-between rounded-2xl w-full
                                {{$improvement->children->isEmpty() ? 'cursor-pointer' : ''}}
                                {{$selectedEeImprovements->contains($improvement)
                                    ? 'border-green-500 bg-white text-black'
                                    : 'border-gray-400 text-gray-500 bg-gray-50'}}">
                            <x-improvement-icon :selected="$selectedEeImprovements->contains($improvement)"
                                                :improvement="$improvement" class="ee-icon"/>
                            <span class="w-full text-sm xs:text-base text-center">{{$improvement->name}}</span>
                            @if($improvement->children->isNotEmpty())
                                <div class="flex flex-col space-y-6 self-start">
                                    @foreach($improvement->children as $child)
                                        <x-checkbox id="improvement_{{$child->id}}"
                                                    :checked="in_array($child->id, $selectedEeChildren[$improvement->id] ?? [])"
                                                    wire:change.prevent="toggleChildEeImprovement({{$improvement->id}}, {{$child->id}})">{{$child->name}}</x-checkbox>
                                    @endforeach
                                </div>
                            @endif
                        </div>
                    @endforeach
                </div>
                <div class="flex justify-center items-center space-x-12 lg:space-x-8">
                    <x-btn wire:loading.attr="disabled" color="green" class="space-x-4 md:space-x-6"
                           :outline="true"
                           x-on:click="$dispatch('scroll-needed')"
                           wire:click="$set('step',1)">
                        <x-icons.arrow-left class="w-6 h-auto"/>
                        <span>{{__('buttons.back')}}</span>
                    </x-btn>
                    <x-btn wire:loading.attr="disabled" color="green" class="space-x-4 md:space-x-6"
                           x-on:click="$dispatch('scroll-needed')"
                           wire:click="fillEeImprovements">
                        <span>{{__('buttons.next')}}</span>
                        <x-icons.arrow-right class="w-6 h-auto"/>
                    </x-btn>
                </div>
            </div>
        </x-container>
    @elseif($step === 2.5)
        <x-container class="calculation-step grid grid-cols-1 lg:grid-cols-3 lg:gap-x-6 gap-y-6 lg:gap-y-0 relative">
            <div class="rounded-4xl bg-gray-50 p-2 sm:p-4 lg:p-8 col-span-2">
                <div class="overflow-hidden p-2">
                    <div class="flex items-center mb-12 icons-row" style="
                            width: calc({{$selectedEeImprovements->count()}} * 120px);
                            transform: translateX({{-($currentEeImprovementIndex - 1) * 120 }}px);
                        ">
                        @php($selectedEeImprovements = $selectedEeImprovements->sortBy('sort_order')->values())
                        @foreach($selectedEeImprovements as $index => $improvement)
                            <x-improvement-icon :improvement="$improvement" class="ee-icon"
                                                wire:click="setCurrentEeImprovement({{ $index }}, {{ $improvement->sort_order }})"
                                                :selected="$improvement->sort_order <= $currentEeImprovement->sort_order"
                                                :focused="$improvement->is($currentEeImprovement)"/>
                            @if(!$loop->last)
                                <div class="border-b w-10 md:w-8
                                        {{$improvement->sort_order < $currentEeImprovement->sort_order ? 'border-green-500' : 'border-gray-50' }}">
                                </div>
                            @endif
                        @endforeach
                    </div>
                </div>
                <h2 class="font-bold text-xl xs:text-2xl text-black mb-12">{{$currentEeImprovement->description}}</h2>
                @if($currentEeImprovement->children->isEmpty())
                    <div class="relative">
                        @include('livewire.partials.ee-improvement-form', ['improvement' => $currentEeImprovement])
                    </div>
                @else
                    @foreach($currentEeImprovement->children as $child)
                        @if(in_array($child->id, $selectedEeChildren[$currentEeImprovement->id] ?? []))
                            <div class="bg-gray-200 p-6 mb-6 rounded-3xl relative">
                                <h3 class="font-bold text-black mb-8 text-lg">{{$child->name}}</h3>
                                @include('livewire.partials.ee-improvement-form', ['improvement' => $child])
                            </div>
                        @endif
                    @endforeach
                @endif
                <div class="flex justify-center items-center space-x-12 lg:space-x-8 mt-12">
                    <x-btn wire:loading.attr="disabled" color="green" class="space-x-4 md:space-x-6"
                           :outline="true"
                           x-on:click="$dispatch('scroll-needed')"
                           wire:click="prevEeImprovement">
                        <x-icons.arrow-left class="w-6 h-auto"/>
                        <span>{{__('buttons.back')}}</span>
                    </x-btn>
                    <x-btn wire:loading.attr="disabled" color="green" class="space-x-4 md:space-x-6"
                           x-on:click="$dispatch('scroll-needed')"
                           wire:click="nextEeImprovement">
                        <span>{{__('buttons.next')}}</span>
                        <x-icons.arrow-right class="w-6 h-auto"/>
                    </x-btn>
                </div>
            </div>
            <div>
                @include('livewire.partials.summary')
            </div>
        </x-container>
    @elseif($step === 3)
        <x-container class="calculation-step">
            <div class="rounded-4xl bg-gray-50 p-2 sm:p-4 lg:p-8">
                <div
                    class="grid grid-cols-1 sm:grid-cols-2 gap-4 lg:flex justify-between items-start lg:space-x-2 mb-12">
                    @foreach($improvements as $improvement)
                        <div wire:click="toggleImprovement({{$improvement->id}})"
                             class="flex flex-col items-center border p-2 space-y-8 justify-between rounded-2xl w-full
                                   {{$improvement->children->isEmpty() ? 'cursor-pointer' : ''}}
                                   {{$selectedImprovements->contains($improvement)
                                       ? 'border-green-500 bg-white text-black'
                                       : 'border-gray-400 text-gray-500 bg-gray-50'}}">
                            <x-improvement-icon :selected="$selectedImprovements->contains($improvement)"
                                                :improvement="$improvement" class="non-ee-icon"/>
                            <span class="w-full text-center">{{$improvement->name}}</span>
                            @if($improvement->children->isNotEmpty())
                                <div class="flex flex-col space-y-6 self-start">
                                    @foreach($improvement->children as $child)
                                        <x-checkbox id="improvement_{{$child->id}}"
                                                    :checked="in_array($child->id, $selectedChildren[$improvement->id] ?? [])"
                                                    wire:change.prevent="toggleChildImprovement({{$improvement->id}}, {{$child->id}})">{{$child->name}}</x-checkbox>
                                    @endforeach
                                </div>
                            @endif
                        </div>
                    @endforeach
                </div>
                <div class="flex justify-center items-center space-x-12 lg:space-x-8">
                    <x-btn wire:loading.attr="disabled" color="green" class="space-x-4 md:space-x-6"
                           :outline="true"
                           x-on:click="$dispatch('scroll-needed')"
                           wire:click="prevEeImprovement">
                        <x-icons.arrow-left class="w-6 h-auto"/>
                        <span>{{__('buttons.back')}}</span>
                    </x-btn>
                    <x-btn wire:loading.attr="disabled" color="green" class="space-x-4 md:space-x-6"
                           x-on:click="$dispatch('scroll-needed')"
                           wire:click="fillImprovements">
                        <span>{{__('buttons.next')}}</span>
                        <x-icons.arrow-right class="w-6 h-auto"/>
                    </x-btn>
                </div>
            </div>
        </x-container>
    @elseif($step === 3.5)
        <x-container class="calculation-step grid grid-cols-1 lg:grid-cols-3 lg:gap-x-6 gap-y-6 lg:gap-y-0 relative">
            <div class="rounded-4xl bg-gray-50 p-2 sm:p-4 lg:p-8 col-span-2">
                <div class="overflow-hidden p-2">
                    <div class="flex items-center mb-12 icons-row" style="
                            width: calc({{$selectedImprovements->count()}} * 120px);
                            transform: translateX({{-($currentImprovementIndex - 1) * 120 }}px);
                        ">
                        @php($selectedImprovements = $selectedImprovements->sortBy('id'))
                        @foreach($selectedImprovements as $index => $improvement)
                            <x-improvement-icon :improvement="$improvement" class="non-ee-icon"
                                                wire:click="setCurrentImprovement({{ $index }}, {{ $improvement->id }})"
                                                :selected="$improvement->id <= $currentImprovement->id"
                                                :focused="$improvement->is($currentImprovement)"/>
                            @if(!$loop->last)
                                <div class="border-b w-6 lg:w-8
                                        {{$improvement->id < $currentImprovement->id ? 'border-green-500' : 'border-gray-50' }}">
                                </div>
                            @endif
                        @endforeach
                    </div>
                </div>
                <h2 class="font-bold text-xl xs:text-2xl text-black mb-12">{{$currentImprovement->description}}</h2>
                @if($currentImprovement->children->isEmpty())
                    <div class="relative">
                        @include('livewire.partials.improvement-form', ['improvement' => $currentImprovement])
                    </div>
                @else
                    @foreach($currentImprovement->children as $child)
                        @if(in_array($child->id, $selectedChildren[$currentImprovement->id] ?? []))
                            <div class="bg-gray-200 p-6 mb-6 rounded-3xl relative">
                                <h3 class="font-bold text-black mb-8 text-lg">{{$child->name}}</h3>
                                @if($child->children->isEmpty())
                                    @include('livewire.partials.improvement-form', ['improvement' => $child])
                                @else
                                    @foreach($child->children as $subChild)
                                        <div class="bg-gray-50 p-6 mb-4 rounded-3xl relative">
                                            @include('livewire.partials.improvement-form', ['improvement' => $subChild])
                                        </div>
                                    @endforeach
                                    @if($child->include_works)
                                        <div
                                            class="bg-gray-50 p-6 mb-4 rounded-3xl grid grid-cols-1 lg:grid-cols-2 lg:gap-x-8 gap-y-6">
                                            <div class="flex items-center">
                                                <label class="mb-4 lg:mb-0"
                                                       for="labor_cost_{{$child->id}}">{{__('phrases.labor_cost')}}</label>
                                            </div>
                                            <div>
                                                <div
                                                    class="flex flex-col items-start lg:flex-row lg:items-center justify-start lg:justify-end">
                                                    <x-input-unit id="labor_cost_{{$child->id}}" type="text"
                                                                  inputmode="numeric" size="w-full"
                                                                  x-on:input="event.target.value = event.target.value.replace(/[^0-9]/g, '')"
                                                                  x-on:blur="event.target.value = window.numberFormat(event.target.value.replace(/[^0-9]/g, ''))"
                                                                  :unit="__('phrases.amd')"
                                                                  wire:model.blur="applied_improvement_data.{{$child->id}}.labor_cost"/>
                                                </div>
                                                @error('applied_improvement_data.'.$child->id.'.labor_cost')
                                                <p class="text-red-500 text-xs mt-2 text-right">{{ $message }}</p>
                                                @enderror
                                            </div>
                                        </div>
                                    @endif
                                @endif
                            </div>
                        @endif
                    @endforeach
                @endif
                <div class="flex justify-center items-center space-x-12 lg:space-x-8 mt-12">
                    <x-btn wire:loading.attr="disabled" color="green" class="space-x-4 md:space-x-6"
                           :outline="true"
                           x-on:click="$dispatch('scroll-needed')"
                           wire:click="prevImprovement">
                        <x-icons.arrow-left class="w-6 h-auto"/>
                        <span>{{__('buttons.back')}}</span>
                    </x-btn>
                    <x-btn wire:loading.attr="disabled" color="green" class="space-x-4 md:space-x-6"
                           x-on:click="$dispatch('scroll-needed')"
                           wire:click="nextImprovement">
                        <span>{{__('buttons.next')}}</span>
                        <x-icons.arrow-right class="w-6 h-auto"/>
                    </x-btn>
                </div>
            </div>
            <div>
                @include('livewire.partials.summary')
            </div>
        </x-container>
    @elseif($step === 4)
        <x-container class="calculation-step grid grid-cols-1 lg:grid-cols-3 lg:gap-x-6 gap-y-6 lg:gap-y-0 relative">
            <div class="rounded-4xl bg-gray-50 p-2 sm:p-4 lg:p-8 col-span-2">
                <div class="flex items-center mb-12">
                    @php($selectedImprovements = $selectedImprovements->sortBy('id'))
                    @foreach($selectedImprovements as $improvement)
                        <x-improvement-icon :improvement="$improvement" class="non-ee-icon"
                                            :selected="$improvement->id <= $currentImprovement->id"
                                            :focused="$improvement->is($currentImprovement)"/>
                        @if(!$loop->last)
                            <div class="border-b w-6 lg:w-8
                                        {{$improvement->id < $currentImprovement->id ? 'border-green-500' : 'border-gray-50' }}">
                            </div>
                        @endif
                    @endforeach
                </div>
                <div class="bg-gray-200 p-6 mb-12 rounded-3xl flex flex-col items-center justify-center">
                    @foreach($applied_custom_data as $index => $improvement)
                        <div
                            class="w-full bg-gray-50 p-6 rounded-t-3xl grid grid-cols-1 lg:grid-cols-2 lg:gap-x-8 gap-y-6">
                            <div class="flex flex-col items-start lg:flex-row justify-start lg:items-center
                                            lg:justify-between lg:space-x-6">
                                <x-label class="mb-4 lg:mb-0"
                                         for="name_{{$index}}">{{__('phrases.description')}}</x-label>
                                <x-input id="name_{{$index}}" type="text"
                                         wire:model.blur="applied_custom_data.{{$index}}.name"/>
                            </div>
                            <div class="flex flex-col items-start lg:flex-row lg:items-center justify-start
                                            lg:justify-between lg:space-x-6">
                                <x-label class="mb-4 lg:mb-0 whitespace-nowrap"
                                         for="price_{{$index}}">{{__('phrases.total_price')}}</x-label>
                                <x-input-unit id="price_{{$index}}" type="text"
                                              inputmode="numeric"
                                              x-on:input="event.target.value = event.target.value.replace(/[^0-9]/g, '')"
                                              x-on:blur="event.target.value = window.numberFormat(event.target.value.replace(/[^0-9]/g, ''))"
                                              :unit="__('phrases.amd')"
                                              wire:model.blur="applied_custom_data.{{$index}}.price"/>
                            </div>
                        </div>
                        <div wire:click="removeCustomImprovement({{$index}})"
                             class="w-full mb-8 rounded-b-3xl bg-red-500 text-white cursor-pointer flex items-center justify-center p-3">
                            <x-heroicon-o-trash class="w-6 h-auto mr-6"/>
                            <span>{{__('buttons.remove_measure')}}</span>
                        </div>
                    @endforeach
                    <x-btn color="dark" class="space-x-4 md:space-x-6" wire:click="addCustomImprovement">
                        <x-heroicon-o-plus-circle class="w-6 h-auto"/>
                        <span>{{__('buttons.add_measure')}}</span>
                    </x-btn>
                </div>
                <div class="flex justify-center items-center space-x-12 lg:space-x-8 mt-12">
                    <x-btn wire:loading.attr="disabled" color="green" class="space-x-4 md:space-x-6"
                           :outline="true"
                           x-on:click="$dispatch('scroll-needed')"
                           wire:click="prevImprovement">
                        <x-icons.arrow-left class="w-6 h-auto"/>
                        <span>{{__('buttons.back')}}</span>
                    </x-btn>
                    <x-modal :close-button="false" size="lg:w-4/12">
                        <x-slot name="trigger">
                            <x-btn color="green"
                                   x-on:click="event.target.disabled = true; await (isModalOpen = $wire.validateEligibility())">
                                {{__('buttons.download_report')}}
                            </x-btn>
                        </x-slot>
                        <div class="modal-content">
                            @if($errors->has('eligibility'))
                                <x-validation-errors :errors="$errors"/>
                                <div class="flex items-center justify-center mt-6">
                                    <x-btn x-on:click="isModalOpen = false" color="green">
                                        {{__('buttons.got_it')}}
                                    </x-btn>
                                </div>
                            @else
                                <p class="mb-8">{{__('phrases.download_notice')}}</p>
                                <div class="flex flex-col items-center justify-center space-y-6">
                                    <x-btn color="green" class="space-x-4 md:space-x-6"
                                           x-on:click="event.target.disabled = true; event.currentTarget.disabled = true; isModalOpen = !(await $wire.downloadReport())">
                                        <span>{{__('buttons.download_report_final')}}</span>
                                        <x-icons.download class="w-6 h-auto"/>
                                    </x-btn>
                                    <x-btn x-on:click="isLoanerEmailModalOpen = true" color="green" :outline="true">
                                        {{__('buttons.download_editable')}}
                                    </x-btn>
                                </div>
                            @endif
                        </div>
                    </x-modal>
                    <x-modal-dynamic name="LoanerEmail" :close-button="false" size="lg:w-4/12">
                        <div class="modal-content">
                            <x-label for="loaner_email" class="mb-4">{{__('phrases.need_email')}}</x-label>
                            <x-input class="w-full mb-8 !bg-gray-50" type="email"
                                     wire:model.blur="loaner_email" id="loaner_email"/>
                            <div class="flex items-center justify-center">
                                <x-btn color="green" class="space-x-4 md:space-x-6"
                                       x-on:click="event.target.disabled = true; event.currentTarget.disabled = true; isLoanerEmailModalOpen = !(await $wire.saveAndDownloadReport())"
                                >
                                    <span>{{__('buttons.download_report')}}</span>
                                    <x-icons.download class="w-6 h-auto"/>
                                </x-btn>
                            </div>
                        </div>
                    </x-modal-dynamic>
                </div>
            </div>
            <div>
                @include('livewire.partials.summary')
            </div>
        </x-container>
    @else
        <x-container class="calculation-step">
            <div class="rounded-4xl bg-gray-50 p-2 sm:p-4 lg:p-8 flex flex-col items-center justify-center min-h-[300px]">
                <h2 class="font-bold text-xl xs:text-2xl text-black mb-12">{{__('phrases.final_title')}}</h2>
                <x-btn color="green" class="space-x-4 md:space-x-6" x-on:click="location.replace('/')">{{__('buttons.back')}}</x-btn>
            </div>
        </x-container>
    @endif
</div>
@script
<script>
    $wire.on('scroll-needed', () => {
        const targetElement = document.querySelector('.calculation-step');
        if (targetElement) {
            window.scrollTo({
                top: targetElement.offsetTop - 100,
                behavior: 'smooth',
            });
        }
    });
    $wire.$watch('selected_region_id', (value, old) => {
        if (value != old) {
            const select = document.getElementById('selected_region_id');
            window.initCustomSelects([select]);
            select.tomselect.setValue(value);
        }
    });
    if (window.Livewire) {
        Livewire.hook('morph.updated', ({el, component}) => {
            if (el.classList.contains('contains-custom-select')) {
                let select = el.querySelector('.custom-select');
                if (!select) {
                    setTimeout(() => {
                        window.initCustomSelects();
                    }, 2);
                } else {
                    setTimeout(() => {
                        window.initCustomSelects([select]);
                        select.tomselect.sync();
                    }, 1);
                }
            }

            if (!window.isMobile) {
                setTimeout(() => {
                    document.querySelectorAll('.icons-row').forEach((el) => {
                        el.removeAttribute('style');
                    });
                }, 2)
            }
        });
    }
</script>
@endscript
