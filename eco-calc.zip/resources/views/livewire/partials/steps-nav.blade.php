<x-container class="hidden md:block mb-16">
    <div class="flex items-center px-16 mb-4">
        <div class="rounded-full flex items-center justify-center border-2 border-green-500 min-w-[78px] h-[78px]">
            <div class="rounded-full size-[56px] bg-green-500 flex items-center justify-center">
                <span class="text-white text-3xl leading-none -mt-1">1</span>
            </div>
        </div>
        <div class="border-b-2 w-full {{$step>1 ? 'border-green-500' : 'border-white/30'}}
                        transition duration-150 ease-in"></div>
        <div class="rounded-full flex items-center justify-center border-2
                        transition duration-150 ease-in
                        {{$step>1 ? 'border-green-500' : 'border-transparent'}} min-w-[78px] h-[78px]">
            <div class="rounded-full size-[56px] {{$step>1 ? 'bg-green-500' : 'bg-white/30'}}
                            flex items-center justify-center">
                <span class="text-white text-3xl leading-none -mt-1">2</span>
            </div>
        </div>
        <div class="border-b-2 w-full {{$step>2.5 || $step === 0 ? 'border-green-500' : 'border-white/30'}}
                        transition duration-150 ease-in"></div>
        <div class="rounded-full flex items-center justify-center border-2
                        transition duration-150 ease-in
                        {{$step>2.5 || $step === 0 ? 'border-green-500' : 'border-transparent'}} min-w-[78px] h-[78px]">
            <div class="rounded-full size-[56px] {{$step>2.5 || $step === 0 ? 'bg-green-500' : 'bg-white/30'}}
                            flex items-center justify-center">
                <span class="text-white text-3xl leading-none -mt-1">3</span>
            </div>
        </div>
    </div>
    <div class="flex items-center justify-between mb-2">
        <span class="text-center text-white max-w-[200px] font-bold">{{__('phrases.common_info')}}</span>
        <span class="text-center max-w-[300px] lg:max-w-[400px]
                        {{$step>1 ? 'text-white font-bold' : 'text-white/60'}}">{{__('phrases.ee_improvements')}}</span>
        <span class="text-center max-w-[200px]
                        {{$step>2 || $step === 0 ? 'text-white font-bold' : 'text-white/60'}}">{{__('phrases.non_ee_improvements')}}</span>
    </div>
</x-container>
<div class="md:hidden">
    <div class="flex items-center justify-center mt-2">
        <div class="border-b-2 w-full {{$step>1 || $step === 0 ? 'border-green-500' : 'border-transparent'}}
                        transition duration-150 ease-in"></div>
        <div class="rounded-full flex items-center justify-center border-2
                        transition duration-150 ease-in border-green-500 min-w-[78px] h-[78px]">
            <div class="rounded-full size-[56px] bg-green-500
                            flex items-center justify-center">
                <span class="text-white text-3xl leading-none -mt-1">{{(int) $step}}</span>
            </div>
        </div>
        <div class="border-b-2 w-full {{$step<3 ? 'border-green-500' : 'border-transparent'}}
                        transition duration-150 ease-in"></div>
    </div>
    <div class="flex items-center justify-center mt-6 mb-16">
        <span class="text-center text-white max-w-[280px] font-bold">
            @if($step === 1)
                {{__('phrases.common_info')}}
            @elseif($step > 1)
                {{__('phrases.ee_improvements')}}
            @else
                {{__('phrases.non_ee_improvements')}}
            @endif
        </span>
    </div>
</div>