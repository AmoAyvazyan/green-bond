@if($this->isConstruction)
    @include('livewire.partials.construction-summary')
@else
    @include('livewire.partials.renovation-summary')
@endif