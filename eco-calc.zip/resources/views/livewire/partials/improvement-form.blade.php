@props(['improvement' => null])
<div>
    <div class="grid grid-cols-1 lg:grid-cols-2 lg:gap-x-8 gap-y-6">
        @if($improvement->is_countable)
            <div class="col-span-full">
                <h4 class="text-black">{{$improvement->name}}</h4>
            </div>
            <div>
                <div
                    class="flex flex-col items-start lg:flex-row lg:items-center justify-start lg:justify-between lg:space-x-6">
                    <x-label class="mb-4 lg:mb-0"
                             for="quantity_{{$improvement->id}}">{{__('phrases.quantity')}}</x-label>
                    <x-input-unit id="quantity_{{$improvement->id}}" type="text"
                                  inputmode="numeric"
                                  x-on:input="event.target.value = event.target.value.replace(/[^0-9]/g, '')"
                                  :unit="$improvement->unit"
                                  wire:model.blur="applied_improvement_data.{{$improvement->id}}.quantity"/>
                </div>
                @error('applied_improvement_data.'.$improvement->id.'.quantity')
                <p class="text-red-500 text-xs mt-2 text-right">{{ $message }}</p>
                @enderror
            </div>
            <div>
                <div
                    class="flex flex-col items-start lg:flex-row lg:items-center justify-start lg:justify-between lg:space-x-6">
                    <x-label class="mb-4 lg:mb-0 whitespace-nowrap"
                             for="price_{{$improvement->id}}">{{__('phrases.price_one')}}</x-label>
                    <x-input-unit id="price_{{$improvement->id}}" type="text"
                                  inputmode="numeric"
                                  x-on:input="event.target.value = event.target.value.replace(/[^0-9]/g, '')"
                                  :unit="__('phrases.amd')"
                                  x-on:blur="event.target.value = window.numberFormat(event.target.value.replace(/[^0-9]/g, ''))"
                                  wire:model.blur="applied_improvement_data.{{$improvement->id}}.price"/>
                </div>
                @error('applied_improvement_data.'.$improvement->id.'.price')
                <p class="text-red-500 text-xs mt-2 text-right">{{ $message }}</p>
                @enderror
            </div>
            <div class="col-span-full flex items-center space-x-2">
                <div class="border-b border-gray-400 w-full"></div>
                <span class="text-gray-400 whitespace-nowrap">{{__('phrases.total_amount')}} <span
                        class="text-black">{{number_format((int) ($applied_improvement_data[$improvement->id]['quantity'] ?: 1)
                                                        * (int) $applied_improvement_data[$improvement->id]['price'], 0, '.', ' ')}}</span> {{__('phrases.amd')}}</span>
                <div class="border-b border-gray-400 w-full"></div>
            </div>
        @else
            <h4 class="flex items-center">
                <label class="mb-4 lg:mb-0" for="total_{{$improvement->id}}">{{$improvement->name}}</label>
            </h4>
            <div>
                <div
                    class="flex flex-col items-start lg:flex-row lg:items-center justify-start lg:justify-end">
                    <x-input-unit id="total_{{$improvement->id}}" type="text"
                                  inputmode="numeric" size="w-full"
                                  x-on:input="event.target.value = event.target.value.replace(/[^0-9]/g, '')"
                                  :unit="__('phrases.amd')"
                                  x-on:blur="event.target.value = window.numberFormat(event.target.value.replace(/[^0-9]/g, ''))"
                                  wire:model.blur="applied_improvement_data.{{$improvement->id}}.total"/>
                </div>
                @error('applied_improvement_data.'.$improvement->id.'.total')
                <p class="text-red-500 text-xs mt-2 text-right">{{ $message }}</p>
                @enderror
            </div>
        @endif
    </div>
</div>
