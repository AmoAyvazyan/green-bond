@props(['improvement' => null])
<div>
    <div class="grid grid-cols-1 lg:grid-cols-3 lg:gap-x-8 gap-y-8 lg:gap-y-0">
        @if($improvement->has_quantity)
            <div>
                <div
                    class="flex flex-col items-start lg:flex-row lg:items-center justify-start lg:justify-between lg:space-x-6">
                    <x-label class="mb-4 lg:mb-0"
                             for="quantity_{{$improvement->id}}">{{__('phrases.quantity')}}</x-label>
                    <x-input-unit id="quantity_{{$improvement->id}}" type="text"
                                  inputmode="numeric"
                                  x-on:input="event.target.value = event.target.value.replace(/[^0-9]/g, '')"
                                  :unit="__('phrases.pcs')"
                                  wire:model.blur="applied_ee_improvement_data.{{$improvement->id}}.quantity"/>
                </div>
                @error('applied_ee_improvement_data.'.$improvement->id.'.quantity')
                <p class="text-red-500 text-xs mt-2 text-right">{{ $message }}</p>
                @enderror
            </div>
        @endif
        @if($improvement->has_power)
            <div>
                <div
                    class="flex flex-col items-start lg:flex-row lg:items-center justify-start lg:justify-between lg:space-x-6">
                    <x-label class="mb-4 lg:mb-0"
                             for="power_{{$improvement->id}}">{{__('phrases.power')}}</x-label>
                    <x-input-unit id="power_{{$improvement->id}}" type="tex"
                                  inputmode="numeric"
                                  x-on:input="event.target.value = event.target.value.replace('․', '.').replace(/[^0-9.,]/g, '')"
                                  :unit="$improvement->slug === \App\Models\EeImprovement::SLUG_LIGHTING ? __('phrases.Wt') :__('phrases.kWt')"
                                  wire:model.blur="applied_ee_improvement_data.{{$improvement->id}}.power"/>
                </div>
                @error('applied_ee_improvement_data.'.$improvement->id.'.power')
                <p class="text-red-500 text-xs mt-2 text-right">{{ $message }}</p>
                @enderror
            </div>
        @endif
        @if($improvement->has_area)
            <div>
                <div
                    class="flex flex-col items-start lg:flex-row lg:items-center justify-start lg:justify-between lg:space-x-6">
                    <x-label class="mb-4 lg:mb-0"
                             for="area_{{$improvement->id}}">{{__('phrases.area')}}</x-label>
                    <x-input-unit id="area_{{$improvement->id}}" type="text"
                                  :unit="__('phrases.sqm')" inputmode="numeric"
                                  x-on:input="event.target.value = event.target.value.replace(/[,․,]/g, '.').replace(/[^0-9.]/g, '')"
                                  wire:model.blur="applied_ee_improvement_data.{{$improvement->id}}.area"/>
                </div>
                @error('applied_ee_improvement_data.'.$improvement->id.'.area')
                <p class="text-red-500 text-xs mt-2 text-right">{{ $message }}</p>
                @enderror
            </div>
        @endif
        @if($improvement->has_volume)
            <div class="lg:col-span-2">
                <div
                    class="flex flex-col items-start lg:flex-row lg:items-center justify-start lg:justify-between lg:space-x-6">
                    <x-label class="mb-4 lg:mb-0 lg:whitespace-nowrap"
                             for="volume_{{$improvement->id}}">{{__('phrases.volume')}}</x-label>
                    <x-input-unit id="volume_{{$improvement->id}}" type="text"
                                  :unit="__('phrases.liter')" inputmode="numeric"
                                  x-on:input="event.target.value = event.target.value.replace(/[^0-9]/g, '')"
                                  wire:model.blur="applied_ee_improvement_data.{{$improvement->id}}.volume"/>
                </div>
                @error('applied_ee_improvement_data.'.$improvement->id.'.volume')
                <p class="text-red-500 text-xs mt-2 text-right">{{ $message }}</p>
                @enderror
            </div>
        @endif
        @if($improvement->has_thickness)
            <div>
                <div
                    class="flex flex-col items-start lg:flex-row lg:items-center justify-start lg:justify-between lg:space-x-6">
                    <x-label class="mb-4 lg:mb-0"
                             for="volume_{{$improvement->id}}">{{__('phrases.thickness')}}</x-label>
                    <x-input-unit id="volume_{{$improvement->id}}" type="text"
                                  :unit="__('phrases.cm')" inputmode="numeric"
                                  x-on:input="event.target.value = event.target.value.replace('․', '.').replace(/[^0-9.,]/g, '')"
                                  wire:model.blur="applied_ee_improvement_data.{{$improvement->id}}.thickness"/>
                </div>
                @error('applied_ee_improvement_data.'.$improvement->id.'.thickness')
                <p class="text-red-500 text-xs mt-2 text-right">{{ $message }}</p>
                @enderror
            </div>
        @endif
        @if($improvement->has_price)
            <div>
                <div
                    class="flex flex-col items-start lg:flex-row lg:items-center justify-start lg:justify-between lg:space-x-6">
                    <x-label class="mb-4 lg:mb-0 whitespace-nowrap"
                             for="cost_{{$improvement->id}}">{{($improvement->has_volume || (!$improvement->has_quantity && !$improvement->has_area)) ? __('phrases.system_price') : __('phrases.price_one')}}</x-label>
                    <x-input-unit id="cost_{{$improvement->id}}" type="text"
                                  inputmode="numeric"
                                  x-on:input="event.target.value = event.target.value.replace(/[^0-9]/g, '')"
                                  :unit="__('phrases.amd')"
                                  x-on:blur="event.target.value = window.numberFormat(event.target.value.replace(/[^0-9]/g, ''))"
                                  wire:model.blur="applied_ee_improvement_data.{{$improvement->id}}.price"/>
                </div>
                @error('applied_ee_improvement_data.'.$improvement->id.'.price')
                <p class="text-red-500 text-xs mt-2 text-right">{{ $message }}</p>
                @enderror
            </div>
        @endif
    </div>
    @if($improvement->materials->isNotEmpty())
        <p class="mt-12 mb-6 text-black">{{__('phrases.material')}}</p>
        <div class="flex flex-wrap items-center max-w-[70%]"
             x-data="{@foreach($improvement->materials as $material) showMaterialPic_{{$improvement->id}}_{{$material->id}}: false, @endforeach}"
        >
            @foreach($improvement->materials as $material)
                <label for="material_{{$improvement->id}}_{{$material->id}}"
                       class="flex mr-2 mb-2 rounded-2xl border p-2 xs:p-4 items-center justify-center
                                              {{$applied_ee_improvement_data[$improvement->id]['material'] == $material->id
                                                    ? 'border-green-500 bg-white text-black'
                                                    : 'border-gray-400 text-gray-500 cursor-pointer'}}"
                       x-on:mouseenter="showMaterialPic_{{$improvement->id}}_{{$material->id}} = true"
                       x-on:mouseleave="showMaterialPic_{{$improvement->id}}_{{$material->id}} = false"
                >
                    {{$material->name}}
                </label>
                <input
                    class="hidden" value="{{$material->id}}" type="radio"
                    id="material_{{$improvement->id}}_{{$material->id}}">
                <div x-cloak
                     x-show="showMaterialPic_{{$improvement->id}}_{{$material->id}}"
                     class="absolute right-1 top-1 rounded-xl p-2 bg-white shadow-md w-[250px] md:w-[400px] h-[300px]">
                    <img data-src="{{$material->image}}" class="lazyload w-full h-full object-cover object-center rounded-xl"
                         alt="{{$material->name}}">
                </div>
            @endforeach
        </div>
        @error('applied_ee_improvement_data.'.$improvement->id.'.material')
        <p class="text-red-500 text-xs mt-2">{{ $message }}</p>
        @enderror
    @endif
    <div class="flex items-center space-x-2 mt-12">
        <div class="border-b border-gray-400 w-full"></div>
        <span class="text-gray-400 whitespace-nowrap">{{__('phrases.total_amount')}} <span
                class="text-black">{{number_format((float)(($applied_ee_improvement_data[$improvement->id]['quantity']
                                                        ?: $applied_ee_improvement_data[$improvement->id]['area']) ?: 1)
                                                        * (int) preg_replace("/[^0-9]/", '', $applied_ee_improvement_data[$improvement->id]['price']), 0, '.', ' ')}}</span> {{__('phrases.amd')}}</span>
        <div class="border-b border-gray-400 w-full"></div>
    </div>
</div>
