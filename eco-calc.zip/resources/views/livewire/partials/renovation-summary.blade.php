<div class="rounded-3xl bg-white p-3 text-gray-500 shadow-md sticky top-[150px]">
    <div class="flex flex-col space-y-6 p-3 mb-3 text-gray-500">
        <p><strong>{{$this->eeAmountPercent}}%</strong> {{__('loan.ee_measures')}}</p>
        <p><strong>{{$this->totalAmount > 0 ? 100 - $this->eeAmountPercent : 0}}%</strong> {{__('loan.non_ee_measures')}}</p>
        <p><strong>{{$this->householdAppliancesSumPercent}}%</strong> {{__('loan.household_appliances')}}</p>
        <p>{{__('phrases.co2_reduction')}}{{__('phrases.colon')}}
            <strong>{{round(array_sum(array_column(array_column($applied_ee_improvement_data, 'savings'),'co2')), 2)}}</strong>
            {{__('phrases.tons_year')}}
        </p>
        <p>{{__('phrases.energy_savings')}}{{__('phrases.colon')}}
            <strong>{{round(array_sum(array_column(array_column($applied_ee_improvement_data, 'savings'), 'energy')))}}</strong>
            {{__('phrases.kWh_year')}}
        </p>
    </div>
    <div class="border border-gray-200 rounded-t-2xl p-3 text-black">
        <p class="text-lg mb-1">{{__('phrases.total_ee')}}{{__('phrases.colon')}}</p>
        <p class="text-right text-green-500 text-4xl font-bold">{{number_format($this->getTotalEeAmount(),0,'.', ' ')}} {{__('phrases.amd')}}</p>
    </div>
    <div class="border border-t-0 border-gray-200 rounded-b-2xl text-black p-3 mb-3">
        <p class="text-lg mb-1">{{__('phrases.total_non_ee')}}{{__('phrases.colon')}}</p>
        <p class="text-right text-4xl font-bold">{{number_format($this->totalAmount - $this->getTotalEeAmount(),0,'.', ' ')}} {{__('phrases.amd')}}</p>
    </div>
    <div class="bg-black rounded-t-2xl p-3 text-white">
        <p class="text-lg mb-1">{{__('phrases.total_calculation')}}{{__('phrases.colon')}}</p>
        <p class="text-right text-4xl font-bold">{{number_format($this->totalAmount,0,'.', ' ')}} {{__('phrases.amd')}}</p>
    </div>
    @if($this->isLoanTypeGreen)
        <div class="rounded-b-2xl text-white p-3 bg-green-500">
            <p>{{__('phrases.loan_type')}}{{__('phrases.colon')}}
                {{__('phrases.loan_type_green')}}
            </p>
        </div>
    @elseif($this->isLoanTypeEe)
        <div class="rounded-b-2xl text-black p-3 bg-green-400">
            <p>{{__('phrases.loan_type')}}{{__('phrases.colon')}}
                {{__('phrases.loan_type_ee')}}
            </p>
        </div>
    @elseif($this->isLoanTypeStandard)
        <div
            class="rounded-b-2xl text-white p-3 bg-yellow-500">
            <p>{{__('phrases.loan_type')}}{{__('phrases.colon')}}
                {{__('phrases.loan_type_standard')}}
            </p>
        </div>
    @else
        <div
            class="rounded-b-2xl text-white p-3 bg-red-500">
            <p>{{__('phrases.loan_type')}}{{__('phrases.colon')}}
                {{__('phrases.loan_type_nok')}}
            </p>
        </div>
    @endif
</div>