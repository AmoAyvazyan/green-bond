<div class="rounded-3xl bg-white p-3 text-gray-500 shadow-md sticky top-[150px]">
    <div class="flex flex-col space-y-6 text-gray-500 mb-6">
        <div class="border border-green-500 rounded-2xl flex flex-col space-y-6 p-3">
            <h2 class="text-green-500 text-center text-xs font-medium bg-white -mt-5 px-1 w-[max-content] self-center">{{__('phrases.events')}}</h2>
            <div class="flex space-x-2">
                <span>{{__('phrases.walls_insulation_thickness')}}{{__('phrases.colon')}}</span>
                @if (($applied_ee_improvement_data[$wallInsulationId]['thickness'] ?? 0) >= 5)
                    <span class="text-green-500 font-bold h-6 w-auto"><x-heroicon-o-check class="h-6 w-auto"/></span>
                @else
                    <span class="text-red-500 font-bold">&#60; 5</span>
                @endif
            </div>
            <div class="flex space-x-2">
                <span>{{__('phrases.roof_insulation_thickness')}}{{__('phrases.colon')}}</span>
                @if (($applied_ee_improvement_data[$roofInsulationId]['thickness'] ?? 0) >= 15)
                    <span class="text-green-500 font-bold h-6 w-auto"><x-heroicon-o-check class="h-6 w-auto"/></span>
                @else
                    <span class="text-red-500 font-bold h-6 w-auto">&#60; 15</span>
                @endif
            </div>
            <div class="flex space-x-2">
                <span>{{__('phrases.windows_installation')}}{{__('phrases.colon')}}</span>
                @if (($applied_ee_improvement_data[$windowsInstallId]['area'] ?? 0) > 0)
                    <span class="text-green-500 font-bold h-6 w-auto"><x-heroicon-o-check class="h-6 w-auto"/></span>
                @else
                    <span class="text-red-500 font-bold h-6 w-auto"><x-heroicon-o-x-mark class="h-6 w-auto"/></span>
                @endif
            </div>
            <div class="flex space-x-2">
                <span>{{__('phrases.door_installation')}}{{__('phrases.colon')}}</span>
                @if (($applied_ee_improvement_data[$doorInstallId]['area'] ?? 0) > 0)
                    <span class="text-green-500 font-bold h-6 w-auto"><x-heroicon-o-check class="h-6 w-auto"/></span>
                @else
                    <span class="text-red-500 font-bold h-6 w-auto"><x-heroicon-o-x-mark class="h-6 w-auto"/></span>
                @endif
            </div>
        </div>
        <p class="px-3">{{__('phrases.co2_reduction')}}
            <strong>{{round(array_sum(array_column(array_column($applied_ee_improvement_data, 'savings'),'co2')), 2)}}</strong>
            {{__('phrases.tons_year')}}
        </p>
        <p class="px-3">{{__('phrases.energy_savings')}}
            <strong>{{round(array_sum(array_column(array_column($applied_ee_improvement_data, 'savings'), 'energy')))}}</strong>
            {{__('phrases.kWh_year')}}
        </p>
    </div>
    <div class="bg-black rounded-t-2xl p-3 text-white">
        <p class="text-lg mb-1">{{__('phrases.total_calculation')}}{{__('phrases.colon')}}</p>
        <p class="text-right text-4xl font-bold">{{number_format($this->totalAmount,0,'.', ' ')}} {{__('phrases.amd')}}</p>
    </div>
    @if($this->isLoanTypeGreen)
        <div class="rounded-b-2xl text-white p-3 bg-green-500">
            <p>{{__('phrases.loan_type')}}{{__('phrases.colon')}}
                {{__('phrases.loan_type_green')}}
            </p>
        </div>
    @elseif($this->isLoanTypeStandard)
        <div
            class="rounded-b-2xl text-yellow-500 p-3 border-yellow-500">
            <p>{{__('phrases.loan_type')}}{{__('phrases.colon')}}
                {{__('phrases.loan_type_standard')}}
            </p>
        </div>
    @elseif($this->isLoanTypeNonStandard)
        <div
            class="rounded-b-2xl text-white p-3 bg-yellow-500">
            <p>{{__('phrases.loan_type')}}{{__('phrases.colon')}}
                {{__('phrases.loan_type_non_standard')}}
            </p>
        </div>
    @else
        <div
            class="rounded-b-2xl text-white p-3 bg-red-500">
            <p>{{__('phrases.loan_type')}}{{__('phrases.colon')}}
                {{__('phrases.loan_type_nok')}}
            </p>
        </div>
    @endif
</div>