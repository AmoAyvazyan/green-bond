<div class="py-8 lg:py-16">
    @if(!$isDownloaded)
        <x-container>
            <div class="grid grid-cols-1 lg:grid-cols-3 lg:gap-x-6">
                <div class="col-span-full grid grid-cols-1 lg:grid-cols-3 lg:gap-x-6">
                    <div class="col-span-2">
                        <x-notice type="warning" aria-role="notice" class="mb-6">
                            {!! __('phrases.mortgage_notice_warning') !!}
                        </x-notice>
                    </div>
                    <div></div>
                    <div class="col-span-2">
                        <x-notice type="warning" aria-role="notice" class="mb-6">
                            {!! __('phrases.step_1_notice', ['url' => route('front.terms.privacy-policy')]) !!}
                        </x-notice>
                    </div>
                    <div></div>
                </div>
                <div class="col-span-2 mb-6 lg:mb-0">
                    <div class="flex flex-col space-y-6 lg:space-y-0 lg:grid grid-cols-1 lg:grid-cols-2 lg:bg-gray-50
                        rounded-2xl lg:shadow-md lg:p-8 lg:gap-8">
                        <div>
                            <x-label for="loaner_first_name" class="mb-4" :value="__('phrases.first_name').' *'"/>
                            <x-input wire:model="loaner_first_name" id="loaner_first_name" class="block w-full" type="text"
                                     name="loaner_first_name" required autofocus/>
                            @error('loaner_first_name')
                            <p class="text-red-500 text-xs mt-2">{{ $message }}</p>
                            @enderror
                        </div>
                        <div>
                            <x-label for="loaner_last_name" class="mb-4" :value="__('phrases.last_name').' *'"/>
                            <x-input wire:model="loaner_last_name" id="loaner_last_name" class="block w-full" type="text"
                                     name="loaner_last_name" required/>
                            @error('loaner_last_name')
                            <p class="text-red-500 text-xs mt-2">{{ $message }}</p>
                            @enderror
                        </div>
                        <div>
                            <x-label for="location_region" class="mb-4" :value="__('phrases.property_location')"/>
                            <x-custom-select x-on:change="$wire.updateRegions(window.tomSelects['location_region'].getValue())"
                                             multiple="true" class="tag-select" id="location_region"
                                             data-placeholder="{{__('phrases.select_region')}}" name="selected_regions[]">
                                @foreach($regions as $region)
                                    <option value="{{$region->id}}">{{$region->name}}</option>
                                @endforeach
                            </x-custom-select>
                        </div>
                        <div>
                            <x-label for="location_community" class="mb-4 lg:text-transparent"
                                     :value="__('phrases.select_community')"/>
                            <x-custom-wire-select
                                x-on:change="$wire.updateCommunities(window.tomSelects['location_community'].getValue())"
                                multiple="true" class="tag-select" id="location_community"
                                :disabled="$communitiesByRegion->isEmpty() ? 'disabled' : ''"
                                data-placeholder="{{__('phrases.select_community')}}" name="selected_communities[]">
                                @foreach($communitiesByRegion as $region)
                                    <optgroup label="{{$region->name}}">
                                        @foreach($region->communities as $community)
                                            <option {{in_array($community->id, $selectedCommunities) ? 'selected' : ''}}
                                                    value="{{$community->id}}">{{$community->name}}</option>
                                        @endforeach
                                    </optgroup>
                                @endforeach
                            </x-custom-wire-select>
                        </div>
                        <div class="lg:col-span-2">
                            <x-label for="property_address" class="mb-4" :value="__('phrases.address').' *'"/>
                            <x-custom-wire-select
                                x-on:change="$wire.updateComplex(window.tomSelects['property_address'].getValue())"
                                id="property_address" name="property_address"
                                data-placeholder="{{__('phrases.select_complex')}}">
                                <option selected disabled value="">{{__('phrases.select_complex')}}</option>
                                @forelse($complexes as $complex)
                                    <option {{$selectedComplex?->is($complex) ? 'selected' : ''}} value="{{$complex->id}}"
                                            aria-label="{{$complex->address}}">{{$complex->address_new ?? $complex->address }}
                                        {{$complex->name ? " ({$complex->name})" : ''}}</option>
                                @empty
                                    <option selected disabled>{{__('phrases.no_complexes')}}</option>
                                @endforelse
                            </x-custom-wire-select>
                            @error('selectedComplex')
                            <p class="text-red-500 text-xs mt-2">{{ $message }}</p>
                            @enderror
                        </div>
                        <div class="grid grid-cols-1 lg:grid-cols-2 gap-4 lg:items-center">
                            <x-label for="selected_building" :value="__('phrases.complex_building').' *'"/>
                            <x-select wire:model.live="selectedBuildingId" id="selected_building" class="w-full">
                                <option selected value="0">...</option>
                                @forelse($selectedComplex?->buildings ?? [] as $building)
                                    <option value="{{$building->id}}">{{$building->title}}</option>
                                @empty
                                @endforelse
                            </x-select>
                            @error('selectedBuilding')
                            <p class="text-red-500 col-span-full text-xs mt-2">{{ $message }}</p>
                            @enderror
                        </div>
                        <div class="flex justify-between items-center space-x-4">
                            <span class="text-black">{{__('phrases.ee_class')}}</span>
                            <span
                                class="h-13 flex items-center justify-center bg-gray-200 text-black font-bold rounded-2xl shadow-md min-w-[150px]">
                        {{$selectedBuilding?->ee_class ?? '--'}}
                    </span>
                        </div>
                        <div class="grid grid-cols-1 lg:grid-cols-2 gap-4 lg:items-center">
                            <x-label for="apartment_number" :value="__('phrases.apartment_number').' *'"/>
                            <x-input wire:model="apartment_number" inputmode="numeric" id="apartment_number" class="w-full"/>
                            @error('apartment_number')
                            <p class="text-red-500 col-span-full text-xs mt-2">{{ $message }}</p>
                            @enderror
                        </div>
                        <div class="grid grid-cols-1 lg:grid-cols-2 gap-4 lg:items-center">
                            <x-label for="area" :value="__('phrases.total_area').' *'"/>
                            <x-input-unit inputmode="numeric" pattern="[0-9]*\.?[0-9]*"
                                          :disabled="!$selectedBuilding || !$selectedComplex"
                                          x-on:input="event.target.value = event.target.value.replace(/[^0-9.]/g, '')"
                                          wire:model.blur="area" id="area" class="w-full"
                                          :unit="__('phrases.sqm')"/>
                            @error('area')
                            <p class="text-red-500 col-span-full text-xs mt-2">{{ $message }}</p>
                            @enderror
                        </div>
                        <div class="col-span-2 hidden lg:flex items-center justify-center">
                            <x-btn :wire:loading.attr="'disabled'"
                                   size="sm" color="green" wire:click="downloadReport" class="justify-between mt-12 space-x-4">
                                <span>{{__('buttons.download_all')}}</span>
                                <x-icons.download class="size-6"/>
                            </x-btn>
                        </div>
                    </div>
                </div>
                <aside class="flex flex-col justify-between space-y-6">
                    <div class="rounded-2xl bg-white p-4 text-gray-500 shadow-md">
                        <p class="mb-4">
                            {{__('phrases.co2_reduction')}}{{__('phrases.colon')}}
                            <strong class="text-black">{{$co2Reduction ?? 0}}</strong> {{__('phrases.tons_year')}}
                        </p>
                        <p>
                            {{__('phrases.energy_savings')}}{{__('phrases.colon')}}
                            <strong class="text-black">{{$energySavings ?? 0}}</strong> {{__('phrases.kWh_year')}}
                        </p>
                    </div>
                    <x-notice type="error" aria-role="notice">
                        {{__('phrases.mortgage_notice_error')}}
                    </x-notice>
                    <div class="lg:hidden flex items-center justify-center">
                        <x-btn :wire:loading.attr="'disabled'"
                               size="sm" color="green" wire:click="downloadReport" class="justify-between mt-6 space-x-4">
                            <span>{{__('buttons.download_all')}}</span>
                            <x-icons.download class="size-6"/>
                        </x-btn>
                    </div>
                </aside>
            </div>
        </x-container>
    @else
        <x-container class="calculation-step">
            <div class="rounded-4xl bg-gray-50 p-2 sm:p-4 lg:p-8 flex flex-col items-center justify-center min-h-[300px]">
                <h2 class="font-bold text-xl xs:text-2xl text-black mb-12">{{__('phrases.final_title')}}</h2>
                <x-btn color="green" class="space-x-4 md:space-x-6" x-on:click="location.replace('/')">{{__('buttons.back')}}</x-btn>
            </div>
        </x-container>
    @endif
</div>
@script
<script>
    if (window.Livewire) {
        Livewire.hook('morph.updated', ({el, component}) => {
            if (el.classList.contains('custom-select')) {
                // window.initCustomSelects([el]);
                setTimeout(() => {
                    window.initCustomSelects([el]);
                    el.tomselect.sync();
                }, 1);
            }
        });
    }
</script>
@endscript
