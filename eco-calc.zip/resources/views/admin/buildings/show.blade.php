@section('title', 'Building Details')
@section('button-class','flex justify-between items-center pb-1')
@section('button')
    <x-btn :link="true" color="green" href="{{route('back-office.buildings.edit', $building)}}">Edit</x-btn>
@endsection
<x-admin-layout>
    <x-card>
        <x-detail-row label="Title">
            @foreach($building->translations as $translation)
                {{$translation->title}}
                <span class="text-gray-500">|</span>
            @endforeach
        </x-detail-row>
        <x-detail-row label="Complex">
            <x-link href="{{route('back-office.residential-complexes.show', $complex)}}">
                @foreach($complex->translations as $translation)
                    {{$translation->name}}
                    <span class="text-gray-500">|</span>
                @endforeach
            </x-link>
        </x-detail-row>
        <x-detail-row label="EE Class"> {{$building->ee_class}} </x-detail-row>
        <x-detail-row label="Energy Passport">
            <x-link target="_blank" href=" {{$building->energy_passport}}">
                {{$building->energy_passport}}
            </x-link>
        </x-detail-row>
        <x-detail-row label="HDD"> {{$building->hdd}} </x-detail-row>
        <x-detail-row label="Floors"> {{$building->floors}} </x-detail-row>
        <x-detail-row label="Surface area"> {{$building->surface_area}} </x-detail-row>
        <x-detail-row label="Heated volume"> {{$building->heated_volume}} </x-detail-row>
        <x-detail-row label="Heating ventilation pf"> {{$building->heating_ventilation_pf}} </x-detail-row>
        <x-detail-row label="Created">
            {{$building->created_at->timezone(config('app.timezone'))->format('d.m.Y H:i:s')}}
        </x-detail-row>
        <x-detail-row label="Modified" :last="true">
            {{$building->updated_at->timezone(config('app.timezone'))->format('d.m.Y H:i:s')}}
        </x-detail-row>
    </x-card>
    @include('partials.show-actions', [
        'resource' => 'buildings',
        'permission' => 'delete-settings',
        'model' => $building,
    ])
</x-admin-layout>