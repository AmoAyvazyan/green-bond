@php /** @var $building \App\Models\Building */ @endphp
<x-card>
    <div class="grid grid-cols-1 md:grid-cols-2 gap-x-10 gap-y-5">
        @if($errors->count()>0)
            <div class="col-span-full">
                <!-- Validation Errors -->
                <x-validation-errors class="mb-4" :errors="$errors"/>
            </div>
        @endif
        <div>
            <x-label for="title" :value="__('Title')"/>
            <x-input id="title" class="block mt-1 w-full" type="text" name="title"
                     :value="isset($building) && $building->translate($currentLocale) ? $building->translate($currentLocale ?? 'en')?->title : old('title')"
                     required/>
        </div>
        <div>
            <x-label for="complex_id" :value="__('Complex')"/>
            <x-custom-select name="complex_id" id="complex_id" class="block mt-1 w-full" required>
                @forelse($complexes as $complex)
                    <option
                        {{($building?->complex->is($complex)
                            || old('complex_id') == $complex->id) ? 'selected' : ''}}
                        value="{{$complex->id}}">{{$complex->translate($currentLocale)?->name ?? $complex->name}}</option>
                @empty
                    <option value="" disabled selected>{{__('There are no any complex')}}</option>
                @endforelse
            </x-custom-select>
        </div>
        <div>
            <x-label for="ee_class" :value="__('EE Class')"/>
            <x-custom-select name="ee_class" id="ee_class" class="block mt-1 w-full">
                @forelse($eeClasses as $eeClass)
                    <option
                        {{$building?->ee_class === $eeClass ? 'selected' : ''}} value="{{$eeClass}}">{{$eeClass}}</option>
                @empty
                    <option value="" disabled selected>{{__('There are no any ee class')}}</option>
                @endforelse
            </x-custom-select>
        </div>
        <div>
            <x-label for="hdd" :value="__('HDD')"/>
            <x-input id="hdd" class="block mt-1 w-full" type="text" name="hdd" required
                     :value="isset($building) ? $building->hdd : old('hdd')"/>
        </div>
            <div>
                <x-label for="floors" :value="__('Floors')"/>
                <x-input id="floors" class="block mt-1 w-full" type="number" name="floors" required
                         :value="isset($building) ? $building->floors : old('floors')"/>
            </div>
            <div>
                <x-label for="surface_area" :value="__('Surface area')"/>
                <x-input id="surface_area" class="block mt-1 w-full" type="text" name="surface_area" required
                         :value="isset($building) ? $building->surface_area : old('surface_area')"/>
            </div>
            <div>
                <x-label for="heated_volume" :value="__('Heated volume')"/>
                <x-input id="heated_volume" class="block mt-1 w-full" type="number" name="heated_volume" required
                         :value="isset($building) ? $building->heated_volume : old('heated_volume')"/>
            </div>
            <div>
                <x-label for="heating_ventilation_pf" :value="__('Heating ventilation pf')"/>
                <x-input id="heating_ventilation_pf" class="block mt-1 w-full" type="text" name="heating_ventilation_pf" required
                         :value="isset($building) ? $building->heating_ventilation_pf : old('heating_ventilation_pf')"/>
            </div>
        <div>
            <x-label for="energy_passport" :value="__('Energy Passport')"/>
            @if($building && $building->energy_passport)
                <div class="flex items-center justify-between">
                    <x-input-file id="energy_passport" name="energy_passport" class="w-full" :value="__('Edit file')"/>
                    <x-link class="ml-1" target="_blank" href="{{$building->energy_passport}}">View</x-link>
                </div>
            @else
                <x-input-file id="energy_passport" name="energy_passport" class="" :value="__('Upload file')"/>
            @endif
        </div>
    </div>
</x-card>
<div class="flex justify-between items-center">
    <x-btn color="gray" :link="true" href="{{back()->getTargetUrl()}}">{{__('Back')}}</x-btn>
    <x-btn color="green">{{__('Save')}}</x-btn>
</div>