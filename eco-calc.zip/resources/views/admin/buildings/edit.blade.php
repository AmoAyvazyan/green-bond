@section('title',__('Edit Building'))
@section('select-class', 'flex justify-between items-center')
@section('select')
    <x-select onchange="location.replace('{{route('back-office.buildings.edit',$building)}}' + '?locale=' + this.value)"
              name="translation_locale" id="translation_locale" form="editForm">
        @foreach($locales as $code=>$locale)
            <option {{$currentLocale===$code?'selected':''}} value="{{$code}}">{{$locale['native']}}</option>
        @endforeach
    </x-select>
@endsection
<x-admin-layout>
    <form id="editForm" enctype="multipart/form-data" method="POST"
          action="{{route('back-office.buildings.update',$building)}}">
        @csrf
        @method('put')
        @include('admin.buildings.partials.form_main')
    </form>
</x-admin-layout>