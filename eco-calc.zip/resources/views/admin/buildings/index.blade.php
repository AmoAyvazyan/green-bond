@section('title',__('Buildings'))
@section('button-class','flex justify-between items-center pb-1')
@section('button')
    <x-btn :link="true" color="green" href="{{route('back-office.buildings.create')}}">Add Building</x-btn>
@endsection
<x-admin-layout>
    <livewire:tables.buildings-table/>
    <hr>
    <div class="flex justify-end items-center mt-5">
        <x-btn :link="true" color="green" href="{{route('back-office.buildings.create')}}">Add Building</x-btn>
    </div>
</x-admin-layout>