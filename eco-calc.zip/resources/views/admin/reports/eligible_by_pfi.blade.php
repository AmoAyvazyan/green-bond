@section('title',__('Breakdown of Eligible Loans by PFI'))
<x-admin-layout>
    <livewire:reports.eligible-by-pfi-report-table/>
</x-admin-layout>