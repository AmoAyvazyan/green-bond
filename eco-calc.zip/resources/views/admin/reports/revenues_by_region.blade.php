@section('title',__('Breakdown of average revenues by Region'))
<x-admin-layout>
    <livewire:reports.revenues-by-region-report-table/>
</x-admin-layout>