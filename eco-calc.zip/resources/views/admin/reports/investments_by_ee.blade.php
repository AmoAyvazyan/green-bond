@section('title',__('Investments by EE Technology type'))
<x-admin-layout>
    <livewire:reports.investments-by-ee-report-table/>
</x-admin-layout>