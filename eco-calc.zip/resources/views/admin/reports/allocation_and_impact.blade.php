@section('title',__('Green Bond Allocation and Impact Report '))
<x-admin-layout>
    <livewire:reports.allocation-and-impact-report-table/>
</x-admin-layout>