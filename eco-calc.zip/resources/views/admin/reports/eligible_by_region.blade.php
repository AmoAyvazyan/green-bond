@section('title',__('Breakdown of Eligible Loans by Region'))
<x-admin-layout>
    <livewire:reports.eligible-by-region-report-table/>
</x-admin-layout>