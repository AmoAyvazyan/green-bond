@section('title',__('Breakdown of Eligible Loans by Sex'))
<x-admin-layout>
    <livewire:reports.eligible-by-sex-report-table/>
</x-admin-layout>