@section('title',__('Breakdown of Eligible Loans by Month'))
<x-admin-layout>
    <livewire:reports.eligible-by-month-report-table/>
</x-admin-layout>