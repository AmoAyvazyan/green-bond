@php /** @var $material \App\Models\Material */ @endphp
<x-card>
    <div class="grid grid-cols-1 md:grid-cols-2 gap-x-10 gap-y-5">
        @if($errors->count()>0)
            <div class="col-span-full">
                <!-- Validation Errors -->
                <x-validation-errors class="mb-4" :errors="$errors"/>
            </div>
        @endif
        <div>
            <x-label for="name" :value="__('Name')"/>
            <x-input id="name" data-lang="{{$currentLocale ?? 'en'}}" class="block mt-1 w-full" type="text" name="name"
                     :value="isset($material) && $material->translate($currentLocale) ? $material->translate($currentLocale ?? 'en')?->name : old('name')"
                     required/>
        </div>
        <div>
            <x-label for="slug" :value="__('Slug')"/>
            <x-input id="slug" class="block mt-1 w-full" type="text" name="slug" required
                     data-new="{{isset($material) ? 'false' : 'true'}}"
                     :value="isset($material) ? $material->slug : old('slug')"/>
        </div>
        <div>
            <x-label for="image" :value="__('Image (min: 580x380)')"/>
            @isset($material)
                <div class="flex items-center justify-between">
                    <x-input-file id="image" name="image" class="w-full" :value="__('Edit image')"/>
                    <a target="_blank" href="{{$material->image}}"><img
                            class="w-10 h-10 object-cover object-center rounded shadow-md ml-2"
                            src="{{$material->image}}" alt="{{$material->image}}"></a>
                </div>
            @else
                <x-input-file id="image" name="image" class="" :value="__('Upload image')"/>
            @endif
        </div>
        <div class="col-span-full flex">
            <div class="items-center">
                <x-checkbox value="1" :checked="$material->is_active??old('is_active')" name="is_active" id="is_active"
                            class="block ms-4 mt-5 mr-8">{{__('Active')}}</x-checkbox>
            </div>
        </div>
    </div>
</x-card>
<div class="flex justify-between items-center">
    <x-btn color="gray" :link="true" href="{{back()->getTargetUrl()}}">{{__('Back')}}</x-btn>
    <x-btn color="green">{{__('Save')}}</x-btn>
</div>