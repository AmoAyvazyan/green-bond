@section('title', 'Materials Details')
@section('button-class','flex justify-between items-center pb-1')
@section('button')
    <x-btn :link="true" color="green" href="{{route('back-office.materials.edit', $material)}}">Edit</x-btn>
@endsection
<x-admin-layout>
    <x-card>
        <x-detail-row label="Slug"> {{$material->slug}} </x-detail-row>
        <x-detail-row label="Material Image">
            <a target="_blank" class="cursor-pointer" href="{{$material->image}}">
                <img src="{{$material->image}}" alt=""
                     class="rounded w-24">
            </a>
        </x-detail-row>
        <x-detail-row label="Name">
            @foreach($material->translations as $translation)
                {{$translation->name}}
                <span class="text-gray-500">|</span>
            @endforeach
        </x-detail-row>
        <x-detail-row label="Active">
            @if($material->is_active)
                <x-heroicon-o-check-circle class="w-5 h-5 text-green-500"/>
            @else
                <x-heroicon-o-no-symbol class="w-5 h-5 text-red-500"/>
            @endif
        </x-detail-row>
        <x-detail-row label="Created">
            {{$material->created_at->timezone(config('app.timezone'))->format('d.m.Y H:i:s')}}
        </x-detail-row>
        <x-detail-row label="Modified" :last="true">
            {{$material->updated_at->timezone(config('app.timezone'))->format('d.m.Y H:i:s')}}
        </x-detail-row>
    </x-card>
    @include('partials.show-actions', [
        'resource' => 'materials',
        'permission' => 'delete-settings',
        'model' => $material,
    ])
</x-admin-layout>