@section('title',__('Materials'))
@section('button-class','flex justify-between items-center pb-1')
@section('button')
    <x-btn :link="true" color="green" href="{{route('back-office.materials.create')}}">Add Materials</x-btn>
@endsection
<x-admin-layout>
    <livewire:tables.material-table/>
    <hr>
    <div class="flex justify-end items-center mt-5">
        <x-btn :link="true" color="green" href="{{route('back-office.materials.create')}}">Add Materials</x-btn>
    </div>
</x-admin-layout>