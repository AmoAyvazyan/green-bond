@section('title',__('Edit Materials'))
@section('select-class', 'flex justify-between items-center')
@section('select')
    <x-select onchange="location.replace('{{route('back-office.materials.edit',$material)}}' + '?locale=' + this.value)"
              name="translation_locale" id="translation_locale" form="editForm">
        @foreach($locales as $code=>$locale)
            <option {{$currentLocale===$code?'selected':''}} value="{{$code}}">{{$locale['native']}}</option>
        @endforeach
    </x-select>
@endsection
<x-admin-layout>
    <form id="editForm" enctype="multipart/form-data" method="POST"
          action="{{route('back-office.materials.update',$material)}}">
        @csrf
        @method('put')
        @include('admin.materials.partials.form_main')
    </form>
</x-admin-layout>