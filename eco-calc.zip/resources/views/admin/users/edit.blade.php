@section('title',__('Edit User'))
<x-admin-layout>
    <form id="editForm" enctype="multipart/form-data" method="POST" action="{{route('back-office.users.update',$user)}}">
        @csrf
        @method('put')
        @include('admin.users.partials.form_main')
    </form>
</x-admin-layout>
