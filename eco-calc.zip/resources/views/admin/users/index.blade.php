@section('title',__('Users'))
@section('button-class','flex justify-between items-center pb-1')
@section('button')
    <x-btn :link="true" color="green" href="{{route('back-office.users.create')}}">Add User</x-btn>
@endsection
<x-admin-layout>
    <livewire:tables.users-table/>
    <hr>
    <div class="flex justify-end items-center mt-5">
        <x-btn :link="true" color="green" href="{{route('back-office.users.create')}}">Add User</x-btn>
    </div>
</x-admin-layout>
