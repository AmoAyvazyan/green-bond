@section('title', 'User Details')
@section('button-class','flex justify-between items-center pb-1')
@section('button')
    <x-btn :link="true" color="green" href="{{route('back-office.users.edit', $user)}}">Edit</x-btn>
@endsection
<x-admin-layout>
    <x-card>
        <x-detail-row label="Avatar">
            <a target="_blank" class="cursor-pointer" href="{{$user->avatar}}">
                <img src="{{$user->avatar}}" alt="{{$user->full_name}}"
                     class="rounded-full w-6 h-6 object-cover object-center">
            </a>
        </x-detail-row>
        <x-detail-row label="First Name">{{$user->first_name}}</x-detail-row>
        <x-detail-row label="Last Name">{{$user->last_name}}</x-detail-row>
        <x-detail-row label="Email">
            <x-link href="mailto:{{$user->email}}">{{$user->email}}</x-link>
        </x-detail-row>
        <x-detail-row label="Role">{{ucfirst($user->role?->name) ?? 'N/A'}}</x-detail-row>
        <x-detail-row label="Registered">{{$user->created_at->timezone(config('app.timezone'))->format('d.m.Y H:i:s')}}</x-detail-row>
        <x-detail-row label="Modified" :last="true">{{$user->updated_at->timezone(config('app.timezone'))->format('d.m.Y H:i:s')}}</x-detail-row>
    </x-card>
    @include('partials.show-actions', [
        'resource' => 'users',
        'permission' => $user->isAdmin() ? '' : 'delete-users',
        'model' => $user,
    ])
</x-admin-layout>
