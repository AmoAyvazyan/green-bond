@php /** @var $user \App\Models\User */ @endphp
<x-card>
    <div class="grid grid-cols-1 md:grid-cols-2 gap-x-10 gap-y-5">
        @if($errors->count()>0)
            <div class="col-span-full">
                <!-- Validation Errors -->
                <x-validation-errors class="mb-4" :errors="$errors"/>
            </div>
        @endif
        <div>
            <x-label for="first_name" :value="__('First Name')"/>
            <x-input id="first_name" class="block mt-1 w-full" type="text" name="first_name"
                     :value="$user->first_name??old('first_name')" required/>
        </div>
        <div>
            <x-label for="last_name" :value="__('Last Name')"/>
            <x-input id="last_name" class="block mt-1 w-full" type="text" name="last_name"
                     :value="$user->last_name??old('last_name')" required/>
        </div>
        <div>
            <x-label for="email" :value="__('Email')"/>
            <x-input id="email" class="block mt-1 w-full" type="email" name="email" :value="$user->email??old('email')"
                     required/>
        </div>
        <div class="grid grid-cols-2 gap-x-10">
            <div>
                <x-label for="password" :value="__('Password')"/>
                @isset($user)
                    <x-input id="password" class="block mt-1 w-full" type="password" name="password"
                             aria-autocomplete="new-password" autocomplete="new-password"/>
                @else
                    <x-input id="password" class="block mt-1 w-full" type="password" name="password"
                             aria-autocomplete="new-password" autocomplete="new-password" required/>
                @endisset
            </div>
            <div>
                <x-label for="password_confirmation" :value="__('Confirm Password')"/>
                @isset($user)
                    <x-input id="password_confirmation" class="block mt-1 w-full" type="password"
                             name="password_confirmation"
                             aria-autocomplete="off" autocomplete="off"/>
                @else
                    <x-input id="password_confirmation" class="block mt-1 w-full" type="password"
                             name="password_confirmation"
                             aria-autocomplete="off" autocomplete="off" required/>
                @endisset
            </div>
        </div>
        <div>
            <x-label for="avatar" :value="__('User Avatar (min: 120x120, max 5 MB)')"/>
            @isset($user)
                <div class="flex items-center justify-between">
                    <x-input-file id="avatar" name="avatar" class="w-full" data-size-limit="{{5*1024*1024}}"
                                  :value="__('Edit image')"/>
                    <a target="_blank" href="{{$user->avatar}}"><img
                            class="w-13 h-13 object-cover object-center rounded shadow-md ml-2" src="{{$user->avatar}}"
                            alt="{{$user->full_name}}"></a>
                </div>
            @else
                <x-input-file id="avatar" name="avatar" class="" data-size-limit="{{5*1024*1024}}"
                              :value="__('Upload image')"/>
            @endisset
        </div>
        @can('manage-roles')
            @if(!isset($user) || !$user->isAdmin())
                <div>
                    <x-label for="role" :value="__('Role')"/>
                    <x-select name="role" id="role" class="block mt-1 w-full">
                        @foreach($roles as $role)
                            @continue($role->name === 'root')
                            <option
                                {{((isset($user) && $user->role && $user->role->is($role)) || old('role') === $role->id)?'selected':''}} value="{{$role->id}}">{{ucfirst($role->name)}}</option>
                        @endforeach
                    </x-select>
                </div>
            @endif
        @endcan
    </div>
</x-card>
<div class="flex justify-between">
    <x-btn color="gray" :link="true" href="{{back()->getTargetUrl()}}">{{__('Back')}}</x-btn>
    <x-btn color="green">{{__('Save')}}</x-btn>
</div>
