@section('title',__('Add User'))
<x-admin-layout>
    <form id="createForm" enctype="multipart/form-data" method="POST" action="{{route('back-office.users.store')}}">
        @csrf
        @include('admin.users.partials.form_main')
    </form>
</x-admin-layout>
