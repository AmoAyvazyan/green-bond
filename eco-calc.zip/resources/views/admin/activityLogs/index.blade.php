@section('title',__('Activity Logs'))
@section('button-class','flex justify-between items-center pb-1')
<x-admin-layout>
    <livewire:tables.activity-log-table/>
</x-admin-layout>