@section('title', 'Activity Log Details')
@section('button-class','flex justify-between items-center pb-1')
<x-admin-layout>
    <x-card>
        <x-detail-row label="Action"> {{$activityLog->action}} </x-detail-row>
        <x-detail-row label="Route"> {{$activityLog->route}} </x-detail-row>
        <x-detail-row label="Ip">{{$activityLog->ip}}</x-detail-row>
        <x-detail-row label="Actionable type">
            {{class_basename($activityLog->actionable_type)}}
            @if($activityLog->action !== 'deleted')
                <span> | </span>
                <x-link href="{{url($activityLog->route .'/'. $activityLog->actionable_id)}}">
                    View
                </x-link>
            @endif
        </x-detail-row>
        <x-detail-row label="Actionable Id">{{$activityLog->actionable_id}}</x-detail-row>
        <x-detail-row label="User">
            <x-link href="{{route('back-office.users.show', $activityLog->actionable_id)}}">
                {{$activityLog->user->full_name}}
            </x-link>
        </x-detail-row>
        <x-detail-row label="Request">
            <pre>{{ json_encode($activityLog->request, JSON_PRETTY_PRINT)  }}</pre>
        </x-detail-row>
        <x-detail-row label="Before">
            <pre>{{ json_encode($activityLog->actionable_before, JSON_PRETTY_PRINT) }}</pre>
        </x-detail-row>
        <x-detail-row label="After">
            <pre>{{ json_encode($activityLog->actionable_after, JSON_PRETTY_PRINT) }}</pre>
        </x-detail-row>
        <x-detail-row :last="true"
                      label="Created">{{$activityLog->created_at->timezone(config('app.timezone'))->format('d.m.Y H:i:s')}}</x-detail-row>
    </x-card>
    <div class="flex flex-col md:flex-row justify-between items-center">
        <x-btn color="gray" class="mb-3 md:mb-0 w-full md:w-auto" :link="true"
               href="{{route('back-office.activity-log.index')}}">Back to List
        </x-btn>
    </div>
</x-admin-layout>
