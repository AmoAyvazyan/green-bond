@section('title', 'Loan Request Details')
@section('button-class','flex justify-between items-center pb-1')
@section('button')
    <x-btn :link="true" color="green"
           href="{{route('back-office.loan-requests.edit', $loanRequest)}}">Edit
    </x-btn>
@endsection
<x-admin-layout>
    <x-card>
        <x-detail-row label="Code"> {{$loanRequest->code}} </x-detail-row>
        <x-detail-row label="Loan Type"> {{ucfirst($loanRequest->loan_type)}} </x-detail-row>
        <x-detail-row label="Address"> {{$loanRequest->address}} </x-detail-row>
        <x-detail-row label="Region">
            <x-link href="{{route('back-office.regions.show', $region)}}">
                @foreach($region->translations as $translation)
                    {{$translation->name}}
                    <span class="text-gray-500">|</span>
                @endforeach
            </x-link>
        </x-detail-row>
        <x-detail-row label="Community">
            @if($community)
                <x-link href="{{route('back-office.communities.show', $community)}}">
                    @foreach($community->translations as $translation)
                        {{$translation->name}}
                        <span class="text-gray-500">|</span>
                    @endforeach
                </x-link>
            @else
                <span>-</span>
            @endif
        </x-detail-row>
        <x-detail-row label="CO2 Reduction"> {{$loanRequest->co2_reduction}} </x-detail-row>
        <x-detail-row label="Area"> {{$loanRequest->area}} </x-detail-row>
        <x-detail-row label="Duration Months"> {{$loanRequest->duration_months}} </x-detail-row>
        <x-detail-row label="Energy Savings"> {{number_format($loanRequest->energy_savings,2,'.',' ')}} </x-detail-row>
        <x-detail-row label="Monetary Savings"> {{number_format($loanRequest->monetary_savings,2,'.',' ') . ' ' . __('phrases.amd')}} </x-detail-row>
        <x-detail-row label="Property Type"> {{ucfirst($loanRequest->property_type)}} </x-detail-row>
        <x-detail-row label="Type"> {{ucfirst($loanRequest->type)}} </x-detail-row>
        <x-detail-row label="Status"> {{ucfirst($loanRequest->status)}} </x-detail-row>
        <x-detail-row label="Amount Total">{{$loanRequest->total_amount ? number_format($loanRequest->total_amount,0,'.',' ') . ' ' . __('phrases.amd') : '-'}} </x-detail-row>
        <x-detail-row label="Amount Refinanced">{{$loanRequest->amount_refinanced ? number_format($loanRequest->amount_refinanced,0,'.',' ') . ' ' . __('phrases.amd') : '-'}} </x-detail-row>
        <x-detail-row label="Loaner Sex"> {{$loanRequest->loaner_sex ?? '-'}} </x-detail-row>
        <x-detail-row label="Loaner Revenue"> {{$loanRequest->loaner_revenue ? number_format($loanRequest->loaner_revenue, 0,'.',' ') . ' ' . __('phrases.amd') : '-'}} </x-detail-row>
        <x-detail-row label="Funding Source"> {{$loanRequest->funding_source ?? '-'}} </x-detail-row>
        <x-detail-row label="Loaned by">
            @if($partner)
                <x-link href="{{route('back-office.partners.show', $partner)}}">
                    @foreach($partner->translations as $translation)
                        {{$translation->name}}
                        <span class="text-gray-500">|</span>
                    @endforeach
                </x-link>
            @else
                <span>-</span>
            @endif
        </x-detail-row>
        <x-detail-row label="File">
            @if($loanRequest->file)
                <x-link target="_blank" href="{{$loanRequest->file}}">View File</x-link>
            @else
                <x-link target="_blank" href="{{route('front.result.calculators.other', [
                        'loanRequest' => $loanRequest,
                        'loaner_first_name' => 'Not',
                        'loaner_last_name' => 'Available',
                        'print' => false,
                    ])}}">View File
                </x-link>
            @endif
        </x-detail-row>
        <x-detail-row label="Refinanced">
            {{$loanRequest->refinanced_at?->timezone(config('app.timezone'))->format('d.m.Y H:i:s') ?? '-'}}
        </x-detail-row>
        <x-detail-row label="Called Back">
            {{$loanRequest->rejected_at?->timezone(config('app.timezone'))->format('d.m.Y H:i:s') ?? '-'}}
        </x-detail-row>
        <x-detail-row label="Requested">
            {{$loanRequest->created_at->timezone(config('app.timezone'))->format('d.m.Y H:i:s')}}
        </x-detail-row>
        <x-detail-row label="Modified" :last="true">
            {{$loanRequest->updated_at->timezone(config('app.timezone'))->format('d.m.Y H:i:s')}}
        </x-detail-row>
    </x-card>
    @include('partials.show-actions', [
        'resource' => 'loan-requests',
        'permission' => 'delete-loan-requests',
        'editPermission' => 'edit-loan-requests',
        'model' => $loanRequest,
    ])
</x-admin-layout>