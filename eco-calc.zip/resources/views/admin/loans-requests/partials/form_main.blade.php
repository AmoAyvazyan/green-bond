@php /** @var $loanRequest \App\Models\LoanRequest */ @endphp
<x-card>
    <div class="grid grid-cols-1 md:grid-cols-2 gap-x-10 gap-y-5">
        @if($errors->count()>0)
            <div class="col-span-full">
                <!-- Validation Errors -->
                <x-validation-errors class="mb-4" :errors="$errors"/>
            </div>
        @endif
        <div>
            <x-label for="region_id" :value="__('Region')"/>
            <x-custom-select name="region_id" id="region_id" class="block mt-1 w-full" required>
                @forelse($regions as $region)
                    <option
                        {{($loanRequest?->region->is($region)
                            || old('region_id') == $region->id) ? 'selected' : ''}}
                        value="{{$region->id}}">{{$region->name}}</option>
                @empty
                    <option value="" disabled selected>{{__('There are no any region')}}</option>
                @endforelse
            </x-custom-select>
        </div>
        <div>
            <x-label for="community_id" :value="__('Community')"/>
            <x-custom-select name="community_id" id="community_id" class="block mt-1 w-full">
                <option value="" selected>{{__('Choose Community')}}</option>
                @forelse($communities as $community)
                    <option
                        {{($loanRequest?->community?->is($community)
                            || old('community_id') == $community->id) ? 'selected' : ''}}
                        value="{{$community->id}}">{{$community->name}}</option>
                @empty
                    <option value="" disabled selected>{{__('There are no any community')}}</option>
                @endforelse
            </x-custom-select>
        </div>
        <div>
            <x-label for="pfi_id" :value="__('Partner')"/>
            <x-custom-select name="pfi_id" id="pfi_id" class="block mt-1 w-full">
                <option value="" selected>{{__('Choose Partner')}}</option>
                @forelse($partners as $partner)
                    <option
                        {{($loanRequest?->partner?->is($partner)
                            || old('pfi_id') == $partner->id) ? 'selected' : ''}}
                        value="{{$partner->id}}">{{$partner->name}}</option>
                @empty
                    <option value="" disabled selected>{{__('There is no any partner')}}</option>
                @endforelse
            </x-custom-select>
        </div>
        <div>
            <x-label for="address" :value="__('Address')"/>
            <x-input id="address" class="block mt-1 w-full" type="text" name="address"
                     :value="isset($loanRequest) ? $loanRequest->address : old('address')"
                     required/>
        </div>
        <div>
            <x-label for="status" :value="__('Status')"/>
            <x-select name="status" id="status" class="block mt-1 w-full">
                @foreach($statuses as $status)
                    <option
                        {{$loanRequest?->status === $status ? 'selected' : ''}} value="{{$status}}">{{ucfirst($status)}}</option>
                @endforeach
            </x-select>
        </div>
        <div>
            <x-label for="loaner_sex" :value="__('Loaner Sex')"/>
            <x-select name="loaner_sex" id="loaner_sex" class="block mt-1 w-full">
                <option value="" selected>{{__('Choose Sex')}}</option>
                @foreach($loanerSexes as $sex)
                    <option
                        {{$loanRequest?->loaner_sex === $sex ? 'selected' : ''}} value="{{$sex}}">{{ucfirst($sex)}}</option>
                @endforeach
            </x-select>
        </div>
        <div>
            <x-label for="refinanced_at" :value="__('Refinanced At')"/>
            <div class="flex justify-between items-center space-x-2.5">
                <x-input id="refinanced_at" class="block mt-1 w-full" type="datetime-local" name="refinanced_at"
                         :value="isset($loanRequest) && $loanRequest->refinanced_at
                     ? date('Y-m-d\TH:i:s', strtotime($loanRequest->refinanced_at))
                     : ''"/>
            </div>
        </div>
        <div>
            <x-label for="rejected_at" :value="__('Rejected At')"/>
            <div class="flex justify-between items-center space-x-2.5">
                <x-input id="rejected_at" class="block mt-1 w-full" type="datetime-local" name="rejected_at"
                         :value="isset($loanRequest) && $loanRequest->rejected_at
                     ? date('Y-m-d\TH:i:s', strtotime($loanRequest->rejected_at))
                     : ''"/>
            </div>
        </div>
        <div>
            <x-label for="amount_refinanced" :value="__('Amount Refinanced')"/>
            <x-input id="amount_refinanced" class="block mt-1 w-full" type="text" name="amount_refinanced"
                     :value="isset($loanRequest) ? $loanRequest->amount_refinanced : old('amount_refinanced')"/>
        </div>
        <div>
            <x-label for="loaner_revenue" :value="__('Loaner Revenue')"/>
            <x-input id="loaner_revenue" class="block mt-1 w-full" type="text" name="loaner_revenue"
                     :value="isset($loanRequest) ? $loanRequest->loaner_revenue : old('loaner_revenue')"/>
        </div>
        <div>
            <x-label for="funding_source" :value="__('Funding Source')"/>
            <x-input id="funding_source" class="block mt-1 w-full" type="text" name="funding_source"
                     :value="isset($loanRequest) ? $loanRequest->funding_source : old('funding_source')"/>
        </div>
    </div>
</x-card>
<div class="flex justify-between items-center">
    <x-btn color="gray" :link="true" href="{{back()->getTargetUrl()}}">{{__('Back')}}</x-btn>
    <x-btn color="green">{{__('Save')}}</x-btn>
</div>