@section('title', $loanRequest->loan_type === \App\Models\LoanRequest::LOAN_TYPE_RENOVATION ? __('Edit Renovation Loan Request') : __('Edit Construction Loan Request'))
@section('select-class', 'flex justify-between items-center')
<x-admin-layout>
    <form id="editForm" enctype="multipart/form-data" method="POST"
          action="{{route('back-office.loan-requests.update', $loanRequest)}}">
        @csrf
        @method('put')
        @include('admin.loans-requests.partials.form_main')
    </form>
</x-admin-layout>