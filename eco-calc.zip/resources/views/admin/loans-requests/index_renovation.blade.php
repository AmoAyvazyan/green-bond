@section('title',__('Renovation Loan Requests'))
@section('button-class','flex justify-between items-center pb-1')
@section('button')
    @include('partials.bulk_approve_button', ['type' => 'renovation'])
@endsection
<x-admin-layout>
    <livewire:tables.renovation-loan-request-table/>
</x-admin-layout>