@section('title',__('Construction Loan Requests'))
@section('button-class','flex justify-between items-center pb-1')
@section('button')
    @include('partials.bulk_approve_button', ['type' => 'construction'])
@endsection
<x-admin-layout>
    <livewire:tables.construction-loan-request-table/>
</x-admin-layout>