@php /** @var $improvement \App\Models\Improvement */ @endphp
<x-card>
    <div class="grid grid-cols-1 md:grid-cols-2 gap-x-10 gap-y-5">
        @if($errors->count()>0)
            <div class="col-span-full">
                <!-- Validation Errors -->
                <x-validation-errors class="mb-4" :errors="$errors"/>
            </div>
        @endif
        <div>
            <x-label for="name" :value="__('Name')"/>
            <x-input id="name" data-lang="{{$currentLocale ?? 'en'}}" class="block mt-1 w-full" type="text" name="name"
                     :value="isset($improvement) && $improvement->translate($currentLocale) ? $improvement->translate($currentLocale ?? 'en')?->name : old('name')"
                     required/>
        </div>
        <div>
            <x-label for="slug" :value="__('Slug')"/>
            <x-input id="slug" class="block mt-1 w-full" type="text" name="slug" required
                     data-new="{{isset($improvement) ? 'false' : 'true'}}"
                     :value="isset($improvement) ? $improvement->slug : old('slug')"/>
        </div>
        <div>
            <x-label for="parent_id" :value="__('Parent Improvement')"/>
            <x-custom-select name="parent_id" id="parent_id" class="block mt-1 w-full">
                <option value="" selected>{{__('Choose Improvement')}}</option>
                @forelse($parentImprovements as $parentImprovement)
                    <option
                        {{($improvement?->parent?->is($parentImprovement)
                            || old('parent_id') === $parentImprovement->id) ? 'selected' : ''}}
                        value="{{$parentImprovement->id}}">{{$parentImprovement->name}}</option>
                @empty
                    <option value="" disabled selected>{{__('There are no any improvement')}}</option>
                @endforelse
            </x-custom-select>
        </div>
        <div>
            <x-label for="icon" :value="__('Icon (SVG)')"/>
            @isset($improvement)
                <div class="flex items-center justify-between">
                    <x-input-file id="icon" name="icon" class="w-full" :value="__('Edit icon')"/>
                    <a target="_blank" href="{{$improvement->icon}}"><img
                            class="w-10 h-10 object-cover object-center rounded shadow-md ml-2"
                            src="{{$improvement->icon}}" alt="{{$improvement->icon}}"></a>
                </div>
            @else
                <x-input-file id="icon" name="icon" class="" :value="__('Upload icon')"/>
            @endif
        </div>
        <div>
            <x-label for="availability" :value="__('Availability')"/>
            <x-custom-select name="availability" id="availability" class="block mt-1 w-full">
                @forelse($availabilities as $availability)
                        <option {{$improvement?->availability === $availability ? 'selected' : ''}} value="{{$availability}}">
                        {{$availability}}
                    </option>
                @empty
                    <option value="" disabled selected>{{__('There are no any availability')}}</option>
                @endforelse
            </x-custom-select>
        </div>
        <div>
            <x-label for="unit" :value="__('Unit')"/>
            <x-input id="unit" class="block mt-1 w-full" type="text" name="unit"
                     :value="isset($improvement) && $improvement->translate($currentLocale) ? $improvement->translate($currentLocale ?? 'en')?->unit : old('unit')"/>
        </div>
        <div class="col-span-full flex">
            <div class="items-center">
                <x-checkbox value="1" :checked="$improvement->is_active??old('is_active')" name="is_active"
                            id="is_active" class="block ms-4 mt-5 mr-8">{{__('Active')}}</x-checkbox>
            </div>
            <div class="items-center">
                <x-checkbox value="1" :checked="$improvement->is_countable??old('is_countable')" name="is_countable"
                            id="is_countable" class="block ms-4 mt-5 mr-8">{{__('Countable')}}</x-checkbox>
            </div>
            <div class="items-center">
                <x-checkbox value="1" :checked="$improvement->include_works??old('Include Works')" name="include_works"
                            id="include_works" class="block ms-4 mt-5 mr-8">{{__('Include Works')}}</x-checkbox>
            </div>
        </div>
        <div class="col-span-full">
            <x-label for="description" class="mb-1" :value="__('Description')"/>
            <x-textarea id="description" name="description">
                {!! isset($improvement) && $improvement->translate($currentLocale)
                    ? $improvement->translate($currentLocale)->getRawOriginal('description')
                    : old('description') !!}
            </x-textarea>
        </div>
    </div>
</x-card>
<div class="flex justify-between items-center">
    <x-btn color="gray" :link="true" href="{{back()->getTargetUrl()}}">{{__('Back')}}</x-btn>
    <x-btn color="green">{{__('Save')}}</x-btn>
</div>