@section('title',__('Edit Improvement'))
@section('select-class', 'flex justify-between items-center')
@section('select')
    <x-select onchange="location.replace('{{route('back-office.improvements.edit', $improvement)}}' + '?locale=' + this.value)"
              name="translation_locale" id="translation_locale" form="editForm">
        @foreach($locales as $code=>$locale)
            <option {{$currentLocale===$code?'selected':''}} value="{{$code}}">{{$locale['native']}}</option>
        @endforeach
    </x-select>
@endsection
<x-admin-layout>
    <form id="editForm" enctype="multipart/form-data" method="POST"
          action="{{route('back-office.improvements.update',$improvement)}}">
        @csrf
        @method('put')
        @include('admin.improvements.partials.form_main')
    </form>
</x-admin-layout>