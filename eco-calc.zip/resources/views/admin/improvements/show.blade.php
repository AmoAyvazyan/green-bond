@section('title', 'Improvement Details')
@section('button-class','flex justify-between items-center pb-1')
@section('button')
    <x-btn :link="true" color="green" href="{{route('back-office.improvements.edit', $improvement)}}">Edit</x-btn>
@endsection
<x-admin-layout>
    <x-card>
        <x-detail-row label="Slug"> {{$improvement->slug}} </x-detail-row>
        <x-detail-row label="Improvement Icon">
            @if($improvement->icon)
                <img src="{{$improvement->icon}}" alt="Improvement Icon"
                     class="rounded h-50">
            @else
                <span>-</span>
            @endif
        </x-detail-row>
        <x-detail-row label="Name">
            @foreach($improvement->translations as $translation)
                {{$translation->name}}
                <span class="text-gray-500">|</span>
            @endforeach
        </x-detail-row>
        <x-detail-row label="Parent">
            @if($parent)
                <x-link href="{{route('back-office.improvements.show', $parent)}}">
                    {{$parent->translate('hy') ? $parent->translate('hy')->name : ''}} |
                    {{$parent->translate('en') ? $parent->translate('en')->name : ''}}
                </x-link>
            @endif
        </x-detail-row>
        <x-detail-row label="Unit">
            @if($improvement->unit)
                @foreach($improvement->translations as $translation)
                    {{$translation->unit}}
                    <span class="text-gray-500">|</span>
                @endforeach
            @else
                <span>-</span>
            @endif
        </x-detail-row>
        <x-detail-row label="Availability"> {{$improvement->availability}} </x-detail-row>
        <x-detail-row label="Description">
            @if($improvement->description)
                @foreach($improvement->translations as $translation)
                    {!! $translation->description !!}
                    <span class="text-gray-500">|</span>
                @endforeach
            @else
                <span>-</span>
            @endif
        </x-detail-row>
        <x-detail-row label="Active">
            @if($improvement->is_active)
                <x-heroicon-o-check-circle class="w-5 h-5 text-green-500"/>
            @else
                <x-heroicon-o-no-symbol class="w-5 h-5 text-red-500"/>
            @endif
        </x-detail-row>
        <x-detail-row label="Countable">
            @if($improvement->is_countable)
                <x-heroicon-o-check-circle class="w-5 h-5 text-green-500"/>
            @else
                <x-heroicon-o-no-symbol class="w-5 h-5 text-red-500"/>
            @endif
        </x-detail-row>
        <x-detail-row label="Include Works">
            @if($improvement->include_works)
                <x-heroicon-o-check-circle class="w-5 h-5 text-green-500"/>
            @else
                <x-heroicon-o-no-symbol class="w-5 h-5 text-red-500"/>
            @endif
        </x-detail-row>
        <x-detail-row label="Created">
            {{$improvement->created_at->timezone(config('app.timezone'))->format('d.m.Y H:i:s')}}
        </x-detail-row>
        <x-detail-row label="Modified" :last="true">
            {{$improvement->updated_at->timezone(config('app.timezone'))->format('d.m.Y H:i:s')}}
        </x-detail-row>
    </x-card>
    @include('partials.show-actions', [
        'resource' => 'improvements',
        'permission' => 'delete-improvements',
        'model' => $improvement,
    ])
</x-admin-layout>