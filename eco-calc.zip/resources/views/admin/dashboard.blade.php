@section('title', __('Dashboard'))
<x-admin-layout>
    <div id="notificationsBlock"
         class="notifications-area absolute bottom-16 right-5 translate-y-2/4 max-h-screen"></div>
</x-admin-layout>
