@section('title',__('Edit Setting'))
@section('select-class', 'flex justify-between items-center')
<x-admin-layout>
    <form id="editForm" enctype="multipart/form-data" method="POST"
          action="{{route('back-office.settings.update',$setting)}}">
        @csrf
        @method('put')
        @include('admin.settings.partials.form_main')
    </form>
</x-admin-layout>
