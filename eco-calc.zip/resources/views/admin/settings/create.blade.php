@section('title',__('Add Setting'))
@section('select-class', 'flex justify-between items-center')
<x-admin-layout>
    <form id="createForm" enctype="multipart/form-data" method="POST" action="{{route('back-office.settings.store')}}">
        @csrf
        @include('admin.settings.partials.form_main')
    </form>
</x-admin-layout>
