@section('title', 'Setting Details')
@section('button-class','flex justify-between items-center pb-1')
@section('button')
    <x-btn :link="true" color="green" href="{{route('back-office.settings.edit', $setting)}}">Edit</x-btn>
@endsection
<x-admin-layout>
    <x-card>
        <x-detail-row label="Key">{{$setting->key}}</x-detail-row>
        <x-detail-row label="Value">{{$setting->value}}</x-detail-row>
        <x-detail-row label="Created">{{$setting->created_at->timezone(config('app.timezone'))->format('d.m.Y H:i:s')}}</x-detail-row>
        <x-detail-row label="Modified" :last="true">{{$setting->updated_at->timezone(config('app.timezone'))->format('d.m.Y H:i:s')}}</x-detail-row>
    </x-card>
    @include('partials.show-actions', [
        'resource' => 'settings',
        'permission' => 'delete-settings',
        'model' => $setting,
    ])
</x-admin-layout>
