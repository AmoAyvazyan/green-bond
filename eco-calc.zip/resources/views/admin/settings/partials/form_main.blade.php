<x-card>
    <div class="grid grid-cols-1 md:grid-cols-2 gap-x-10 gap-y-5">
        @if($errors->count()>0)
            <div class="col-span-full">
                <!-- Validation Errors -->
                <x-validation-errors class="mb-4" :errors="$errors"/>
            </div>
        @endif
        <div>
            <x-label for="key" :value="__('Key')"/>
            <x-input id="key" class="block mt-1 w-full" type="text" name="key"
                     :value="isset($setting) ? $setting->key : old('key')" :readonly="isset($setting) && $setting->is_system" required/>
        </div>
        <div>
            <x-label for="value" :value="__('Value')"/>
            <x-input id="value" class="block mt-1 w-full" type="text" name="value"
                     :value="isset($setting) ? $setting->value : old('value')" required/>
        </div>
    </div>
</x-card>
<div class="flex justify-between items-center">
    <x-btn color="gray" :link="true" href="{{back()->getTargetUrl()}}">{{__('Back')}}</x-btn>
    <x-btn color="green">{{__('Save')}}</x-btn>
</div>
