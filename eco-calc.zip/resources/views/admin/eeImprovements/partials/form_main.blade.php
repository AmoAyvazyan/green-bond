@php /** @var $eeImprovement \App\Models\EeImprovement */ @endphp
<x-card>
    <div class="grid grid-cols-1 md:grid-cols-2 gap-x-10 gap-y-5">
        @if($errors->count()>0)
            <div class="col-span-full">
                <!-- Validation Errors -->
                <x-validation-errors class="mb-4" :errors="$errors"/>
            </div>
        @endif
        <div>
            <x-label for="name" :value="__('Name')"/>
            <x-input id="name" data-lang="{{$currentLocale ?? 'en'}}" class="block mt-1 w-full" type="text" name="name"
                     :value="isset($eeImprovement) && $eeImprovement->translate($currentLocale) ? $eeImprovement->translate($currentLocale ?? 'en')?->name : old('name')"
                     required/>
        </div>
        <div>
            <x-label for="slug" :value="__('Slug')"/>
            <x-input id="slug" class="block mt-1 w-full" type="text" name="slug" required
                     data-new="{{isset($eeImprovement) ? 'false' : 'true'}}"
                     :value="isset($eeImprovement) ? $eeImprovement->slug : old('slug')"/>
        </div>
        <div>
            <x-label for="sort_order" :value="__('Sort Order')"/>
            <x-input id="sort_order" class="block mt-1 w-full" type="number" name="sort_order" required
                     :value="isset($eeImprovement) ? $eeImprovement->sort_order : old('sort_order')"/>
        </div>
        <div>
            <x-label for="parent_id" :value="__('Parent EeImprovement')"/>
            <x-custom-select name="parent_id" id="parent_id" class="block mt-1 w-full">
                <option value="" selected>{{__('Choose Improvement')}}</option>
                @forelse($parentEeImprovements as $parentEeImprovement)
                    <option
                        {{($eeImprovement?->parent?->is($parentEeImprovement)
                            || old('parent_id') === $parentEeImprovement->id) ? 'selected' : ''}}
                        value="{{$parentEeImprovement->id}}">{{$parentEeImprovement->translate($currentLocale ?? 'hy')->name}}</option>
                @empty
                    <option value="" disabled selected>{{__('There are no any improvement')}}</option>
                @endforelse
            </x-custom-select>
        </div>
        <div>
            <x-label for="materials" :value="__('Materials')"/>
            <x-select name="materials[]" id="materials" class="block mt-1 w-full h-20" multiple multiselect>
                @forelse($materials as $material)
                    <option
                        {{isset($eeImprovement) && $eeImprovement->materials->contains($material) ? 'selected' : ''}}
                        value="{{$material->id}}">{{$material->translate('en')?->name}}</option>
                @empty
                    <option value="" disabled selected>{{__('There are no any material')}}</option>
                @endforelse
            </x-select>
        </div>
        <div>
            <x-label for="icon" :value="__('Icon (SVG)')"/>
            @isset($eeImprovement)
                <div class="flex items-center justify-between">
                    <x-input-file id="icon" name="icon" class="w-full" :value="__('Edit icon')"/>
                    <a target="_blank" href="{{$eeImprovement->icon}}"><img
                            class="w-10 h-10 object-cover object-center rounded shadow-md ml-2"
                            src="{{$eeImprovement->icon}}" alt="{{$eeImprovement->icon}}"></a>
                </div>
            @else
                <x-input-file id="icon" name="icon" class="" :value="__('Upload icon')" required/>
            @endif
        </div>
        <div class="col-span-full flex">
            <div class="items-center">
                <x-checkbox value="1" :checked="$eeImprovement->is_active??old('is_active')" name="is_active"
                            id="is_active" class="block ms-4 mt-5 mr-8">{{__('Active')}}</x-checkbox>
            </div>
            <div class="items-center">
                <x-checkbox value="1" :checked="$eeImprovement->has_quantity??old('has_quantity')" name="has_quantity"
                            id="has_quantity" class="block ms-4 mt-5 mr-8">{{__('Quantity')}}</x-checkbox>
            </div>
            <div class="items-center">
                <x-checkbox value="1" :checked="$eeImprovement->has_power??old('has_power')" name="has_power"
                            id="has_power" class="block ms-4 mt-5 mr-8">{{__('Power')}}</x-checkbox>
            </div>
            <div class="items-center">
                <x-checkbox value="1" :checked="$eeImprovement->has_price??old('has_price')" name="has_price"
                            id="has_price" class="block ms-4 mt-5 mr-8">{{__('Price')}}</x-checkbox>
            </div>
            <div class="items-center">
                <x-checkbox value="1" :checked="$eeImprovement->has_area??old('has_area')" name="has_area"
                            id="has_area" class="block ms-4 mt-5 mr-8">{{__('Area')}}</x-checkbox>
            </div>
            <div class="items-center">
                <x-checkbox value="1" :checked="$eeImprovement->has_thickness??old('has_thickness')"
                            name="has_thickness"
                            id="has_thickness" class="block ms-4 mt-5 mr-8">{{__('Thickness')}}</x-checkbox>
            </div>
            <div class="items-center">
                <x-checkbox value="1" :checked="$eeImprovement->has_volume??old('has_volume')" name="has_volume"
                            id="has_volume" class="block ms-4 mt-5 mr-8">{{__('Volume')}}</x-checkbox>
            </div>
        </div>
    </div>
</x-card>
<div class="flex justify-between items-center">
    <x-btn color="gray" :link="true" href="{{back()->getTargetUrl()}}">{{__('Back')}}</x-btn>
    <x-btn color="green">{{__('Save')}}</x-btn>
</div>