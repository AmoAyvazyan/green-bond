@section('title',__('EeImprovements'))
@section('button-class','flex justify-between items-center pb-1')
@section('button')
    <x-btn :link="true" color="green" href="{{route('back-office.eeImprovements.create')}}">Add EeImprovement</x-btn>
@endsection
<x-admin-layout>
    <livewire:tables.ee-improvement-table/>
    <hr>
    <div class="flex justify-end items-center mt-5">
        <x-btn :link="true" color="green" href="{{route('back-office.eeImprovements.create')}}">Add EeImprovement</x-btn>
    </div>
</x-admin-layout>