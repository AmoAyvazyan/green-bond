@section('title', 'EeImprovement Details')
@section('button-class','flex justify-between items-center pb-1')
@section('button')
    <x-btn :link="true" color="green" href="{{route('back-office.eeImprovements.edit', $eeImprovement)}}">Edit</x-btn>
@endsection
<x-admin-layout>
    <x-card>
        <x-detail-row label="Slug"> {{$eeImprovement->slug}} </x-detail-row>
        <x-detail-row label="Sort Order"> {{$eeImprovement->sort_order}} </x-detail-row>
        <x-detail-row label="Improvement Icon">
            <a target="_blank" class="cursor-pointer" href="{{$eeImprovement->icon}}">
                <img src="{{$eeImprovement->icon}}" alt="Improvement Icon"
                     class="rounded w-12">
            </a>
        </x-detail-row>
        <x-detail-row label="Name">
            @foreach($eeImprovement->translations as $translation)
                {{$translation->name}}
                <span class="text-gray-500">|</span>
            @endforeach
        </x-detail-row>
        <x-detail-row label="Materials">
            @foreach($materials as $material)
                <x-link href="{{route('back-office.materials.show', $material)}}">
                    {{$material->name}}
                </x-link>
                <span class="text-gray-500">|</span>
            @endforeach
        </x-detail-row>
        <x-detail-row label="Parent">
            @if($parent)
                <x-link href="{{route('back-office.eeImprovements.show', $parent)}}">
                    @foreach($parent->translations as $translation)
                        {{$translation->name}}
                        <span class="text-gray-500">|</span>
                    @endforeach
                </x-link>
            @endif
        </x-detail-row>
        <x-detail-row label="Active">
            @if($eeImprovement->is_active)
                <x-heroicon-o-check-circle class="w-5 h-5 text-green-500"/>
            @else
                <x-heroicon-o-no-symbol class="w-5 h-5 text-red-500"/>
            @endif
        </x-detail-row>
        <x-detail-row label="Quantity">
            @if($eeImprovement->has_quantity)
                <x-heroicon-o-check-circle class="w-5 h-5 text-green-500"/>
            @else
                <x-heroicon-o-no-symbol class="w-5 h-5 text-red-500"/>
            @endif
        </x-detail-row>
        <x-detail-row label="Power">
            @if($eeImprovement->has_power)
                <x-heroicon-o-check-circle class="w-5 h-5 text-green-500"/>
            @else
                <x-heroicon-o-no-symbol class="w-5 h-5 text-red-500"/>
            @endif
        </x-detail-row>
        <x-detail-row label="Price">
            @if($eeImprovement->has_price)
                <x-heroicon-o-check-circle class="w-5 h-5 text-green-500"/>
            @else
                <x-heroicon-o-no-symbol class="w-5 h-5 text-red-500"/>
            @endif
        </x-detail-row>
        <x-detail-row label="Area">
            @if($eeImprovement->has_area)
                <x-heroicon-o-check-circle class="w-5 h-5 text-green-500"/>
            @else
                <x-heroicon-o-no-symbol class="w-5 h-5 text-red-500"/>
            @endif
        </x-detail-row>
        <x-detail-row label="Thickness">
            @if($eeImprovement->has_thickness)
                <x-heroicon-o-check-circle class="w-5 h-5 text-green-500"/>
            @else
                <x-heroicon-o-no-symbol class="w-5 h-5 text-red-500"/>
            @endif
        </x-detail-row>
        <x-detail-row label="Volume">
            @if($eeImprovement->has_volume)
                <x-heroicon-o-check-circle class="w-5 h-5 text-green-500"/>
            @else
                <x-heroicon-o-no-symbol class="w-5 h-5 text-red-500"/>
            @endif
        </x-detail-row>
        <x-detail-row label="Created">
            {{$eeImprovement->created_at->timezone(config('app.timezone'))->format('d.m.Y H:i:s')}}
        </x-detail-row>
        <x-detail-row label="Modified" :last="true">
            {{$eeImprovement->updated_at->timezone(config('app.timezone'))->format('d.m.Y H:i:s')}}
        </x-detail-row>
    </x-card>
    @include('partials.show-actions', [
        'resource' => 'eeImprovements',
        'permission' => 'delete-improvements',
        'model' => $eeImprovement,
    ])
</x-admin-layout>