@php /** @var $residentialComplex \App\Models\ResidentialComplex */ @endphp
<x-card>
    <div class="grid grid-cols-1 md:grid-cols-2 gap-x-10 gap-y-5">
        @if($errors->count()>0)
            <div class="col-span-full">
                <!-- Validation Errors -->
                <x-validation-errors class="mb-4" :errors="$errors"/>
            </div>
        @endif
        <div>
            <x-label for="name" :value="__('Name')"/>
            <x-input id="name" data-lang="{{$currentLocale ?? 'en'}}" class="block mt-1 w-full" type="text" name="name"
                     :value="isset($residentialComplex) && $residentialComplex->translate($currentLocale) ? $residentialComplex->translate($currentLocale ?? 'en')?->name : old('name')"
                     required/>
        </div>
        <div>
            <x-label for="developer" :value="__('Developer')"/>
            <x-input id="developer" class="block mt-1 w-full" type="text" name="developer" required
                     :value="isset($residentialComplex) ? $residentialComplex->developer : old('developer')"/>
        </div>
            <div>
            <x-label for="address" :value="__('Address')"/>
            <x-input id="address" class="block mt-1 w-full" type="text" name="address" required
                     :value="isset($residentialComplex) && $residentialComplex->translate($currentLocale) ? $residentialComplex->translate($currentLocale ?? 'en')?->address : old('address')"/>
        </div>
        <div>
            <x-label for="address_new" :value="__('New Address')"/>
            <x-input id="address_new" class="block mt-1 w-full" type="text" name="address_new"
                     :value="isset($residentialComplex) && $residentialComplex->translate($currentLocale) ? $residentialComplex->translate($currentLocale ?? 'en')?->address_new : old('address_new')"/>
        </div>
        <div>
            <x-label for="region_id" :value="__('Region')"/>
            <x-custom-select name="region_id" id="region_id" class="block mt-1 w-full" required>
                @forelse($regions as $region)
                    <option
                        {{($residentialComplex?->region->is($region)
                            || old('region_id') == $region->id) ? 'selected' : ''}}
                        value="{{$region->id}}">{{$region->translate($currentLocale ?? 'hy')->name}}</option>
                @empty
                    <option value="" disabled selected>{{__('There are no any region')}}</option>
                @endforelse
            </x-custom-select>
        </div>
        <div>
            <x-label for="community_id" :value="__('Community')"/>
            <x-custom-select name="community_id" id="community_id" class="block mt-1 w-full">
                <option value="" selected>{{__('Choose community')}}</option>
                @forelse($communities as $community)
                    <option
                        {{($residentialComplex?->community?->is($community)
                            || old('community_id') == $community->id) ? 'selected' : ''}}
                        value="{{$community->id}}">{{$community->translate($currentLocale ?? 'hy')->name}}</option>
                @empty
                    <option value="" disabled selected>{{__('There are no any community')}}</option>
                @endforelse
            </x-custom-select>
        </div>
{{--        <div>--}}
{{--            <x-label for="image" :value="__('Image (min: 500x500)')"/>--}}
{{--            @isset($residentialComplex)--}}
{{--                <div class="flex items-center justify-between">--}}
{{--                    <x-input-file id="image" name="image" class="w-full" :value="__('Edit image')"/>--}}
{{--                    <a target="_blank" href="{{$residentialComplex->image}}"><img--}}
{{--                            class="w-10 h-10 object-cover object-center rounded shadow-md ml-2"--}}
{{--                            src="{{$residentialComplex->image}}" alt="{{$residentialComplex->image}}"></a>--}}
{{--                </div>--}}
{{--            @else--}}
{{--                <x-input-file id="image" name="image" class="" :value="__('Upload image')"/>--}}
{{--            @endif--}}
{{--        </div>--}}
    </div>
</x-card>
<div class="flex justify-between items-center">
    <x-btn color="gray" :link="true" href="{{back()->getTargetUrl()}}">{{__('Back')}}</x-btn>
    <x-btn color="green">{{__('Save')}}</x-btn>
</div>