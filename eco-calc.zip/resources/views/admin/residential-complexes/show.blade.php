@section('title', 'Residential Complex Details')
@section('button-class','flex justify-between items-center pb-1')
@section('button')
    <x-btn :link="true" color="green" href="{{route('back-office.residential-complexes.edit', $residentialComplex)}}">
        Edit
    </x-btn>
@endsection
<x-admin-layout>
    <x-card>
        @if($residentialComplex->image)
            <x-detail-row label="Image">
                <x-link target="_blank" href="{{$residentialComplex->image}}">
                    <img src="{{$residentialComplex->image}}" alt=""
                         class="rounded h-50">
                </x-link>
            </x-detail-row>
        @endif
        <x-detail-row label="Name">
            @foreach($residentialComplex->translations as $translation)
                {{$translation->name}}
                @if(!$loop->last)
                    <span class="text-gray-500">|</span>
                @endif
            @endforeach
        </x-detail-row>
        <x-detail-row label="Region">
            <x-link href="{{route('back-office.regions.show', $region)}}">
                @foreach($region->translations as $translation)
                    {{$translation->name}}
                    @if(!$loop->last)
                        <span class="text-gray-500">|</span>
                    @endif
                @endforeach
            </x-link>
        </x-detail-row>
        @if(isset($community))
            <x-detail-row label="Community">
                <x-link href="{{route('back-office.communities.show', $community)}}">
                    @foreach($community->translations as $translation)
                        {{$translation->name}}
                        @if(!$loop->last)
                            <span class="text-gray-500">|</span>
                        @endif
                    @endforeach
                </x-link>
            </x-detail-row>
        @endif
        <x-detail-row label="Address">
            @foreach($residentialComplex->translations as $translation)
                {{$translation->address}}
                @if(!$loop->last)
                    <span class="text-gray-500">|</span>
                @endif
            @endforeach
        </x-detail-row>
        @if($residentialComplex->address_new)
            <x-detail-row label="New Address">
                @foreach($residentialComplex->translations as $translation)
                    {{$translation->address_new}}
                    @if(!$loop->last)
                        <span class="text-gray-500">|</span>
                    @endif
                @endforeach
            </x-detail-row>
        @else
            <x-detail-row label="New Address">
                -
            </x-detail-row>
        @endif
        <x-detail-row label="Developer"> {{$residentialComplex->developer}} </x-detail-row>
        <x-detail-row label="Available Buildings">
            @foreach($buildings as $building)
                <x-link href="{{route('back-office.buildings.show', $building)}}">
                    {{$building->title}}
                </x-link>
                @if(!$loop->last)
                    <span class="text-gray-500">|</span>
                @endif
            @endforeach
        </x-detail-row>
        <x-detail-row label="Created">
            {{$residentialComplex->created_at->timezone(config('app.timezone'))->format('d.m.Y H:i:s')}}
        </x-detail-row>
        <x-detail-row label="Modified" :last="true">
            {{$residentialComplex->updated_at->timezone(config('app.timezone'))->format('d.m.Y H:i:s')}}
        </x-detail-row>
    </x-card>
    @include('partials.show-actions', [
        'resource' => 'residential-complexes',
        'permission' => 'delete-settings',
        'model' => $residentialComplex,
    ])
</x-admin-layout>