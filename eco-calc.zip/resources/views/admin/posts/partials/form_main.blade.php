@php /** @var $post \App\Models\Post */ @endphp
<x-card>
    <div class="grid grid-cols-1 md:grid-cols-2 gap-x-10 gap-y-5">
        @if($errors->count()>0)
            <div class="col-span-full">
                <!-- Validation Errors -->
                <x-validation-errors class="mb-4" :errors="$errors"/>
            </div>
        @endif
        <div>
            <x-label for="title" :value="__('Title')"/>
            <x-input id="title" data-lang="{{$currentLocale ?? 'en'}}" class="block mt-1 w-full" type="text"
                     name="title"
                     :value="isset($post) && $post->translate($currentLocale) ? $post->translate($currentLocale ?? 'en')?->title : old('title')"
                     required/>
        </div>
        <div>
            <x-label for="slug" :value="__('Slug')"/>
            <x-input id="slug" data-new="{{isset($post)?'false':'true'}}" class="block mt-1 w-full" type="text"
                     name="slug"
                     :value="isset($post) ? $post->slug : old('slug')" required/>
        </div>
        <div>
            <x-label for="author" :value="__('Author')"/>
            <x-select name="author" id="author" class="block mt-1 w-full" required>
                @forelse($users as $user)
                    <option
                        {{((isset($post) && $post->author->is($user))
                            || old('author') == $user->id
                            || (!isset($post) && $user->is(Auth::user()))
                            )?'selected':''}} value="{{$user->id}}">{{$user->full_name}}</option>
                @empty
                    <option value="" disabled selected>{{__('There are no any authors')}}</option>
                @endforelse
            </x-select>
        </div>
        <div>
            <x-label for="image" :value="__('Image (min: 800x800, max 5 MB)')"/>
            @isset($post)
                <div class="flex items-center justify-between">
                    <x-input-file id="image" name="image" class="w-full" :value="__('Edit image')"/>
                    <a target="_blank" href="{{$post->image}}"><img
                            class="w-10 h-10 object-cover object-center rounded shadow-md ml-2"
                            src="{{$post->image}}"
                            alt="{{$post->image}}"></a>
                </div>
            @else
                <x-input-file id="image" name="image" class="" :value="__('Upload image')" required/>
            @endif
        </div>
        <div>
            <x-label for="published_at" :value="__('Published At')"/>
            <div class="flex justify-between items-center space-x-2.5">
                <x-input id="published_at" class="block mt-1 w-full" type="datetime-local" name="published_at"
                         :value="isset($post) && $post->published_at
                     ? date('Y-m-d\TH:i:s', strtotime($post->published_at))
                     : date('Y-m-d\TH:i:s')"/>
            </div>
        </div>
        <div class="flex pt-5 items-right">
            <x-checkbox value="1" :checked="isset($post) && $post->is_published ? 'checked' : ''"
                        name="is_published"
                        id="is_published"
                        class="block mt-1">{{__('Published')}}</x-checkbox>
        </div>
        <div class="col-span-full">
            <x-label for="content" class="mb-1" :value="__('Content')"/>
            <x-editor id="content" name="content" required>
                {!! isset($post) && $post->translate($currentLocale)
                    ? $post->translate($currentLocale)->getRawOriginal('content')
                    : old('content') !!}
            </x-editor>
        </div>
    </div>
</x-card>
<div class="flex justify-between items-center">
    <x-btn color="gray" :link="true" href="{{back()->getTargetUrl()}}">{{__('Back')}}</x-btn>
    <x-btn color="green">{{__('Save')}}</x-btn>
</div>
