<div class="flex justify-evenly items-center">
    <x-icon-link color="yellow" href="{{route('back-office.posts.show',$post)}}">
        <x-heroicon-o-eye class="w-5 h-5"/>
    </x-icon-link>
{{--    @if($post->editor && $post->editor->isNot(Auth::user()))--}}
{{--        <x-icon-link color="green" href="#" data-target="#editModal{{$post->id}}" title="{{$post->editor->full_name}} now editing the page..." class="modal-isModalOpen opacity-80" >--}}
{{--            <x-heroicon-o-pencil-square class="w-5 h-5"/>--}}
{{--        </x-icon-link>--}}
{{--        <x-modal id="editModal{{$post->id}}" heading="{{$post->editor->full_name}} now editing the page...">--}}
{{--            <form method="POST" action="{{route('back-office.posts.switch',$post)}}">--}}
{{--                @csrf--}}
{{--                <input type="hidden" name="redirect_url" value="{{route('back-office.posts.edit',$post)}}">--}}
{{--                <div class="my-4 text-gray-900">--}}
{{--                    <p>Are you sure you want to intercept the editing of this post? All unsaved changes from {{$post->editor->first_name}}'s side will be lost.</p>--}}
{{--                </div>--}}
{{--                <div class="flex justify-end pt-2">--}}
{{--                    <x-btn color="ghost" class="modal-close me-4" type="reset">Cancel</x-btn>--}}
{{--                    <x-btn color="red" type="submit">I'm sure</x-btn>--}}
{{--                </div>--}}
{{--            </form>--}}
{{--        </x-modal>--}}
{{--    @else--}}
        <x-icon-link color="green" href="{{route('back-office.posts.edit',$post)}}">
            <x-heroicon-o-pencil-square class="w-5 h-5"/>
        </x-icon-link>
{{--    @endif--}}
    @can('delete-posts')
        <x-modal :closeButton="true" name="Remove Page" size="lg:w-6/12">
            <x-slot name="trigger">
                <x-icon-link color="red" href="#" x-on:click="isModalOpen = true">
                    <x-heroicon-o-trash class="w-5 h-6 pt-1"/>
                </x-icon-link>
            </x-slot>
            <div class="modal-content">
                <div class="py-4">
                    <p class="text-xl text-center text-gray-900">Are you sure, that you want to delete the post absolutely?</p>
                </div>
                <hr>
                <div class="flex justify-between pt-4">
                    <x-btn color="ghost" x-on:click="isModalOpen = false" class="mr-4">Cancel</x-btn>
                    <x-btn color="red" wire:click="delete({{ $post->id }})" type="button">Sure</x-btn>
                </div>
            </div>
        </x-modal>
    @endcan
</div>
