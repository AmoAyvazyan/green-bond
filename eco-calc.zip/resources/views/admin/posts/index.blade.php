@section('title',__('Posts'))
@section('button-class','flex justify-between items-center pb-1')
@section('button')
    <x-btn :link="true" color="green" href="{{route('back-office.posts.create')}}">Add Post</x-btn>
@endsection
<x-admin-layout>
    <livewire:tables.posts-table/>
    <hr>
    <div class="flex justify-end items-center mt-5">
        <x-btn :link="true" color="green" href="{{route('back-office.posts.create')}}">Add Post</x-btn>
    </div>
</x-admin-layout>
