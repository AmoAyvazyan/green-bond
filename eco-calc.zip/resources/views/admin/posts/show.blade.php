@section('title', 'Post Details')
@section('button-class','flex justify-between items-center pb-1')
@section('button')
    <x-btn :link="true" color="green" href="{{route('back-office.posts.edit', $post)}}">Edit</x-btn>
@endsection
<x-admin-layout>
    <x-card>
        <x-detail-row label="Post Image">
            <a target="_blank" class="cursor-pointer" href="{{$post->image}}">
                <img src="{{$post->image}}" alt=""
                     class="rounded w-auto h-6">
            </a>
        </x-detail-row>
        <x-detail-row label="Title">
            @foreach($post->translations as $translation)
                {{$translation->title}} <span class="text-gray-500">|</span>
            @endforeach
        </x-detail-row>
        <x-detail-row label="Slug">{{$post->slug}}</x-detail-row>
        <x-detail-row label="Content">
            @foreach($post->translations as $translation)
                {{$translation->content}} <br/><hr class="my-4"/>
            @endforeach
        </x-detail-row>
        <x-detail-row label="Author">{{$post->author->full_name}}</x-detail-row>
        <x-detail-row label="Created">{{$post->created_at->timezone(config('app.timezone'))->format('d.m.Y H:i:s')}}</x-detail-row>
        <x-detail-row label="Published">
            <div class="flex items-center">
                @if($post->is_published)
                    <x-heroicon-o-check-circle class="w-5 h-5 inline-block mr-2 text-green-500"/>
                @else
                    <x-heroicon-o-no-symbol class="w-5 h-5 inline-block mr-2 text-red-500"/>
                @endif
                {{$post->published_at}}
            </div>
        </x-detail-row>
        <x-detail-row label="Modified" :last="true">{{$post->updated_at->timezone(config('app.timezone'))->format('d.m.Y H:i:s')}}</x-detail-row>
    </x-card>
    @include('partials.show-actions', [
        'resource' => 'posts',
        'permission' => 'delete-food',
        'model' => $post,
    ])
</x-admin-layout>
