@section('title',__('Electronic Params'))
@section('button-class','flex justify-between items-center pb-1')
@section('button')
    <x-btn :link="true" color="green" href="{{route('back-office.electronic-params.create')}}">Add Electronic Param</x-btn>
@endsection
<x-admin-layout>
    <livewire:tables.electronic-param-table/>
    <hr>
    <div class="flex justify-end items-center mt-5">
        <x-btn :link="true" color="green" href="{{route('back-office.electronic-params.create')}}">Add Electronic Param</x-btn>
    </div>
</x-admin-layout>