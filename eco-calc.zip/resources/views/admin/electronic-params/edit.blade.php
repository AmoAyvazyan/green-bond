@section('title',__('Edit Electronic Param'))
@section('select-class', 'flex justify-between items-center')
<x-admin-layout>
    <form id="editForm" enctype="multipart/form-data" method="POST"
          action="{{route('back-office.electronic-params.update',$electronicParam)}}">
        @csrf
        @method('put')
        @include('admin.electronic-params.partials.form_main')
    </form>
</x-admin-layout>