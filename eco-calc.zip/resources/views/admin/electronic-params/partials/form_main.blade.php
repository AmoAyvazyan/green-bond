@php /** @var $electronicParam \App\Models\ElectronicParam */ @endphp
<x-card>
    <div class="grid grid-cols-1 md:grid-cols-2 gap-x-10 gap-y-5">
        @if($errors->count()>0)
            <div class="col-span-full">
                <!-- Validation Errors -->
                <x-validation-errors class="mb-4" :errors="$errors"/>
            </div>
        @endif
        <div>
            <x-label for="name" :value="__('Name')"/>
            <x-input id="name" data-lang="{{$currentLocale ?? 'en'}}" class="block mt-1 w-full" type="text" name="name"
                     :value="$electronicParam->name??old('name')"
                     required/>
        </div>
        <div>
            <x-label for="slug" :value="__('Slug')"/>
            <x-input id="slug" class="block mt-1 w-full" type="text" name="slug" required
                     data-new="{{isset($electronicParam) ? 'false' : 'true'}}"
                     :value="isset($electronicParam) ? $electronicParam->slug : old('slug')"/>
        </div>
        <div>
            <x-label for="electricity_demand_old" :value="__('Electricity Demand Old')"/>
            <x-input id="electricity_demand_old" class="block mt-1 w-full" type="number" name="electricity_demand_old"
                     required
                     :value="$electronicParam->electricity_demand_old??old('electricity_demand_old')"/>
        </div>
        <div>
            <x-label for="electricity_demand_new" :value="__('Electricity Demand New')"/>
            <x-input id="electricity_demand_new" class="block mt-1 w-full" type="number" name="electricity_demand_new"
                     :value="$electronicParam->electricity_demand_new??old('electricity_demand_new')" required/>
        </div>
        <div>
            <x-label for="electricity_demand_a" :value="__('Electricity Demand A')"/>
            <x-input id="electricity_demand_a" class="block mt-1 w-full" type="number" name="electricity_demand_a"
                     :value="$electronicParam->electricity_demand_a??old('electricity_demand_a')"/>
        </div>
        <div>
            <x-label for="electricity_demand_a_plus" :value="__('Electricity Demand A+')"/>
            <x-input id="electricity_demand_a_plus" class="block mt-1 w-full" type="number" name="electricity_demand_a_plus"
                     :value="$electronicParam->{'electricity_demand_a_plus'} ?? old('electricity_demand_a_plus')" required/>
        </div>
        <div>
            <x-label for="electricity_demand_a_2plus" :value="__('Electricity Demand A++')"/>
            <x-input id="electricity_demand_a_2plus" class="block mt-1 w-full" type="number" name="electricity_demand_a_2plus"
                     :value="$electronicParam->{'electricity_demand_a_2plus'}??old('electricity_demand_a_2plus')" required/>
        </div>
        <div>
            <x-label for="electricity_demand_a_3plus" :value="__('Electricity Demand A+++')"/>
            <x-input id="electricity_demand_a_3plus" class="block mt-1 w-full" type="number" name="electricity_demand_a_3plus"
                     :value="$electronicParam->{'electricity_demand_a_3plus'}??old('electricity_demand_a_3plus')" required/>
        </div>
        <div>
            <x-label for="baseline_class" :value="__('Baseline Class')"/>
            <x-input id="baseline_class" class="block mt-1 w-full" type="text" name="baseline_class" required
                     :value="$electronicParam->baseline_class??old('baseline_class')"/>
        </div>
    </div>
</x-card>
<div class="flex justify-between items-center">
    <x-btn color="gray" :link="true" href="{{back()->getTargetUrl()}}">{{__('Back')}}</x-btn>
    <x-btn color="green">{{__('Save')}}</x-btn>
</div>