@section('title', 'Electronic Param Details')
@section('button-class','flex justify-between items-center pb-1')
@section('button')
    <x-btn :link="true" color="green" href="{{route('back-office.electronic-params.edit', $electronicParam)}}">Edit</x-btn>
@endsection
<x-admin-layout>
    <x-card>
        <x-detail-row label="Slug"> {{$electronicParam->slug}} </x-detail-row>
        <x-detail-row label="Name"> {{$electronicParam->name}} </x-detail-row>
        <x-detail-row label="Electricity Demand Old"> {{$electronicParam->electricity_demand_old}} </x-detail-row>
        <x-detail-row label="Electricity Demand New"> {{$electronicParam->electricity_demand_new}} </x-detail-row>
        <x-detail-row label="Electricity Demand A"> {{$electronicParam->electricity_demand_a}} </x-detail-row>
        <x-detail-row label="Electricity Demand A+"> {{  $electronicParam->{'electricity_demand_a_plus'} }} </x-detail-row>
        <x-detail-row label="Electricity Demand A++"> {{  $electronicParam->{'electricity_demand_a_2plus'} }} </x-detail-row>
        <x-detail-row label="Electricity Demand A+++"> {{  $electronicParam->{'electricity_demand_a_3plus'} }} </x-detail-row>
        <x-detail-row label="Baseline Class"> {{$electronicParam->baseline_class}} </x-detail-row>
        <x-detail-row label="Created">
            {{$electronicParam->created_at->timezone(config('app.timezone'))->format('d.m.Y H:i:s')}}
        </x-detail-row>
        <x-detail-row label="Modified" :last="true">
            {{$electronicParam->updated_at->timezone(config('app.timezone'))->format('d.m.Y H:i:s')}}
        </x-detail-row>
    </x-card>
    @include('partials.show-actions', [
        'resource' => 'electronic-params',
        'permission' => 'delete-settings',
        'model' => $electronicParam,
    ])
</x-admin-layout>