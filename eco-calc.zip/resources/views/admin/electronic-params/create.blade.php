@section('title',__('Add Electronic Param'))
@section('select-class', 'flex justify-between items-center')
<x-admin-layout>
    <form id="createForm" enctype="multipart/form-data" method="POST" action="{{route('back-office.electronic-params.store')}}">
        @csrf
        @include('admin.electronic-params.partials.form_main')
    </form>
</x-admin-layout>