@section('title',__('Edit Mortgage Loan Request'))
@section('select-class', 'flex justify-between items-center')
<x-admin-layout>
    <form id="editForm" enctype="multipart/form-data" method="POST"
          action="{{route('back-office.mortgage-loan-requests.update',$mortgageLoanRequest)}}">
        @csrf
        @method('put')
        @include('admin.mortgage-loans-request.partials.form_main')
    </form>
</x-admin-layout>