@section('title', 'Mortgage Loan Request Details')
@section('button-class','flex justify-between items-center pb-1')
@section('button')
    <x-btn :link="true" color="green" href="{{route('back-office.mortgage-loan-requests.edit', $mortgageLoanRequest)}}">
        Edit
    </x-btn>
@endsection
<x-admin-layout>
    <x-card>
        <x-detail-row label="Community">
            @if($community)
                <x-link href="{{route('back-office.communities.show', $community)}}">
                    @foreach($community->translations as $translation)
                        {{$translation->name}}
                        <span class="text-gray-500">|</span>
                    @endforeach
                </x-link>
            @else
                <span>-</span>
            @endif
        </x-detail-row>
        <x-detail-row label="Partner">
            @if($partner)
                <x-link href="{{route('back-office.partners.show', $partner)}}">
                    @foreach($partner->translations as $translation)
                        {{$translation->name}}
                        <span class="text-gray-500">|</span>
                    @endforeach
                </x-link>
            @else
                <span>-</span>
            @endif
        </x-detail-row>
        <x-detail-row label="Region">
            @if($region)
                <x-link href="{{route('back-office.regions.show', $region)}}">
                    @foreach($region->translations as $translation)
                        {{$translation->name}}
                        <span class="text-gray-500">|</span>
                    @endforeach
                </x-link>
            @else
                <span>-</span>
            @endif
        </x-detail-row>
        <x-detail-row label="Building">
            @if($building)
                <x-link href="{{route('back-office.buildings.show', $building)}}">
                    @foreach($building->translations as $translation)
                        {{$translation->title}}
                        <span class="text-gray-500">|</span>
                    @endforeach
                </x-link>
            @else
                <span>-</span>
            @endif
        </x-detail-row>
        <x-detail-row label="Code"> {{$mortgageLoanRequest->code}} </x-detail-row>
        <x-detail-row label="CO2 Reduction"> {{$mortgageLoanRequest->co2_reduction}} </x-detail-row>
        <x-detail-row label="Area"> {{$mortgageLoanRequest->area}} </x-detail-row>
        <x-detail-row label="Apartment Number"> {{$mortgageLoanRequest->apartment_number}} </x-detail-row>
        <x-detail-row label="Energy Savings"> {{number_format($mortgageLoanRequest->energy_savings,2,'.',' ')}} </x-detail-row>
        <x-detail-row label="Property Type"> {{ucfirst($mortgageLoanRequest->property_type)}} </x-detail-row>
        <x-detail-row label="Type"> {{ucfirst($mortgageLoanRequest->type)}} </x-detail-row>
        <x-detail-row label="Status"> {{ucfirst($mortgageLoanRequest->status)}} </x-detail-row>
        <x-detail-row label="Amount Total">{{$mortgageLoanRequest->total_amount ? number_format($mortgageLoanRequest->total_amount,0,'.',' ') . ' ' . __('phrases.amd') : '-'}} </x-detail-row>
        <x-detail-row label="Amount Refinanced"> {{$mortgageLoanRequest->amount_refinanced ? number_format($mortgageLoanRequest->amount_refinanced,0,'.',' ') . ' ' . __('phrases.amd') : '-'}} </x-detail-row>
        <x-detail-row label="Loaner Sex"> {{$mortgageLoanRequest->loaner_sex ?? '-'}} </x-detail-row>
        <x-detail-row label="Loaner Revenue"> {{$mortgageLoanRequest->loaner_revenue ? number_format($mortgageLoanRequest->loaner_revenue,0,'.',' ') . ' ' . __('phrases.amd') : '-'}} </x-detail-row>
        <x-detail-row label="Funding Source"> {{$mortgageLoanRequest->funding_source}} </x-detail-row>
        <x-detail-row label="File">
            <x-link target="_blank" href="{{$mortgageLoanRequest->file}}"> {{$mortgageLoanRequest->file}} </x-link>
        </x-detail-row>
        <x-detail-row label="Refinanced">
            {{$mortgageLoanRequest->refinanced_at?->timezone(config('app.timezone'))->format('d.m.Y H:i:s') ?? '-'}}
        </x-detail-row>
        <x-detail-row label="Called Back">
            {{$mortgageLoanRequest->rejected_at?->timezone(config('app.timezone'))->format('d.m.Y H:i:s') ?? '-'}}
        </x-detail-row>
        <x-detail-row label="Created">
            {{$mortgageLoanRequest->created_at->timezone(config('app.timezone'))->format('d.m.Y H:i:s')}}
        </x-detail-row>
        <x-detail-row label="Modified" :last="true">
            {{$mortgageLoanRequest->updated_at->timezone(config('app.timezone'))->format('d.m.Y H:i:s')}}
        </x-detail-row>
    </x-card>
    @include('partials.show-actions', [
        'resource' => 'mortgage-loan-requests',
        'permission' => 'delete-loan-requests',
        'editPermission' => 'edit-loan-requests',
        'model' => $mortgageLoanRequest,
    ])
</x-admin-layout>