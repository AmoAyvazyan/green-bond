@section('title',__('Mortgage Loan Requests'))
@section('button-class','flex justify-between items-center pb-1')
@if($isNotApproved)
    @section('button')
        @include('partials.bulk_approve_button', ['type' => 'mortgage'])
    @endsection
@endif
<x-admin-layout>
    <livewire:tables.mortgage-loan-request-table/>
</x-admin-layout>