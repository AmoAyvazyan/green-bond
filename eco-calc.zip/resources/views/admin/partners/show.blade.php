@section('title', 'Partner Details')
@section('button-class','flex justify-between items-center pb-1')
@section('button')
    <x-btn :link="true" color="green" href="{{route('back-office.partners.edit', $partner)}}">Edit</x-btn>
@endsection
<x-admin-layout>
    <x-card>
        <x-detail-row label="Sort Order">{{$partner->sort_order}}</x-detail-row>
        <x-detail-row label="Slug">{{$partner->slug}}</x-detail-row>
        <x-detail-row label="Partner Image">
            <a target="_blank" class="cursor-pointer" href="{{$partner->logo}}">
                <img src="{{$partner->logo}}" alt="" height="128" width="128"
                     class="h-50 w-auto">
            </a>
        </x-detail-row>
        <x-detail-row label="Name">
            @foreach($partner->translations as $translation)
                {{$translation->name}}
                <span class="text-gray-500">|</span>
            @endforeach
        </x-detail-row>
        <x-detail-row label="Description">
            @foreach($partner->translations as $translation)
                {!!$translation->description!!}
                <span class="text-gray-500">|</span>
            @endforeach
        </x-detail-row>
        <x-detail-row label="Contact Email">
            <x-link href="mailto:{{$partner->contact_email}}">{{$partner->contact_email}}</x-link>
        </x-detail-row>
        <x-detail-row label="Contact Phone">
            <x-link href="tel:{{$partner->contact_phone}}">{{$partner->contact_phone}}</x-link>
        </x-detail-row>
        <x-detail-row label="Url">
            <x-link href="{{$partner->url}}">{{$partner->url}}</x-link>
        </x-detail-row>
        <x-detail-row label="Address">
            @foreach($partner->translations as $translation)
                {{$translation->address}}
                <span class="text-gray-500">|</span>
            @endforeach
        </x-detail-row>
        <x-detail-row label="Active">
            @if($partner->is_active)
                <x-heroicon-o-check-circle class="w-5 h-5 text-green-500"/>
            @else
                <x-heroicon-o-no-symbol class="w-5 h-5 text-red-500"/>
            @endif
        </x-detail-row>
        <x-detail-row label="Created">
            {{$partner->created_at->timezone(config('app.timezone'))->format('d.m.Y H:i:s')}}
        </x-detail-row>
        <x-detail-row label="Modified" :last="true">
            {{$partner->updated_at->timezone(config('app.timezone'))->format('d.m.Y H:i:s')}}
        </x-detail-row>
    </x-card>
    @include('partials.show-actions', [
        'resource' => 'partners',
        'permission' => 'delete-settings',
        'model' => $partner,
    ])
</x-admin-layout>
