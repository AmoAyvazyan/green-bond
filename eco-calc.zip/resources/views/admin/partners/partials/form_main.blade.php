@php /** @var $partner \App\Models\Partner */ @endphp
<x-card>
    <div class="grid grid-cols-1 md:grid-cols-2 gap-x-10 gap-y-5">
        @if($errors->count()>0)
            <div class="col-span-full">
                <!-- Validation Errors -->
                <x-validation-errors class="mb-4" :errors="$errors"/>
            </div>
        @endif
        <div>
            <x-label for="name" :value="__('Name')"/>
            <x-input id="name" data-lang="{{$currentLocale ?? 'en'}}" class="block mt-1 w-full" type="text" name="name"
                     :value="isset($partner) && $partner->translate($currentLocale) ? $partner->translate($currentLocale ?? 'en')?->name : old('name')"
                     required/>
        </div>
        <div>
            <x-label for="slug" :value="__('Slug')"/>
            <x-input id="slug" class="block mt-1 w-full" type="text" name="slug" required
                     data-new="{{isset($partner) ? 'false' : 'true'}}"
                     :value="isset($partner) ? $partner->slug : old('slug')"/>
        </div>
        <div>
            <x-label for="sort_order" :value="__('Sort Order')"/>
            <x-input id="sort_order" class="block mt-1 w-full" type="number" name="sort_order" required
                     :value="isset($partner) ? $partner->sort_order : old('sort_order')"/>
        </div>
        <div>
            <x-label for="contact_phone" :value="__('Contact Phone')"/>
            <x-input id="contact_phone" class="block mt-1 w-full" type="text" name="contact_phone" required
                     x-on:input="event.target.value = event.target.value.replace(/[^0-9]/g, '')"
                     :value="$partner->contact_phone??old('contact_phone')"/>
        </div>
        <div>
            <x-label for="contact_email" :value="__('Contact Email')"/>
            <x-input id="contact_email" class="block mt-1 w-full" type="email" name="contact_email" required
                     :value="$partner->contact_email??old('contact_email')"/>
        </div>
        <div>
            <x-label for="url" :value="__('Url')"/>
            <x-input id="url" class="block mt-1 w-full" type="text" name="url" required
                     :value="$partner->url??old('url')"/>
        </div>
        <div>
            <x-label for="address" :value="__('Address')"/>
            <x-input id="address" class="block mt-1 w-full" type="text" name="address" required
                     :value="isset($partner) && $partner->translate($currentLocale) ? $partner->translate($currentLocale ?? 'en')?->address : old('address')"/>
        </div>
        <div>
            <x-label for="logo" :value="__('Logo (min: 128x128)')"/>
            @isset($partner)
                <div class="flex items-center justify-between">
                    <x-input-file id="logo" name="logo" class="w-full" :value="__('Edit logo')"/>
                    <a target="_blank" href="{{$partner->logo}}"><img
                            class="w-10 h-10 object-cover object-center rounded shadow-md ml-2" src="{{$partner->logo}}"
                            alt="{{$partner->logo}}"></a>
                </div>
            @else
                <x-input-file id="logo" name="logo" class="" :value="__('Upload logo')"/>
            @endif
        </div>
        <div class="col-span-full flex">
            <div class="items-center">
                <x-checkbox value="1" :checked="$partner->is_active??old('is_active')" name="is_active" id="is_active"
                            class="block ms-4 mt-5 mr-8">{{__('Active')}}</x-checkbox>
            </div>
        </div>
        <div class="col-span-full">
            <x-label for="description" class="mb-1" :value="__('Description')"/>
            <x-editor id="description" name="description">
                {!! isset($partner) && $partner->translate($currentLocale)
                    ? $partner->translate($currentLocale)->getRawOriginal('description')
                    : old('description') !!}
            </x-editor>
        </div>
    </div>
</x-card>
<div class="flex justify-between items-center">
    <x-btn color="gray" :link="true" href="{{back()->getTargetUrl()}}">{{__('Back')}}</x-btn>
    <x-btn color="green">{{__('Save')}}</x-btn>
</div>
