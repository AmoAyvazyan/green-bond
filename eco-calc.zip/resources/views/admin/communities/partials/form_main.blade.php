@php /** @var $community \App\Models\Community */ @endphp
<x-card>
    <div class="grid grid-cols-1 md:grid-cols-2 gap-x-10 gap-y-5">
        @if($errors->count()>0)
            <div class="col-span-full">
                <!-- Validation Errors -->
                <x-validation-errors class="mb-4" :errors="$errors"/>
            </div>
        @endif
        <div>
            <x-label for="name" :value="__('Name')"/>
            <x-input id="name" data-lang="{{$currentLocale ?? 'en'}}" class="block mt-1 w-full" type="text" name="name"
                     :value="isset($community) && $community->translate($currentLocale) ? $community->translate($currentLocale ?? 'en')?->name : old('name')"
                     required/>
        </div>
        <div>
            <x-label for="slug" :value="__('Slug')"/>
            <x-input id="slug" class="block mt-1 w-full" type="text" name="slug" required
                     data-new="{{isset($community) ? 'false' : 'true'}}"
                     :value="isset($community) ? $community->slug : old('slug')"/>
        </div>
        <div>
            <x-label for="region_id" :value="__('Region')"/>
            <x-custom-select name="region_id" id="region_id" class="block mt-1 w-full" required>
                @forelse($regions as $region)
                    <option
                        {{($community?->region->is($region)
                            || old('region_id') == $region->id) ? 'selected' : ''}}
                        value="{{$region->id}}">{{$region->translate($currentLocale ?? 'hy')->name}}</option>
                @empty
                    <option value="" disabled selected>{{__('There are no any region')}}</option>
                @endforelse
            </x-custom-select>
        </div>
    </div>
</x-card>
<div class="flex justify-between items-center">
    <x-btn color="gray" :link="true" href="{{back()->getTargetUrl()}}">{{__('Back')}}</x-btn>
    <x-btn color="green">{{__('Save')}}</x-btn>
</div>