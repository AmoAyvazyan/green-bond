@section('title',__('Add Community'))
@section('select-class', 'flex justify-between items-center')
@section('select')
    <x-select name="translation_locale" id="translation_locale" form="createForm" disabled>
        @foreach($locales as $code=>$locale)
            <option value="{{$code}}">{{$locale['native']}}</option>
        @endforeach
    </x-select>
@endsection
<x-admin-layout>
    <form id="createForm" enctype="multipart/form-data" method="POST" action="{{route('back-office.communities.store')}}">
        @csrf
        @include('admin.communities.partials.form_main')
    </form>
</x-admin-layout>