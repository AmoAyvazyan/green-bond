@section('title', 'Community Details')
@section('button-class','flex justify-between items-center pb-1')
@section('button')
    <x-btn :link="true" color="green" href="{{route('back-office.communities.edit', $community)}}">
        Edit
    </x-btn>
@endsection
<x-admin-layout>
    <x-card>
        <x-detail-row label="Slug"> {{$community->slug}} </x-detail-row>
        <x-detail-row label="Name">
            @foreach($community->translations as $translation)
                {{$translation->name}}
                <span class="text-gray-500">|</span>
            @endforeach
        </x-detail-row>
        <x-detail-row label="Region">
            <x-link href="{{route('back-office.regions.show', $region)}}">
                {{$region->translate('hy') ? $region->translate('hy')->name : ''}} |
                {{$region->translate('en') ? $region->translate('en')->name : ''}}
            </x-link>
        </x-detail-row>
        <x-detail-row label="Created">
            {{$community->created_at->timezone(config('app.timezone'))->format('d.m.Y H:i:s')}}
        </x-detail-row>
        <x-detail-row label="Modified" :last="true">
            {{$community->updated_at->timezone(config('app.timezone'))->format('d.m.Y H:i:s')}}
        </x-detail-row>
    </x-card>

    @if($complexes->isNotEmpty())
        <h2 class="text-xl mb-3 font-bold">Complexes</h2>
        <x-card>
            @foreach($complexes as $complex)
                <x-detail-row :last="$loop->last" label="{{$complex->translate('en')->name}}">
                    <x-link href="{{route('back-office.residential-complexes.show', $complex)}}">View</x-link>
                    <span class="text-gray-500">|</span>
                    <span>{{$complex->address}}</span>
                </x-detail-row>
            @endforeach
        </x-card>
    @endif
    @include('partials.show-actions', [
        'resource' => 'communities',
        'permission' => 'delete-settings',
        'model' => $community,
    ])
</x-admin-layout>