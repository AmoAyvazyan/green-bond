@section('title', 'Region Details')
@section('button-class','flex justify-between items-center pb-1')
@section('button')
    <x-btn :link="true" color="green" href="{{route('back-office.regions.edit', $region)}}">Edit</x-btn>
@endsection
<x-admin-layout>
    <x-card>
        <x-detail-row label="Name">
            @foreach($region->translations as $translation)
                {{$translation->name}}
                <span class="text-gray-500">|</span>
            @endforeach
        </x-detail-row>
        <x-detail-row label="HH, 30-year validity (min.)"> {{$region->hh_30_year}} </x-detail-row>
        <x-detail-row label="HDD, shared weighted average, apartment"> {{$region->hdd_average_apartment}} </x-detail-row>
        <x-detail-row label="HDD, shared weighted average, SFH"> {{$region->hdd_average_sfh}} </x-detail-row>
        <x-detail-row label="HDD, weight average per region (normative)"> {{$region->hdd_average_normative}} </x-detail-row>
        <x-detail-row label="Created">
            {{$region->created_at->timezone(config('app.timezone'))->format('d.m.Y H:i:s')}}
        </x-detail-row>
        <x-detail-row label="Modified" :last="true">
            {{$region->updated_at->timezone(config('app.timezone'))->format('d.m.Y H:i:s')}}
        </x-detail-row>
    </x-card>
    @include('partials.show-actions', [
        'resource' => 'regions',
        'permission' => 'delete-settings',
        'model' => $region,
    ])
</x-admin-layout>