@php /** @var $region \App\Models\Region */ @endphp
<x-card>
    <div class="grid grid-cols-1 md:grid-cols-2 gap-x-10 gap-y-5">
        @if($errors->count()>0)
            <div class="col-span-full">
                <!-- Validation Errors -->
                <x-validation-errors class="mb-4" :errors="$errors"/>
            </div>
        @endif
        <div>
            <x-label for="name" :value="__('Name')"/>
            <x-input id="name" data-lang="{{$currentLocale ?? 'en'}}" class="block mt-1 w-full" type="text" name="name"
                     :value="isset($region) && $region->translate($currentLocale) ? $region->translate($currentLocale ?? 'en')?->name : old('name')"
                     required/>
        </div>
        <div>
            <x-label for="hh_30_year" :value="__('HH, 30-year validity (min.)')"/>
            <x-input id="hh_30_year" class="block mt-1 w-full" type="text" inputmode="numeric"
                     pattern="[0-9]*[.]?[0-9]+" name="hh_30_year" required
                     :value="isset($region) ? $region->hh_30_year : old('hh_30_year')"/>
        </div>
        <div>
            <x-label for="hdd_average_apartment" :value="__('HDD, shared weighted average, apartment')"/>
            <x-input id="hdd_average_apartment" class="block mt-1 w-full" type="text" inputmode="numeric"
                     pattern="[0-9]*[.]?[0-9]+" name="hdd_average_apartment" required
                     :value="isset($region) ? $region->hdd_average_apartment : old('hdd_average_apartment')"/>
        </div>
        <div>
            <x-label for="hdd_average_sfh" :value="__('HDD, shared weighted average, SFH')"/>
            <x-input id="hdd_average_sfh" class="block mt-1 w-full" type="text" inputmode="numeric"
                     pattern="[0-9]*[.]?[0-9]+" name="hdd_average_sfh" required
                     :value="isset($region) ? $region->hdd_average_sfh : old('hdd_average_sfh')"/>
        </div>
        <div>
            <x-label for="hdd_average_normative" :value="__('HDD, weight average per region (normative)')"/>
            <x-input id="hdd_average_normative" class="block mt-1 w-full" type="text" inputmode="numeric"
                     pattern="[0-9]*[.]?[0-9]+" name="hdd_average_normative" required
                     :value="isset($region) ? $region->hdd_average_normative : old('hdd_average_normative')"/>
        </div>
    </div>
</x-card>
<div class="flex justify-between items-center">
    <x-btn color="gray" :link="true" href="{{back()->getTargetUrl()}}">{{__('Back')}}</x-btn>
    <x-btn color="green">{{__('Save')}}</x-btn>
</div>