<footer class="bg-black pt-12 pb-10">
    <x-container class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-y-12 text-lg text-white">
        <div class="col-span-5 flex justify-center md:hidden">
            <a href="https://www.nmc.am" target="_blank"
               class="cursor-pointer" aria-label="NMC">
                <x-application-logo-nmc class="text-white w-[100px] h-auto"/>
            </a>
        </div>
        <div class="col-span-5 md:col-auto md:flex flex-col items-center md:items-start space-y-5 hidden">
            <div class="flex space-x-7">
                <x-icon-link aria-label="Official business page on LinkedIn"
                             href="{{settings('linked_in_url')}}" rel="nofollow" target="_blank">
                    <x-icons.linkedin class="size-5"/>
                </x-icon-link>
                <x-icon-link aria-label="Official page on Facebook"
                             href="{{settings('fb_url')}}" rel="nofollow" target="_blank">
                    <x-icons.fb class="h-5 w-auto"/>
                </x-icon-link>
            </div>
            <div class="flex items-center space-x-2">
                <x-icons.mail class="w-3 h-auto text-white"/>
                <x-link-light href="mailto:{{settings('info_email')}}">{{settings('info_email')}}</x-link-light>
            </div>
            <div class="flex items-center space-x-2">
                <x-icons.phone class="w-3 h-auto text-white"/>
                <x-link-light href="tel:{{settings('info_phone')}}">{{settings('info_phone')}}</x-link-light>
            </div>
        </div>
        <div class="col-span-5 md:col-auto flex flex-col space-y-5 items-center md:items-start">
            <x-link-light class="text-center xs:text-start xs:whitespace-nowrap"
                          href="{{route('front.terms.privacy-policy')}}">{{__('phrases.privacy_policy')}}</x-link-light>
            <x-link-light
                href="{{route('front.terms.legal-notice')}}">{{__('phrases.legal_notice')}}</x-link-light>
        </div>
        <div class="hidden md:block"></div>
        <div class="flex flex-col space-y-5 items-center md:items-start">
            <x-link-light class="text-center xs:text-start xs:whitespace-nowrap"
                          href="{{route('front.calculators.mortgage')}}">{{__('phrases.property_acquisition_title')}}</x-link-light>
            <x-link-light href="{{route('front.calculators.renovation')}}">{{__('phrases.repair_title')}}</x-link-light>
            <x-link-light
                href="{{route('front.calculators.construction')}}">{{__('phrases.construction_residential_house_title')}}</x-link-light>
        </div>
        <div class="hidden md:flex justify-end">
            <a href="https://www.nmc.am" target="_blank"
               class="cursor-pointer" aria-label="NMC">
                <x-application-logo-nmc class="text-white w-[100px] h-auto"/>
            </a>
        </div>
        <div class="col-span-5 md:col-auto flex flex-col items-center md:items-start space-y-5 md:hidden">
            <div class="flex space-x-7">
                <x-icon-link aria-label="Official business page on LinkedIn"
                             href="{{settings('linked_in_url')}}" rel="nofollow" target="_blank">
                    <x-icons.linkedin class="size-5"/>
                </x-icon-link>
                <x-icon-link aria-label="Official page on Facebook"
                             href="{{settings('fb_url')}}" rel="nofollow" target="_blank">
                    <x-icons.fb class="h-5"/>
                </x-icon-link>
            </div>
            <div class="flex items-center space-x-2">
                <x-icons.mail class="w-3 h-auto text-white"/>
                <x-link-light href="mailto:{{settings('info_email')}}">{{settings('info_email')}}</x-link-light>
            </div>
            <div class="flex items-center space-x-2">
                <x-icons.phone class="w-3 h-auto text-white"/>
                <x-link-light href="tel:{{settings('info_phone')}}">{{settings('info_phone')}}</x-link-light>
            </div>
        </div>
        <div class="flex flex-col items-center justify-center col-span-5">
            <div class="flex flex-col md:items-end lg:col-span-2">
                <span class="text-center xs:text-start xs:whitespace-nowrap text-[10px] md:text-base">&copy; {{__('phrases.copyright')}} ® ©{{date("Y")}} green.nmc.am </span>
            </div>
            <div class="flex justify-center items-center mt-7">
                <span class="font-display text-center xs:text-start xs:whitespace-nowrap mr-2">Made by</span>
                <a href="https://www.instagram.com/friday_marketing_/" target="_blank" rel="noreferrer"
                   class="cursor-pointer" aria-label="Friday Design & Development">
                    <img width="77" height="24" class="lazyload" data-src="{{asset('images/friday_logo.png')}}"
                         alt="Friday Design & Development" src="">
                </a>
            </div>
        </div>
    </x-container>
</footer>
