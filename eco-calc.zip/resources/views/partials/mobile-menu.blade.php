@php($isDark = (isset($dark) && $dark))
@php($align = $align ?? 'right')
<x-dropdown-mobile-menu :align="$align" width="full" content-classes>
    <x-slot name="trigger">
        <button id="hamburger"
                class="inline-flex items-center justify-center focus:outline-none transition duration-150 ease-in-out">
            <svg  viewBox="473.0756 246.9526 20.2994 11.4598" width="24" height="24" xmlns="http://www.w3.org/2000/svg">
                <mask id="mask0_942_6565" style="mask-type:alpha" maskUnits="userSpaceOnUse" x="0" y="0" width="24" height="24">
                    <rect width="24" height="24" fill="currentColor"/>
                </mask>
                <g mask="url(#mask0_942_6565)" transform="matrix(1.1277459859848022, 0, 0, 0.6811169981956482, 469.69233577526575, 244.2281566926286)" style="">
                    <path d="M 9 20.825 L 9 18.021 L 21 18.021 L 21 20.825 L 9 20.825 Z M 3 13.815 L 3 11.011 L 21 11.011 L 21 13.815 L 3 13.815 Z M 9 6.804 L 9 4 L 21 4 L 21 6.804 L 9 6.804 Z" fill="currentColor"/>
                </g>
            </svg>
        </button>
    </x-slot>
    <x-slot name="content">
        @include('partials.menu-items', ['mobile' => true])
    </x-slot>
</x-dropdown-mobile-menu>
