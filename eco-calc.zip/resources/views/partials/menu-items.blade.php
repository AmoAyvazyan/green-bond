<div class="w-full h-full flex flex-col justify-between px-5">
    <div class="flex flex-col items-center justify-center">
        <div class="flex flex-col space-y-10 items-center">
            <x-responsive-nav-link class="text-white hover:text-white !text-2xl" href="{{route('front.calculators.mortgage')}}">{{__('phrases.property_acquisition_title')}}</x-responsive-nav-link>
            <x-responsive-nav-link class="text-white hover:text-white !text-2xl" href="{{route('front.calculators.renovation')}}">{{__('phrases.repair_title')}}</x-responsive-nav-link>
            <x-responsive-nav-link class="text-white hover:text-white !text-2xl" href="{{route('front.calculators.construction')}}">{{__('phrases.construction_residential_house_title')}}</x-responsive-nav-link>
        </div>
        <div class="flex items-center justify-between space-x-4 mb-40 mt-40">
            @unless(request()->is('back-office/login'))
                <div class="lang-switcher lg:flex items-center border p-2 rounded-[48px]"
                     x-data="{locale:{hy:false}}"
                     x-init="locale['{{app()->getLocale()}}'] = true"
                >
                    @foreach(config('laravellocalization.supportedLocales') as $code => $locale)
                        <a class="capitalize text-white text-lg font-mono hover:bg-white transition duration-150 rounded-[36px] px-4 py-1 md:py-2 hover:text-black
                            {{$code === app()->getLocale() ? 'active' : ''}}"
                           hreflang="{{$code}}"
                           href="{{LaravelLocalization::getLocalizedURL($code)}}"
                        >{{$locale['shortname']}}</a>
                    @endforeach
                </div>
            @endunless
        </div>
        <div class="col-span-5 md:col-auto h-full flex flex-col items-center md:items-start space-y-5 md:hidden">
            <div class="flex space-x-7">
                <x-icon-link aria-label="Official business page on LinkedIn"
                             href="" rel="nofollow" target="_blank">
                    <x-icons.linkedin class="size-5"/>
                </x-icon-link>
                <x-icon-link aria-label="Official page on Facebook"
                             href="" rel="nofollow" target="_blank">
                    <x-icons.fb class="h-5"/>
                </x-icon-link>
            </div>
            <div class="flex items-center space-x-2">
                <x-icons.mail class="w-3 h-auto text-white"/>
                <x-link-light href="mailto:{{settings('info_email')}}">{{settings('info_email')}}</x-link-light>
            </div>
            <div class="flex items-center space-x-2">
                <x-icons.phone class="w-3 h-auto text-white"/>
                <x-link-light href="tel:{{settings('info_phone')}}">{{settings('info_phone')}}</x-link-light>
            </div>
        </div>
    </div>
</div>
