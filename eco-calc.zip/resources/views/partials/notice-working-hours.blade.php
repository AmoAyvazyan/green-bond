@if(now(config('app.timezone'))->format('d.m.Y') !== settings('block_day', $settings)
            && (now(config('app.timezone'))->lt(\Illuminate\Support\Carbon::createFromTimeString(\App\Models\Setting::WORKING_TIME_START)->subHour())
                  || now(config('app.timezone'))->gt(\Illuminate\Support\Carbon::createFromTimeString(\App\Models\Setting::WORKING_TIME_END)->subHour())
                  || now(config('app.timezone'))->isWeekend()
                )
        )
    <x-popup-notice name="working hours">
        <p>{!! __('phrases.working_hours') !!}</p>
    </x-popup-notice>
@endif
@if(now(config('app.timezone'))->format('d.m.Y') === settings('block_day', $settings))
    <x-popup-notice :hiding-hours-count="3" name="not working day">
        <p>{!! __('phrases.not_working_day') !!}</p>
    </x-popup-notice>
@endif