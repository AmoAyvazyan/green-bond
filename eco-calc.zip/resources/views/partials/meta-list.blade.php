<meta property="og:type" content="@yield('type', 'website')">
<meta name="title" content="@yield('meta-title',__('metas.general'))">
<meta property="og:title" content="@yield('meta-title',__('metas.general'))">
<meta property="twitter:title" content="@yield('meta-title',__('metas.general'))">
<meta name="description" content="@yield('description',__('metas.description'))">
<meta property="og:description" content="@yield('description',__('metas.description'))">
<meta property="twitter:description" content="@yield('description',__('metas.description'))">
<meta name="robots" content="index, follow, max-image-preview:large, max-snippet:-1, max-video-preview:-1">
<meta http-equiv="content-language" content="{{app()->getLocale()}}">
<meta http-equiv="content-type" content="text/html; charset=utf-8">
<link rel="canonical" href="{{LaravelLocalization::getLocalizedURL('en')}}"/>
@foreach(config('laravellocalization.supportedLocales') as $code => $locale)
    @continue($code === 'en')
    <link rel="alternate" hreflang="{{$code}}" href="{{LaravelLocalization::getLocalizedURL($code)}}">
@endforeach
<meta property="og:locale" content="{{app()->getLocale()}}">
<meta property="og:url" content="{{request()->fullUrl()}}">
<meta property="og:site_name" content="{{__('metas.general')}}">
<meta name="twitter:card" content="summary_large_image">
<meta name="twitter:site" content="@nmc">
<meta name="twitter:creator" content="@nmc">
<meta property="og:image" content="@yield('image', asset('images/meta_image.jpg'))">
<meta property="twitter:image" content="@yield('image', asset('images/meta_image.jpg'))">
<meta property="og:image:width" content="1200">
<meta property="og:image:height" content="630">
<link rel="shortcut icon" sizes="any" href="{{asset('images/favicon/favicon.svg')}}">
<link rel="icon" href="{{asset('images/favicon/favicon.svg')}}" sizes="any" type="image/svg+xml">
<link rel="apple-touch-icon" sizes="any" href="{{asset('images/favicon/favicon.svg')}}">
<link rel="manifest" href="{{asset('images/favicon/site.webmanifest')}}">
<link rel="mask-icon" href="{{asset('images/favicon/safari-pinned-tab.svg')}}" color="#0ab64f">
<meta name="msapplication-TileColor" content="#000000">
<meta name="msapplication-config" content="{{asset('images/favicon/browserconfig.xml')}}">
<meta name="theme-color" content="#000000">
<meta name="author" content="Apricode Team Armenia"/>
<meta name="copyright" content="&copy; {{date('Y')}} National Mortgage Company">
<meta http-equiv="cache-control" content="no-cache, no-store, must-revalidate, max-age=0">
@yield('post_meta','')

