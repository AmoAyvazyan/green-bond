@php($currentLocale = str_replace('_', '-', app()->getLocale()))
<section class="py-6 flex lg:block overflow-scroll lg:overflow-visible pb-6 lg:pb-0">
    <x-nav-card-link class="whitespace-nowrap" href="{{route('front.terms.definitions')}}"
                     :active="request()->is(($currentLocale ?? 'en').'/terms')">{{__('terms.definitions')}}</x-nav-card-link>
</section>
