<div class="px-12 pt-10 pb-11 mb-12 bg-cover bg-center lazyload" data-bg="{{asset('images/arnament.png')}}">
    <p class="text-center font-bold font-mono text-xl mb-1">{{__('phrases.social_share_first')}}</p>
    <p class="text-center font-bold font-mono text-xl mb-8">{{__('phrases.social_share_second')}}</p>
    <div class="flex justify-center items-center">
        <x-icon-btn aria-label="Share on Facebook" class="mx-4" href="javascript:void(0);"
                     onclick="window.open('https://www.facebook.com/sharer.php?u=' + encodeURIComponent(document.location), '_blank', 'width=600,height=500'); return false;">
            <x-icons.fb class="w-11 h-11 text-yellow-500 hover:opacity-100 hover:text-green-500"></x-icons.fb>
        </x-icon-btn>
        <x-icon-btn aria-label="Share on Whatsapp" class="mx-4" href="javascript:void(0);" data-action="share/whatsapp/share"
                     onclick="window.open('https://api.whatsapp.com/send?text=' + encodeURIComponent(document.location), '_blank', 'width=600,height=500'); return false;">
            <x-icons.wa class="w-11 h-11 text-yellow-500 hover:opacity-100 hover:text-green-500"></x-icons.wa>
        </x-icon-btn>
    </div>
</div>
