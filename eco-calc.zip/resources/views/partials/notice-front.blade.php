<section x-cloak x-init="checkCookie()"
         x-transition:enter="ease-out duration-300"
         x-transition:enter-start="opacity-0 translate-y-4 sm:translate-y-0 sm:scale-95"
         x-transition:enter-end="opacity-100 translate-y-0 sm:scale-100"
         x-transition:leave="ease-in duration-200"
         x-transition:leave-start="opacity-100 translate-y-0 sm:scale-100"
         x-transition:leave-end="opacity-0 translate-y-4 sm:translate-y-0 sm:scale-95"
         role="dialog"
         x-show="isNoticeOpen"
         class="heading-notice bg-yellow-500">
    <x-container class="py-3 pr-8 relative">
        <span class="text-xs font-medium leading-none text-black">{{__('phrases.notification')}}</span>
        <x-icon-btn color="black" x-on:click="setCookie(6)"
                     class="absolute top-4 w-4 h-4 right-4">
            <x-icon-x class="w-3 h-3"/>
        </x-icon-btn>
    </x-container>
</section>
