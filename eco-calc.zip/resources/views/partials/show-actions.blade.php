<div class="flex flex-col md:flex-row justify-between items-center">
    <x-btn color="gray" class="mb-3 md:mb-0 w-full md:w-auto" :link="true" href="{{back()->getTargetUrl()}}">Back</x-btn>
    @if(isset($permission) && $permission && Auth::user()->can($permission))
        <x-modal :closeButton="true" name="Remove {{strtolower(class_basename(get_class($model)))}}">
            <x-slot name="trigger">
                <x-btn color="red" class="mb-3 md:mb-0 !w-full md:w-auto" type="button" x-on:click="isModalOpen = true">Delete</x-btn>
            </x-slot>
            <div class="modal-content">
                <form id="deleteForm" action="{{route('back-office.'.$resource.'.destroy', $model)}}" method="POST">
                    @csrf
                    @method('delete')
                    <div class="py-4">
                        <p class="text-xl text-center text-gray-900">Are you sure, that you want to delete
                            the {{strtolower(class_basename(get_class($model)))}} absolutely?</p>
                    </div>
                    <hr>
                    <div class="flex justify-between pt-4">
                        <x-btn color="ghost" type="button" x-on:click="isModalOpen = false" class="mr-4">Cancel</x-btn>
                        <x-btn color="red" form="deleteForm">Sure</x-btn>
                    </div>
                </form>
            </div>
        </x-modal>
    @endif
    @if(isset($editPermission) ? Auth::user()->can($editPermission) : true)
        <x-btn :link="true" color="green" class="w-full md:w-auto" href="{{route('back-office.'.$resource.'.edit', $model)}}">Edit</x-btn>
    @endif
</div>
