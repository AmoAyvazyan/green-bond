<x-modal-bulk-approve :closeButton="true" size="lg:w-6/12">
    <x-slot name="trigger">
        <x-btn color="green" type="button" class="text-base" x-on:click="isBulkApproveModalOpen = true">{{ __('phrases.bulk_update') }}</x-btn>
    </x-slot>
    <div class="modal-content">
        <div class="py-4">
            <p class="text-xl text-center text-gray-900">{{ __('phrases.bulk_update') }}</p>
        </div>
        <hr>
        <livewire:bulk-update :type="$type"/>
    </div>
</x-modal-bulk-approve>