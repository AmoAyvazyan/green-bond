<div class="flex justify-evenly items-center space-x-1">
    <x-icon-link color="blue" href="{{$showRoute}}">
        <x-heroicon-o-eye class="w-5 h-5 mt-0.5"/>
    </x-icon-link>
    @if(isset($editRoute))
        <x-icon-link color="green" href="{{$editRoute}}">
            <x-heroicon-o-pencil-square class="w-5 h-5"/>
        </x-icon-link>
    @endif
    @if(isset($permission) && $permission && Auth::user()->can($permission))
        <x-modal :closeButton="true" name="Remove {{strtolower(class_basename(get_class($model)))}}">
            <x-slot name="trigger">
                <x-icon-link color="red" x-on:click="isModalOpen = true">
                    <x-heroicon-o-trash class="w-5 h-6 mt-1.5"/>
                </x-icon-link>
            </x-slot>
            <div class="modal-content">
                <div class="py-4">
                    <p class="text-xl text-center text-gray-900">Are you sure, that you want to delete the {{strtolower(class_basename(get_class($model)))}} absolutely?</p>
                </div>
                <hr>
                <div class="flex justify-between pt-4">
                    <x-btn color="ghost" x-on:click="isModalOpen = false" class="mr-4">Cancel</x-btn>
                    <x-btn color="red" x-on:click="isModalOpen = false" wire:click="delete({{ $model->id }})"
                           type="button">Sure
                    </x-btn>
                </div>
            </div>
        </x-modal>
    @endif
</div>
