@push('styles')
    @vite('resources/sass/fonts.scss')
@endpush
<link href="{{asset('fonts/segoiui/SegoeUI-Light.woff2')}}" rel="preload" as="font" crossorigin="anonymous">
<link href="{{asset('fonts/segoiui/SegoeUI.woff2')}}" rel="preload" as="font" crossorigin="anonymous">
<link href="{{asset('fonts/segoiui/SegoeUI-Bold.woff2')}}" rel="preload" as="font" crossorigin="anonymous">
