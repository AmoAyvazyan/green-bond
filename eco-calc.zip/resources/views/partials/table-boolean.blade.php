<div class="flex space-x-1 justify-center items-center">
    @if($isChecked)
        <x-heroicon-o-check-circle class="w-5 h-5 text-green-500"/>
    @else
        <x-heroicon-o-no-symbol class="w-5 h-5 text-red-500"/>
    @endif
</div>
