<aside
    class="-left-56 lg:left-0 transition duration-200 absolute lg:relative z-10 p-4
            flex flex-col justify-between shrink-0 bg-black shadow-lg"
    x-data="{ tools: {{ request()->is('back-office/languages*', 'back-office/settings*') ? 'true' : 'false' }},
            loanRequest: {{ request()->is('back-office/mortgage-loan-requests*', 'back-office/construction-loan-requests*', 'back-office/renovation-loan-requests*', 'back-office/loan-requests*') ? 'true' : 'false' }},
             loanReports: {{ request()->is('back-office/report-loan-requests*') ? 'true' : 'false' }} }">
    <div class="flex flex-col">
        <x-nav-link :href="route('back-office.dashboard')" :active="request()->is('back-office/dashboard')">
            <x-heroicon-o-squares-2x2 class="w-4 h-4 mr-2 -mt-0.5"/> {{ __('Dashboard') }}
        </x-nav-link>
        @can('manage-users')
            <x-nav-link :href="route('back-office.users.index')" :active="request()->is('back-office/users*')">
                <x-heroicon-o-users class="w-4 h-4 mr-2 -mt-0.5"/> {{ __('Users') }}
            </x-nav-link>
        @endcan
        @can('manage-posts')
            <x-nav-link :href="route('back-office.posts.index')" :active="request()->is('back-office/posts*')">
                <x-heroicon-o-document-duplicate class="w-4 h-4 mr-2 -mt-0.5"/> {{ __('Posts') }}
            </x-nav-link>
        @endcan
        @can('manage-improvements')
            <x-nav-link :href="route('back-office.improvements.index')" :active="request()->is('back-office/improvements*')">
                <x-heroicon-o-chevron-up class="w-4 h-4 mr-2 -mt-0.5"/> {{ __('Improvements') }}
            </x-nav-link>
            <x-nav-link :href="route('back-office.eeImprovements.index')" :active="request()->is('back-office/eeImprovements*')">
                <x-heroicon-o-chevron-double-up class="w-4 h-4 mr-2 -mt-0.5"/> {{ __('EE Improvements') }}
            </x-nav-link>
        @endcan
        @can('manage-loan-requests')
            <x-nav-link :active="request()->is('back-office/mortgage-loan-requests*', 'back-office/construction-loan-requests*', 'back-office/renovation-loan-requests*', 'back-office/loan-requests*')"
                        @click="loanRequest = !loanRequest" class="justify-between">
                <div class="flex items-center justify-between">
                    <x-heroicon-m-bars-3-bottom-left class="w-4 h-4 mr-2"/>
                    {{ __('Loan Requests') }}
                </div>
                <div class="h-5 w-5 flex items-center justify-center transition-all ease-in-out duration-500"
                     :class="{ 'rotate-90': loanRequest }">
                    <x-heroicon-m-chevron-right/>
                </div>
            </x-nav-link>
            <div x-show="loanRequest" x-collapse.duration.500ms class="flex flex-col pl-2">
                <x-nav-link :href="route('back-office.mortgage-loan-requests.index')" :active="request()->is('back-office/mortgage-loan-requests*')">
                    <x-heroicon-o-key class="w-4 h-4 mr-2 -mt-0.5"/> {{ __('Mortgage Loans Request') }}
                </x-nav-link>
                <x-nav-link :href="route('back-office.construction-loan-requests.index')" :active="request()->is('back-office/construction-loan-requests*')">
                    <x-heroicon-o-home-modern class="w-4 h-4 mr-2 -mt-0.5"/> {{ __('Construction Loans Request') }}
                </x-nav-link>
                <x-nav-link :href="route('back-office.renovation-loan-requests.index')" :active="request()->is('back-office/renovation-loan-requests*')">
                    <x-heroicon-o-sparkles class="w-4 h-4 mr-2 -mt-0.5"/> {{ __('Renovation Loans Request') }}
                </x-nav-link>
            </div>
            <x-nav-link :active="request()->is('back-office/report-loan-requests*')"
                        @click="loanReports = !loanReports" class="justify-between">
                <div class="flex items-center justify-between">
                    <x-heroicon-m-bars-3-bottom-left class="w-4 h-4 mr-2"/>
                    {{ __('Loan Reports') }}
                </div>
                <div class="h-5 w-5 flex items-center justify-center transition-all ease-in-out duration-500"
                     :class="{ 'rotate-90': loanReports }">
                    <x-heroicon-m-chevron-right/>
                </div>
            </x-nav-link>
            <div x-show="loanReports" x-collapse.duration.500ms class="flex flex-col pl-2">
                <x-nav-link :href="route('back-office.report-loan-requests.eligible.month')" :active="request()->is('back-office/report-loan-requests/eligible-by/month')">
                    <x-heroicon-o-calendar-days class="w-4 h-4 mr-2 -mt-0.5"/> {{ __('Eligible By Month') }}
                </x-nav-link>
                <x-nav-link :href="route('back-office.report-loan-requests.eligible.pfi')" :active="request()->is('back-office/report-loan-requests/eligible-by/pfi')">
                    <x-heroicon-o-briefcase class="w-4 h-4 mr-2 -mt-0.5"/> {{ __('Eligible By PFI') }}
                </x-nav-link>
                <x-nav-link :href="route('back-office.report-loan-requests.eligible.region')" :active="request()->is('back-office/report-loan-requests/eligible-by/region')">
                    <x-heroicon-o-globe-europe-africa class="w-4 h-4 mr-2 -mt-0.5"/> {{ __('Eligible By Region') }}
                </x-nav-link>
                <x-nav-link :href="route('back-office.report-loan-requests.eligible.sex')" :active="request()->is('back-office/report-loan-requests/eligible-by/sex')">
                    <x-heroicon-o-user-group class="w-4 h-4 mr-2 -mt-0.5"/> {{ __('Eligible By Sex') }}
                </x-nav-link>
                <x-nav-link :href="route('back-office.report-loan-requests.investments.ee')" :active="request()->is('back-office/report-loan-requests/investments-by-ee')">
                    <x-heroicon-o-presentation-chart-line class="w-4 h-4 mr-2 -mt-0.5"/> {{ __('Investments By EE') }}
                </x-nav-link>
                <x-nav-link :href="route('back-office.report-loan-requests.revenues.region')" :active="request()->is('back-office/report-loan-requests/revenues-by-region')">
                    <x-heroicon-o-currency-euro class="w-4 h-4 mr-2 -mt-0.5"/> {{ __('Revenues By Region') }}
                </x-nav-link>
                <x-nav-link :href="route('back-office.report-loan-requests.allocation_impact')" :active="request()->is('back-office/report-loan-requests/allocation-and-impact')">
                    <x-heroicon-o-arrows-pointing-out class="w-4 h-4 mr-2 -mt-0.5"/> {{ __('Allocation and Impact') }}
                </x-nav-link>
            </div>
        @endcan
        @can('manage-settings')
            <x-nav-link :href="route('back-office.partners.index')" :active="request()->is('back-office/partners*')">
                <x-heroicon-o-briefcase class="w-4 h-4 mr-2 -mt-0.5"/> {{ __('Partners') }}
            </x-nav-link>
            <x-nav-link :href="route('back-office.materials.index')" :active="request()->is('back-office/materials*')">
                <x-heroicon-o-rectangle-group class="w-4 h-4 mr-2 -mt-0.5"/> {{ __('Materials') }}
            </x-nav-link>
            <x-nav-link :href="route('back-office.regions.index')" :active="request()->is('back-office/regions*')">
                <x-heroicon-o-map class="w-4 h-4 mr-2 -mt-0.5"/> {{ __('Regions') }}
            </x-nav-link>
            <x-nav-link :href="route('back-office.communities.index')" :active="request()->is('back-office/communities*')">
                <x-heroicon-o-map-pin class="w-4 h-4 mr-2 -mt-0.5"/> {{ __('Communities') }}
            </x-nav-link>
            <x-nav-link :href="route('back-office.residential-complexes.index')" :active="request()->is('back-office/residential-complexes*')">
                <x-heroicon-o-building-office-2 class="w-4 h-4 mr-2 -mt-0.5"/> {{ __('Residential Complexes') }}
            </x-nav-link>
            <x-nav-link :href="route('back-office.buildings.index')" :active="request()->is('back-office/buildings*')">
                <x-heroicon-o-building-office class="w-4 h-4 mr-2 -mt-0.5"/> {{ __('Buildings') }}
            </x-nav-link>
            <x-nav-link :href="route('back-office.electronic-params.index')"
                        :active="request()->is('back-office/electronic-params*')">
                <x-heroicon-o-light-bulb class="w-4 h-4 mr-2 -mt-0.5"/> {{ __('Electronic Params') }}
            </x-nav-link>
            <x-nav-link :active="request()->is('back-office/languages*', 'back-office/settings*')"
                        @click="tools = !tools" class="justify-between">
                <div class="flex items-center justify-between">
                    <x-heroicon-m-bars-3-bottom-left class="w-4 h-4 mr-2"/>
                    {{ __('Tools') }}
                </div>
                <div class="h-5 w-5 flex items-center justify-center transition-all ease-in-out duration-500"
                     :class="{ 'rotate-90': tools }">
                    <x-heroicon-m-chevron-right/>
                </div>
            </x-nav-link>
            <div x-show="tools" x-collapse.duration.500ms class="flex flex-col pl-2">
                <x-nav-link :href="url('back-office/languages')" :active="request()->is('back-office/languages*')">
                    <x-heroicon-o-language class="w-4 h-4 mr-2 -mt-0.5"/> {{ __('Translations') }}
                </x-nav-link>
                <x-nav-link :href="route('back-office.settings.index')"
                            :active="request()->is('back-office/settings*')">
                    <x-heroicon-o-cog-6-tooth class="w-4 h-4 mr-2 -mt-0.5"/> {{ __('Settings') }}
                </x-nav-link>
{{--                <x-nav-link :href="url('/back-office/artisan')">--}}
{{--                    <x-heroicon-o-command-line class="w-4 h-4 mr-2 -mt-0.5"/> {{ __('Commands') }}--}}
{{--                </x-nav-link>--}}
                <x-nav-link :href="url('/back-office/logs')">
                    <x-heroicon-o-document-text class="w-4 h-4 mr-2 -mt-0.5"/> {{ __('Logs') }}
                </x-nav-link>
                <x-nav-link :href="route('back-office.activity-log.index')"
                            :active="request()->is('back-office/activity-log*')">
                    <x-heroicon-o-identification class="w-4 h-4 mr-2 -mt-0.5"/> {{ __('Activity Logs') }}
                </x-nav-link>
            </div>
        @endcan
        <x-nav-link target="_blank" :href="route('front.homepage')" :active="false">
            <x-heroicon-o-globe-alt class="w-4 h-4 mr-2 -mt-0.5"/>
            Main Site
        </x-nav-link>
    </div>
    <div class="block lg:hidden mt-4">
        @include('partials.profile-menu',['dark'=>true,'align'=>'bottom'])
    </div>
</aside>
