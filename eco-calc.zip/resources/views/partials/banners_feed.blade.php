@foreach($banners as $banner)
    @php /** @var $banner \App\Models\Banner */ @endphp
    @continue($banner->started_at && $banner->started_at->isFuture())
    @continue($banner->expired_at && $banner->expired_at->isPast())
    @if($banner->url && !$banner->btn_text)
        <a href="{{LaravelLocalization::localizeURL($banner->url)}}"
           class="w-full sm:w-[48%] lg:w-full min-h-[300px] lg:min-h-[250px] xl:min-h-[285px] fhd:min-h-[344px] p-4 lg:p-6
                  bg-center bg-cover bg-no-repeat rounded-3xl lazyload mb-6
                  flex flex-col justify-end items-start cursor-pointer"
           data-bg="{{$banner->image}}" data-mobile-bg="{{$banner->mobile_image}}">
            <p class="w-4/5 text-white text-3xl font-extrabold mb-2 drop-shadow-[0_1.2px_1.2px_rgba(0,0,0,0.8)]">{{$banner->heading}}</p>
            <div class="text-base w-4/5 text-white rich-content drop-shadow-[0_1.2px_1.2px_rgba(0,0,0,0.8)]">{!! $banner->description !!}</div>
        </a>
    @else
        <div class="w-full sm:w-[48%] lg:w-full min-h-[300px] lg:min-h-[250px] xl:min-h-[285px] fhd:min-h-[344px] p-4 lg:p-6
                    bg-center bg-cover bg-no-repeat rounded-3xl lazyload mb-6
                    flex flex-col justify-end items-start"
             data-bg="{{$banner->image}}" data-mobile-bg="{{$banner->mobile_image}}">
            <p class="w-4/5 text-white text-3xl font-extrabold mb-2 drop-shadow-[0_1.2px_1.2px_rgba(0,0,0,0.8)]">{{$banner->heading}}</p>
            <div class="text-base w-4/5 text-white drop-shadow-[0_1.2px_1.2px_rgba(0,0,0,0.8)]">{!! $banner->description !!}</div>
            @if($banner->btn_text && $banner->url)
                <x-btn color="green" :link="true"
                       href="{{LaravelLocalization::localizeURL($banner->url)}}"
                       class="mb-2.5 lg:font-bold lg:text-sm mt-4">{{$banner->btn_text}}</x-btn>
            @endif
        </div>
    @endif
@endforeach