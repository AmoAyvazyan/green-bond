<header class="h-16 lg:h-36 py-5 lg:py-11 flex items-center transition duration-500 ease-in z-30 absolute w-full top-0 {{request()->is('login') ? 'bg-black' : ''}}"
        :class="{
              'bg-black !fixed shadow-md' : showBar
         }"
        @scroll.window="showBar = (window.pageYOffset >= 25) ? true : false"
>
    <!-- Primary Navigation Menu -->
    <x-container class="flex items-center justify-between">
        <nav class="grid grid-cols-3 w-full z-20">
            <div></div>
            <div class="w-full h-full flex justify-center items-center">
                <!-- Logo -->
                <a href="{{ route('front.homepage') }}" aria-label="{{__('metas.general')}}">
                    <x-application-logo class="h-8 w-auto lg:h-full text-white"/>
                </a>
            </div>
            <div class="hidden lg:flex items-center">
                <div class="ml-auto flex items-center justify-between space-x-4">
                    @unless(request()->is('back-office/login'))
                        <div class="lang-switcher lg:flex items-center border p-1 rounded-[48px]"
                             x-data="{locale:{hy:false}}"
                             x-init="locale['{{app()->getLocale()}}'] = true"
                        >
                            @foreach(config('laravellocalization.supportedLocales') as $code => $locale)
                                <a class="capitalize text-white text-lg font-mono hover:bg-white transition duration-150 rounded-[36px] px-4 py-1 md:py-2 hover:text-black
                            {{$code === app()->getLocale() ? 'active' : ''}}"
                                   hreflang="{{$code}}"
                                   href="{{LaravelLocalization::getLocalizedURL($code)}}"
                                >{{$locale['shortname']}}</a>
                            @endforeach
                        </div>
                    @endunless
                </div>
            </div>
            <!-- Hamburger -->
            <div class="flex justify-end lg:hidden">
                @include('partials.mobile-menu')
            </div>
        </nav>
    </x-container>
</header>
