<x-guest-layout>
    @section('title', 'Back-Office')
    <div class="bg-black min-h-screen">
        <x-auth-card :with-pic="false">
            <x-slot name="picture">
                <x-heroicon-o-identification class="text-green-500 w-[150px] h-[150px]"/>
            </x-slot>
            <x-slot name="heading">Back-Office</x-slot>

            <!-- Session Status -->
            <x-auth-session-status class="mb-4" :status="session('status')"/>

            <!-- Validation Errors -->
            <x-validation-errors class="mb-4" :errors="$errors"/>

            <form method="POST" class="px-6 sm:px-12.5" action="{{ route('back-office.login') }}">
                @csrf
                <x-label for="email" class="mb-1">{{__('phrases.email')}}</x-label>
                <x-input class="w-full mb-6" name="email" type="email"
                         placeholder="{{__('phrases.email')}}"></x-input>
                <x-label for="password" class="mb-1">{{__('phrases.password')}}</x-label>
                <x-input class="w-full mb-6" name="password" type="password"
                         placeholder="{{__('phrases.password')}}"></x-input>
                <div class="w-full flex justify-between items-center mb-8">
                    <x-checkbox id="remember" value="1" class="text-sm"
                                name="remember">{{__('phrases.remember')}}</x-checkbox>
                </div>
                <x-btn color="green" class="mb-8 w-full">{{__('buttons.login')}}</x-btn>
            </form>
        </x-auth-card>
    </div>
</x-guest-layout>
