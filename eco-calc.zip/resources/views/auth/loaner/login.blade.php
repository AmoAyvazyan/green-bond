<x-guest-layout>
    @section('title', __('phrases.login_title'))
    <x-auth-card :with-pic="false">
        <x-slot name="heading">{!! __('phrases.login_heading') !!}</x-slot>

        <!-- Session Status -->
        <x-auth-session-status class="mb-4 text-green-500" :status="session('status')"/>

        <!-- Validation Errors -->
        <x-validation-errors class="mb-4" :errors="$errors"/>

        <form method="POST" class="px-6 sm:px-12.5" action="{{ route('loaner.login') }}">
            @csrf
            <x-input class="w-full mb-2.5" name="email" type="email"
                     placeholder="{{__('phrases.email')}}"></x-input>
            <x-btn color="green" class="mb-4 w-full">{{__('buttons.login')}}</x-btn>
        </form>
    </x-auth-card>
</x-guest-layout>