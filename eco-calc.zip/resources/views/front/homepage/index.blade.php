@section('title', __('phrases.homepage_title') . ' | ' . __('metas.general'))
<x-guest-layout>
    <div>
        <div class="lazyload w-full h-[1300px] md:h-[1082px] fhd:h-[1200px] bg-cover relative"
             data-bg="{{asset('images/bg-image.jpg')}}">
            <x-container class="absolute left-0 right-0 text-light">
                <div class="w-full mt-36 md:mt-44 mb-44 md:mb-24">
                    <div class="">
                        <h1 class="text-2xl break-words md:break-keep md:text-4xl text-center text-white font-bold mb-4">{{__('phrases.homepage_title')}}</h1>
                        <p class="text-center text-sm md:text-base lg:text-2xl mb-20">{{__('phrases.homepage_subtitle')}}</p>
                    </div>
                    <div class="grid grid-cols-1 md:grid-cols-3 gap-5">
                        <a class="min-h-[260px] md:min-h-[366px] group flex flex-col justify-between
                                    hover:bg-green-500 p-6 rounded-[40px] border border-white cursor-pointer"
                           href="{{route('front.calculators.mortgage')}}">
                            <div class="flex flex-col justify-between space-y-4 h-full">
                                <div class="flex justify-start">
                                    <div
                                        class="flex items-center justify-center p-2 rounded-full size-16 lg:size-32 bg-gray-400/25 group-hover:bg-transparent">
                                        <x-icons.key class="w-12 lg:w-[100px] h-auto text-white"/>
                                    </div>
                                </div>
                                <x-title
                                    class="text-light !mb-12">{{__('phrases.property_acquisition_title')}}</x-title>
                            </div>
                            <x-btn color="dark" size="lg"
                                   class="self-end mt-4 hidden group-hover:inline-flex">{{__('buttons.start_evaluation')}}</x-btn>
                        </a>
                        <a class="min-h-[260px] md:min-h-[366px] group flex flex-col justify-between
                                 hover:bg-green-500 p-6 rounded-[40px] border border-white"
                           href="{{route('front.calculators.renovation')}}">
                            <div class="flex flex-col justify-between space-y-4 h-full">
                                <div class="flex justify-start">
                                    <div
                                        class="flex items-center justify-center p-2 rounded-full size-16 lg:size-32 bg-gray-400/25 group-hover:bg-transparent">
                                        <x-icons.renovation class="w-9 lg:w-[75px] h-auto text-white"/>
                                    </div>
                                </div>
                                <x-title class="text-light !mb-12">{{__('phrases.repair_title')}}</x-title>
                            </div>
                            <x-btn color="dark" size="lg"
                                   class="self-end mt-4 hidden group-hover:inline-flex">{{__('buttons.start_evaluation')}}</x-btn>
                        </a>
                        <a class="min-h-[260px] md:min-h-[366px] group flex flex-col justify-between
                                  hover:bg-green-500 p-6 rounded-[40px] border border-white"
                           href="{{route('front.calculators.construction')}}">
                            <div class="flex flex-col justify-between space-y-4 h-full">
                                <div class="flex justify-start">
                                    <div
                                        class="flex items-center justify-center p-2 rounded-full size-16 lg:size-32 bg-gray-400/25 group-hover:bg-transparent">
                                        <x-icons.construct class="w-9 lg:w-[75px] h-auto text-white"/>
                                    </div>
                                </div>
                                <x-title
                                    class="text-light !mb-12">{{__('phrases.construction_residential_house_title')}}</x-title>
                            </div>
                            <x-btn color="dark" size="lg"
                                   class="self-end mt-4 hidden group-hover:inline-flex">{{__('buttons.start_evaluation')}}</x-btn>
                        </a>
                    </div>
                </div>
            </x-container>
        </div>
        <div class="md:bg-gray-50 w-full md:pt-40 relative z-1">
            <x-container>
                <div class="grid grid-cols-1 md:grid-cols-2 gap-4 border border-transparent md:border-gray-50 bg-white
                 p-2 md:p-5 rounded-xl md:rounded-4xl lg:-mt-[470px] mb-10 md:mb-16">
                    <div>
                        <x-title
                            class="text-black text-2xl md:text-4xl !mt-0">{{$post->title}}</x-title>
                        <p class="text-black text-lg break-words md:break-keep">{!! $post->content !!}</p>
                    </div>
                    <img class="lazyload w-full" data-src="{{$post->image}}" alt="{{$post->title}}">
                </div>
                <x-title class="text-black md:text-4xl text-center mb-11">{{__('phrases.development_goals_title')}}</x-title>
                <div class="grid grid-cols-1 sm:grid-cols-3 gap-6 lg:w-3/4 mx-auto">
                    @for ($i = 1; $i < 4; $i++)
                        <div class="relative text-white xs:text-2xl sm:text-base md:text-2xl font-bold uppercase">
                            <img data-src="{{ asset('images/card_'. $i .'.svg') }}" class="w-full h-auto lazyload"
                                 alt="{{ __('phrases.development_goals_subtitle_'. $i) }}">
                            <div class="absolute top-0 left-0 w-full h-full p-5 lg:p-10">
                                <p>{!! __('phrases.development_goals_subtitle_'. $i) !!}</p>
                            </div>
                        </div>
                    @endfor
                </div>
                <x-title
                    class="text-black text-2xl md:text-4xl text-center">{{__('phrases.additional_information')}}</x-title>
                <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div
                        class="flex flex-col md:flex-row justify-between bg-white items-center rounded-[40px] p-5 space-y-2">
                        <div class="w-full flex items-center justify-start space-x-4">
                            <img class="lazyload w-10" data-src="{{asset('images/icons/file_icon.svg')}}"
                                 alt="{{__('phrases.green_standards')}}">
                            <p class="text-black text-sm md:text-base font-bold">{{__('phrases.green_standards')}}</p>
                        </div>
                        <x-btn color="green" size="lg" class="!justify-between space-x-6" link="true" target="_blank" href="{{asset(app()->getLocale() === 'en' ? 'files/pdf/NMC Green Standards_ENG.pdf' : 'files/pdf/NMC Green Standards_ARM.pdf')}}">
                            <span>{{__('buttons.download')}}</span>
                            <x-icons.download class="text-white size-6"/>
                        </x-btn>
                    </div>
                    <div
                        class="flex flex-col md:flex-row justify-between bg-white items-center rounded-[40px] p-5 space-y-2">
                        <div class="w-full flex items-center justify-between md:justify-start space-x-4">
                            <img class="lazyload w-10" data-src="{{asset('images/icons/video_icon.svg')}}"
                                 alt="{{__('phrases.assessment_tool_completion')}}">
                            <p class="text-black text-sm md:text-base font-bold">{{__('phrases.assessment_tool_completion')}}</p>
                        </div>
                        <x-btn color="green" size="lg" class="!justify-between space-x-6"
                               x-on:click="isVideoModalOpen = true">
                            <span>{{__('buttons.watch')}}</span>
                            <x-icons.play class="text-white size-6"/>
                        </x-btn>
                    </div>
                </div>
                <x-title
                    class="text-black text-2xl md:text-4xl text-center mb-24">{{__('phrases.partner_financial_institutions')}}</x-title>
                <x-partners-slider/>
            </x-container>
        </div>
    </div>
</x-guest-layout>


{{--<div class="lazyload w-full h-[1300px] md:h-[1082px] fhd:h-[1200px] bg-cover relative"--}}
{{--     class="grid grid-cols-1 md:grid-cols-2 gap-4 border border-gray-50 bg-white p-5 rounded-[40px] md:-mt-[400px] lg:-mt-[470px]">--}}
