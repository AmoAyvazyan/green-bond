@section('title', __('phrases.legal_notice') . ' | ' . __('metas.general'))
@section('meta_title', __('phrases.legal_notice'))
@section('description', __('terms.general_terms'))
<x-guest-layout>
    <div class="lazyload w-full bg-cover h-[1082px]"
         data-bg="{{asset('images/bg-image.jpg')}}">
    </div>
    <x-container class="-mt-[930px]">
        <div class="border border-gray-50 bg-white p-5 md:p-10 rounded-[40px]">
            <div class="mt-6">
                <x-title
                    class="text-black text-2xl md:text-4xl !mt-0">{{__('terms.legal_notice')}}</x-title>
                <x-subtitle>{{__('terms.contents_of_this_website_heading')}}</x-subtitle>
                <p class="text-black text-lg mt-2">{!! __('terms.contents_of_this_website_content') !!}</p>
                <x-subtitle class="mt-6">{{__('terms.external_links_heading')}}</x-subtitle>
                <p class="text-black text-lg mt-2">{!! __('terms.external_links_content') !!}</p>
                <x-subtitle class="mt-6">{{__('terms.copyright_trademark_law_heading')}}</x-subtitle>
                <p class="text-black text-lg mt-2">{!! __('terms.copyright_trademark_law_content') !!}</p>
                <x-subtitle class="mt-6">{{__('terms.data_protection_heading')}}</x-subtitle>
                <p class="text-black text-lg mt-2">{!! __('terms.data_protection_content') !!} <a class="text-blue-500 underline" href="{{route('front.terms.privacy-policy')}}">{!! __('terms.privacy_policy') !!}</a></p>
            </div>
        </div>
    </x-container>
</x-guest-layout>
