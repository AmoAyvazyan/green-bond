@section('title', __('phrases.privacy_policy') . ' | ' . __('metas.general'))
@section('meta_title', __('terms.terms_and_conditions'))
@section('description', __('terms.general_terms'))
<x-guest-layout>
    <div class="lazyload w-full bg-cover h-[1082px]"
         data-bg="{{asset('images/bg-image.jpg')}}">
    </div>
    <x-container class="-mt-[930px]">
        <div class="border border-gray-50 bg-white p-5 md:p-10 rounded-[40px]">
            <x-title
                    class="text-black text-2xl md:text-4xl !mt-0">{{__('terms.terms_and_conditions_title')}}</x-title>
            <p class="text-black text-lg">{!! __('terms.terms_and_conditions_content') !!}</p>
            <div class="mt-6">
                <x-subtitle>{{__('terms.terms_and_conditions_subtitle_1')}}</x-subtitle>
                <p class="text-black text-lg mt-4">{!! __('terms.terms_and_conditions_content_1') !!}</p>
            </div>
            <div class="mt-6">
                <x-subtitle>{{__('terms.data_entered_title')}}</x-subtitle>
                <p class="text-black text-lg mt-4">{!! __('terms.data_entered_content_1') !!}</p>
                <ol>
                    @php
                        $data_entered_list_1 = __('terms.data_entered_list_1');
                    @endphp
                    @foreach($data_entered_list_1 as $point)
                        <li class="text-black text-lg ml-10 list-decimal">{{ $point }}</li>
                    @endforeach
                </ol>
                <p class="text-black text-lg mt-2">{!! __('terms.data_entered_content_2') !!}</p>
                <ul>
                    @php
                        $data_entered_list_1 = __('terms.data_entered_list_2');
                    @endphp
                    @foreach($data_entered_list_1 as $point)
                        <li class="text-black text-lg ml-10 list-disc">{{ $point }}</li>
                    @endforeach
                </ul>
                <p class="text-black text-lg mt-2">{!! __('terms.data_entered_content_3') !!}</p>
            </div>
            <div class="mt-6">
                <x-title
                        class="text-black text-2xl md:text-4xl !mt-0">{{__('terms.general_information')}}</x-title>
                <x-subtitle>{{__('terms.personal_data_title')}}</x-subtitle>
                <p class="text-black text-lg mt-2">{!! __('terms.personal_data_content') !!}</p>
                <x-subtitle class="mt-6">{{__('terms.legal_basis_title')}}</x-subtitle>
                <p class="text-black text-lg mt-2">{!! __('terms.legal_basis_content') !!}</p>
            </div>
            <div class="mt-6">
                <x-title
                        class="text-black text-2xl md:text-4xl !mt-0">{{__('terms.website_and_creation_of_log_files')}}</x-title>
                <x-subtitle>{{__('terms.details_and_extent_of_data_processing_heading')}}</x-subtitle>
                <p class="text-black text-lg mt-2">{!! __('terms.details_and_extent_of_data_processing_content_1') !!}</p>
                <ol>
                    @php
                        $details_and_extent_of_data_processing_list = __('terms.details_and_extent_of_data_processing_list');
                    @endphp
                    @foreach($details_and_extent_of_data_processing_list as $point)
                        <li class="text-black text-lg ml-10 list-decimal">{{ $point }}</li>
                    @endforeach
                </ol>
                <p class="text-black text-lg mt-2">{!! __('terms.details_and_extent_of_data_processing_content_2') !!}</p>
                <x-subtitle class="mt-6">{{__('terms.purpose_of_data_processing_heading')}}</x-subtitle>
                <p class="text-black text-lg mt-2">{!! __('terms.purpose_of_data_processing_content') !!}</p>
                <x-subtitle class="mt-6">{{__('terms.purpose_of_data_processing_heading')}}</x-subtitle>
                <p class="text-black text-lg mt-2">{!! __('terms.purpose_of_data_processing_content') !!}</p>
                <x-subtitle class="mt-6">{{__('terms.data_storage_period_heading')}}</x-subtitle>
                <p class="text-black text-lg mt-2">{!! __('terms.data_storage_period_content') !!}</p>
                <x-subtitle class="mt-6">{{__('terms.right_for_avoidance_heading')}}</x-subtitle>
                <p class="text-black text-lg mt-2">{!! __('terms.right_for_avoidance_content') !!}</p>
            </div>
            <div class="mt-6">
                <x-title
                    class="text-black text-2xl md:text-4xl !mt-0">{{__('terms.use_of_cookies_heading')}}</x-title>
                <p class="text-black text-lg mt-2">{!! __('terms.use_of_cookies_content') !!}</p>
                <x-subtitle class="mt-6">{{__('terms.encryption_heading')}}</x-subtitle>
                <p class="text-black text-lg mt-2">{!! __('terms.encryption_content') !!}</p>
                <x-subtitle class="mt-6">{{__('terms.contact_email_details_heading_1')}}</x-subtitle>
                <x-subtitle class="mt-6">{{__('terms.contact_email_details_heading_2')}}</x-subtitle>
                <p class="text-black text-lg mt-2">{!! __('terms.contact_email_details_content') !!}</p>
                <x-subtitle class="mt-6">{{__('terms.legal_basis_title')}}</x-subtitle>
                <p class="text-black text-lg mt-2">{!! __('terms.cookie_legal_basis_content') !!}</p>
                <x-subtitle class="mt-6">{{__('terms.purpose_of_data_processing_heading')}}</x-subtitle>
                <p class="text-black text-lg mt-2">{!! __('terms.cookie_purpose_of_data_processing_content') !!}</p>
                <x-subtitle class="mt-6">{{__('terms.data_storage_period_heading')}}</x-subtitle>
                <p class="text-black text-lg mt-2">{!! __('terms.cookie_data_storage_period_content') !!}</p>
                <x-subtitle class="mt-6">{{__('terms.right_for_avoidance_heading')}}</x-subtitle>
                <p class="text-black text-lg mt-2">{!! __('terms.cookie_right_for_avoidance_content_1') !!} <a class="text-blue-500 underline" href="mailto:info@nmc.am."> info@nmc.am</a></p>
                <p class="text-black text-lg mt-2">{!! __('terms.cookie_right_for_avoidance_content_2') !!}</p>
                <x-subtitle class="mt-6">{{__('terms.data_subject_rights_heading')}}</x-subtitle>
                <p class="text-black text-lg mt-2">{!! __('terms.data_subject_rights_content') !!}</p>
                <x-subtitle class="mt-6">{{__('terms.changes_data_policy_heading')}}</x-subtitle>
                <p class="text-black text-lg mt-2">{!! __('terms.changes_data_policy_content') !!}</p>
                <p class="text-black text-lg mt-2">{!! __('terms.latest_version') !!} 22/03/2024</p>
            </div>
        </div>
    </x-container>
</x-guest-layout>
