<x-guest-layout>
    @section('title', __('phrases.property_acquisition_title'))
    <div class="pt-16 lg:pt-36 relative bg-gray-50 lg:bg-white">
        <img class="lazyload w-full absolute h-16 lg:h-36 top-0 object-center object-cover" data-src="{{asset('images/mortgage_header_bg.webp')}}"
             alt="{{__('phrases.property_acquisition_title')}}" src="">
        <livewire:mortgage-calculator/>
    </div>
</x-guest-layout>