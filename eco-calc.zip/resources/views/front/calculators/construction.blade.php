<x-guest-layout>
    @section('title', __('phrases.construction_residential_house_title'))
    <div class="pt-16 lg:pt-36 relative bg-gray-50 lg:bg-white">
        <img class="lazyload w-full absolute h-[293px] lg:h-[270px] xl:h-[300px] fhd:h-[320px] object-center object-cover top-0" src="data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==" data-src="{{asset('images/construction_header_bg.jpg')}}"
             alt="{{__('phrases.construction_residential_house_title')}}">
        <livewire:construction-calculator/>
    </div>
</x-guest-layout>