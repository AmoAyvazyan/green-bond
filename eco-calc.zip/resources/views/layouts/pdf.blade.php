<!DOCTYPE html>
@php($currentLocale = str_replace('_', '-', app()->getLocale()))
<html lang="{{ $currentLocale }}">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    @include('partials.meta-list')
    <title>{{__('loan.request')}}</title>
    <!-- Fonts -->
    @include('partials.fonts')
    @vite(['resources/sass/app.scss', 'resources/sass/front.scss'])
</head>
<style>
    html {
        -webkit-print-color-adjust: exact;
    }
</style>
<body class="min-h-screen flex flex-col justify-between font-sans antialiased text-gray-900 bg-gray-50 overflow-x-hidden scroll-smooth">
<header class="flex justify-between items-center py-8 px-16">
    <a class="cursor-pointer" href="{{route('front.homepage')}}">
        <x-application-logo class="text-black h-10 w-auto"></x-application-logo>
    </a>
    <a href="https://nmc.am" target="_blank" class="cursor-pointer">
        <x-application-logo-nmc class="text-red-800 h-10 w-auto"></x-application-logo-nmc>
    </a>
</header>
<main class="px-1.5 lg:px-8 lg:container mx-auto">
    {{ $slot }}
</main>
<footer class="flex justify-between items-center py-8 px-16 text-black space-x-12">
    <span>{{__('loan.date')}}</span>
    <span>{{now(config('app.timezone'))->format('d.m.Y')}}</span>
</footer>
@stack('scripts')
</body>
</html>
