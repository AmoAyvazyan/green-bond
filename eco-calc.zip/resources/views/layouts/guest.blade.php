<!DOCTYPE html>
@php($currentLocale = str_replace('_', '-', app()->getLocale()))
<html lang="{{ $currentLocale }}">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="{{ csrf_token() }}">

    <title>@yield('title')</title>

    @include('partials.meta-list')

    <!-- Fonts -->
    @include('partials.fonts')

    <!-- Styles -->
    @livewireStyles
    @vite(['resources/sass/app.scss', 'resources/sass/front.scss'])
    @stack('styles')
    @vite(['resources/js/app.js', 'resources/js/front.js'])
    @env('production')
        <!-- Google Tag Manager -->
    @endenv
</head>
<body x-data="{ showBar: false, isVideoModalOpen: false }"
      class="flex flex-col min-h-screen font-sans antialiased text-white overflow-x-hidden scroll-smooth">
@env('production')
    <!-- Google Tag Manager (noscript) -->
{{--<noscript>--}}
{{--    <iframe src="https://www.googletagmanager.com/ns.html?id=GTM-WD9R64D"--}}
{{--            height="0" width="0" style="display:none;visibility:hidden"></iframe>--}}
{{--</noscript>--}}
<!-- End Google Tag Manager (noscript) -->
@endenv
@include('partials.header-front')
<main class="min-h-screen lg:pb-20 bg-white grow text-gray-500">
    {{ $slot }}
</main>
@include('front.video-modal')
@include('partials.footer-front')
@livewireScriptConfig
@stack('scripts')
</body>
</html>
