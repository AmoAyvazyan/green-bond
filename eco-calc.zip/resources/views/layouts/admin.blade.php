<!DOCTYPE html>
@php($currentLocale = str_replace('_', '-', app()->getLocale()))
<html lang="{{ $currentLocale }}">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="{{ csrf_token() }}">

    <title>Green Bond | Back-office | @yield('title')</title>
    <link rel="shortcut icon" sizes="any" href="{{asset('images/favicon/favicon.svg')}}">

    <!-- Fonts -->
    @include('partials.fonts')

    <!-- Styles -->
    @livewireStyles
    @vite(['resources/sass/app.scss', 'resources/sass/admin.scss'])
    @stack('styles')

    @vite(['resources/js/app.js', 'resources/js/admin.js'])
</head>
<body dir="ltr" class="font-sans antialiased">
<div class="min-h-screen bg-gray-50">
    @include('partials.header')
    <div class="root flex min-h-full">
        @include('partials.sidebar')
        <div class="content min-h-full relative z-1">
            <!-- Page Heading -->
            <header>
                <div class="mx-auto pt-4 px-4 lg:px-6 overflow-x-hidden">
                    <h1 class="font-semibold pt-2 border-b-2 border-green-500 text-xl text-black leading-tight @yield('button-class','pb-3') @yield('select-class')">
                        @yield('title')
                        @yield('button','')
                        @yield('select','')
                    </h1>
                </div>
            </header>

            <!-- Page Content -->
            <main class="@yield('container-class','') mx-auto py-6 pb-10 px-4 lg:px-6 overflow-x-hidden">
                <div class="max-w-10xl mx-auto mb-4">
                    {{ $slot }}
                </div>
                <footer class="text-right italic text-gray-700 text-sm absolute bottom-2 right-4 lg:right-6">
                    Green Bond | Back-office Admin Panel
                </footer>
            </main>
        </div>
    </div>
</div>
@stack('scripts')
@livewireScriptConfig
</body>
</html>
