<?php

use Mcamara\LaravelLocalization\Facades\LaravelLocalization;
use App\Http\Controllers\Auth\Loaner\AuthenticatedSessionController;
use Illuminate\Support\Facades\Route;

Route::group([
    'prefix'     => LaravelLocalization::setLocale(),
    'middleware' => ['localeSessionRedirect', 'localizationRedirect', 'guest'],
], static function () {
    Route::group(['prefix' => 'loaner', 'as' => 'loaner.'], static function () {
        Route::get('/login', [AuthenticatedSessionController::class, 'create'])
             ->name('login');
        Route::post('/login', [AuthenticatedSessionController::class, 'store']);
        Route::get('/login/{token}', [AuthenticatedSessionController::class, 'loginViaToken'])
             ->name('login.token')->middleware('signed');

    });
});

