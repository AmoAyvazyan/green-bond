<?php

use App\Http\Controllers\Admin;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Auth\User\AuthenticatedSessionController;

Route::group(['prefix' => 'back-office', 'as' => 'back-office.'], static function () {
    Route::get('/login', [AuthenticatedSessionController::class, 'create'])
         ->middleware('guest')
         ->name('login');
    Route::post('/login', [AuthenticatedSessionController::class, 'store'])
         ->middleware('guest');
    Route::post('/logout', [AuthenticatedSessionController::class, 'destroy'])
         ->middleware('auth:bo')
         ->name('logout');

    /**
     * Admins routes
     */
    Route::group(['middleware' => 'auth:bo'], static function () {
        Route::get('/dashboard', [Admin\DashboardController::class, 'index'])->name('dashboard');
        Route::resource('users', Admin\UserController::class)->middleware('can:manage-users');
        Route::resource('posts', Admin\PostController::class)->middleware('can:manage-posts');
        Route::group(['middleware' => 'can:manage-settings'], static function () {
            Route::resource('settings', Admin\SettingController::class);
            Route::resource('partners', Admin\PartnerController::class);
            Route::resource('materials', Admin\MaterialController::class);
            Route::resource('regions', Admin\RegionController::class);
            Route::resource('residential-complexes', Admin\ResidentialComplexController::class);
            Route::resource('buildings', Admin\BuildingController::class);
            Route::resource('electronic-params', Admin\ElectronicParamController::class);
            Route::resource('communities', Admin\CommunityController::class);
        });
        Route::group(['middleware' => 'can:manage-improvements'], static function () {
            Route::resource('improvements', Admin\ImprovementController::class);
            Route::resource('eeImprovements', Admin\EeImprovementController::class);
        });
        Route::group(['middleware' => 'can:view-logs'], static function () {
            Route::get('/activity-logs', [Admin\ActivityLogController::class, 'index'])->name('activity-log.index');
            Route::get('/activity-logs/{activity_log}', [Admin\ActivityLogController::class, 'show'])
                 ->name('activity-log.show');
        });
        Route::group(['middleware' => 'can:manage-loan-requests'], static function () {
            Route::resource('mortgage-loan-requests', Admin\MortgageLoanRequestController::class)
                 ->except(['create', 'store']);
            Route::resource('loan-requests', Admin\LoanRequestController::class)
                 ->except(['create', 'store', 'index']);
            Route::get('/renovation-loan-requests', [Admin\LoanRequestController::class, 'indexRenovation'])
                 ->name('renovation-loan-requests.index');
            Route::get('/construction-loan-requests', [Admin\LoanRequestController::class, 'indexConstruction'])
                 ->name('construction-loan-requests.index');
            Route::group(['prefix' => 'report-loan-requests', 'as' => 'report-loan-requests.'], static function () {
                Route::group(['prefix' => '/eligible-by', 'as' => 'eligible.'], static function () {
                    Route::get('month', [Admin\ReportController::class, 'eligibleByMonth'])
                         ->name('month');
                    Route::get('pfi', [Admin\ReportController::class, 'eligibleByPfi'])
                         ->name('pfi');
                    Route::get('region', [Admin\ReportController::class, 'eligibleByRegion'])
                         ->name('region');
                    Route::get('sex', [Admin\ReportController::class, 'eligibleBySex'])
                         ->name('sex');
                });
                Route::get('investments-by-ee', [Admin\ReportController::class, 'investmentsByEe'])
                     ->name('investments.ee');
                Route::get('revenues-by-region', [Admin\ReportController::class, 'revenuesByRegion'])
                     ->name('revenues.region');
                Route::get('allocation-and-impact', [Admin\ReportController::class, 'allocationImpact'])
                     ->name('allocation_impact');
            });
        });
    });
});
