<?php

use App\Http\Controllers\Front;
use Illuminate\Support\Facades\Route;
use Mcamara\LaravelLocalization\Facades\LaravelLocalization;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/
Route::group([
    'prefix'     => LaravelLocalization::setLocale(),
    'middleware' => ['localeSessionRedirect', 'localizationRedirect'],
    'as'         => 'front.',
], static function () {
    Livewire::setUpdateRoute(static function ($handle) {
        return Route::post('/livewire/update', $handle);
    });

    Route::get('/', [Front\MainController::class, 'index'])->name('homepage');
    Route::get('/privacy-policy', [Front\TermsController::class, 'privacy_policy'])->name('terms.privacy-policy');
    Route::get('/legal-notice', [Front\TermsController::class, 'legal_notice'])->name('terms.legal-notice');
    Route::get('/calculators/mortgage', [Front\CalculatorController::class, 'mortgage'])->name('calculators.mortgage');
    Route::get('/calculators/construction', [Front\CalculatorController::class, 'construction'])
         ->name('calculators.construction');
    Route::get('/calculators/renovation', [Front\CalculatorController::class, 'renovation'])
         ->name('calculators.renovation');
    Route::get('/view/result/mortgage/{loanRequest}', static function (\App\Models\MortgageLoanRequest $loanRequest) {
        return view('pdfs.mortgage_loan_request', [
            'request'           => $loanRequest,
            'loaner_first_name' => request()->loaner_first_name,
            'loaner_last_name'  => request()->loaner_last_name,
            'print'             => request()->boolean('print'),
        ]);
    })->name('result.calculators.mortgage');
    Route::get('/view/result/construction-renovation/{loanRequest}', static function (\App\Models\LoanRequest $loanRequest) {
        return view('pdfs.loan_request', [
            'request'           => $loanRequest,
            'loaner_first_name' => request()->loaner_first_name,
            'loaner_last_name'  => request()->loaner_last_name,
            'print'             => request()->boolean('print'),
        ]);
    })->name('result.calculators.other');
});
