<?php $__env->startSection('title', 'Construction Loan Request Details'); ?>
<?php $__env->startSection('button-class','flex justify-between items-center pb-1'); ?>
<?php $__env->startSection('button'); ?>
    <?php if (isset($component)) { $__componentOriginale24d542b14cdce1c7553e932742a57bc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale24d542b14cdce1c7553e932742a57bc = $attributes; } ?>
<?php $component = App\View\Components\Btn::resolve(['link' => true,'color' => 'green'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('btn'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Btn::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => ''.e(route('back-office.construction-loan-requests.edit', $constructionLoanRequest)).'']); ?>Edit <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale24d542b14cdce1c7553e932742a57bc)): ?>
<?php $attributes = $__attributesOriginale24d542b14cdce1c7553e932742a57bc; ?>
<?php unset($__attributesOriginale24d542b14cdce1c7553e932742a57bc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale24d542b14cdce1c7553e932742a57bc)): ?>
<?php $component = $__componentOriginale24d542b14cdce1c7553e932742a57bc; ?>
<?php unset($__componentOriginale24d542b14cdce1c7553e932742a57bc); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php if (isset($component)) { $__componentOriginal91fdd17964e43374ae18c674f95cdaa3 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal91fdd17964e43374ae18c674f95cdaa3 = $attributes; } ?>
<?php $component = App\View\Components\AdminLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('admin-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AdminLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <?php if (isset($component)) { $__componentOriginal53747ceb358d30c0105769f8471417f6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal53747ceb358d30c0105769f8471417f6 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.card','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
        <?php if (isset($component)) { $__componentOriginal14eb9ac9ab1b9936321678816133c448 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal14eb9ac9ab1b9936321678816133c448 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.detail-row','data' => ['label' => 'Community']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('detail-row'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Community']); ?>
            <?php if (isset($component)) { $__componentOriginal90eee3f94ef0e1b15e49c277c8700e9b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal90eee3f94ef0e1b15e49c277c8700e9b = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.link','data' => ['href' => ''.e(route('back-office.communities.show', $community)).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => ''.e(route('back-office.communities.show', $community)).'']); ?>
                <?php $__currentLoopData = $community->translations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $translation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php echo e($translation->name); ?>

                    <span class="text-gray-500">|</span>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal90eee3f94ef0e1b15e49c277c8700e9b)): ?>
<?php $attributes = $__attributesOriginal90eee3f94ef0e1b15e49c277c8700e9b; ?>
<?php unset($__attributesOriginal90eee3f94ef0e1b15e49c277c8700e9b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal90eee3f94ef0e1b15e49c277c8700e9b)): ?>
<?php $component = $__componentOriginal90eee3f94ef0e1b15e49c277c8700e9b; ?>
<?php unset($__componentOriginal90eee3f94ef0e1b15e49c277c8700e9b); ?>
<?php endif; ?>
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal14eb9ac9ab1b9936321678816133c448)): ?>
<?php $attributes = $__attributesOriginal14eb9ac9ab1b9936321678816133c448; ?>
<?php unset($__attributesOriginal14eb9ac9ab1b9936321678816133c448); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal14eb9ac9ab1b9936321678816133c448)): ?>
<?php $component = $__componentOriginal14eb9ac9ab1b9936321678816133c448; ?>
<?php unset($__componentOriginal14eb9ac9ab1b9936321678816133c448); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginal14eb9ac9ab1b9936321678816133c448 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal14eb9ac9ab1b9936321678816133c448 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.detail-row','data' => ['label' => 'Partner']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('detail-row'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Partner']); ?>
            <?php if (isset($component)) { $__componentOriginal90eee3f94ef0e1b15e49c277c8700e9b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal90eee3f94ef0e1b15e49c277c8700e9b = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.link','data' => ['href' => ''.e(route('back-office.partners.show', $partner)).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => ''.e(route('back-office.partners.show', $partner)).'']); ?>
                <?php $__currentLoopData = $partner->translations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $translation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php echo e($translation->name); ?>

                    <span class="text-gray-500">|</span>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal90eee3f94ef0e1b15e49c277c8700e9b)): ?>
<?php $attributes = $__attributesOriginal90eee3f94ef0e1b15e49c277c8700e9b; ?>
<?php unset($__attributesOriginal90eee3f94ef0e1b15e49c277c8700e9b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal90eee3f94ef0e1b15e49c277c8700e9b)): ?>
<?php $component = $__componentOriginal90eee3f94ef0e1b15e49c277c8700e9b; ?>
<?php unset($__componentOriginal90eee3f94ef0e1b15e49c277c8700e9b); ?>
<?php endif; ?>
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal14eb9ac9ab1b9936321678816133c448)): ?>
<?php $attributes = $__attributesOriginal14eb9ac9ab1b9936321678816133c448; ?>
<?php unset($__attributesOriginal14eb9ac9ab1b9936321678816133c448); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal14eb9ac9ab1b9936321678816133c448)): ?>
<?php $component = $__componentOriginal14eb9ac9ab1b9936321678816133c448; ?>
<?php unset($__componentOriginal14eb9ac9ab1b9936321678816133c448); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginal14eb9ac9ab1b9936321678816133c448 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal14eb9ac9ab1b9936321678816133c448 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.detail-row','data' => ['label' => 'Region']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('detail-row'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Region']); ?>
            <?php if (isset($component)) { $__componentOriginal90eee3f94ef0e1b15e49c277c8700e9b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal90eee3f94ef0e1b15e49c277c8700e9b = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.link','data' => ['href' => ''.e(route('back-office.regions.show', $region)).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => ''.e(route('back-office.regions.show', $region)).'']); ?>
                <?php $__currentLoopData = $region->translations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $translation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php echo e($translation->name); ?>

                    <span class="text-gray-500">|</span>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal90eee3f94ef0e1b15e49c277c8700e9b)): ?>
<?php $attributes = $__attributesOriginal90eee3f94ef0e1b15e49c277c8700e9b; ?>
<?php unset($__attributesOriginal90eee3f94ef0e1b15e49c277c8700e9b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal90eee3f94ef0e1b15e49c277c8700e9b)): ?>
<?php $component = $__componentOriginal90eee3f94ef0e1b15e49c277c8700e9b; ?>
<?php unset($__componentOriginal90eee3f94ef0e1b15e49c277c8700e9b); ?>
<?php endif; ?>
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal14eb9ac9ab1b9936321678816133c448)): ?>
<?php $attributes = $__attributesOriginal14eb9ac9ab1b9936321678816133c448; ?>
<?php unset($__attributesOriginal14eb9ac9ab1b9936321678816133c448); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal14eb9ac9ab1b9936321678816133c448)): ?>
<?php $component = $__componentOriginal14eb9ac9ab1b9936321678816133c448; ?>
<?php unset($__componentOriginal14eb9ac9ab1b9936321678816133c448); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginal14eb9ac9ab1b9936321678816133c448 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal14eb9ac9ab1b9936321678816133c448 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.detail-row','data' => ['label' => 'CO2 Reduction']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('detail-row'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'CO2 Reduction']); ?> <?php echo e($constructionLoanRequest->co2_reduction); ?>  <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal14eb9ac9ab1b9936321678816133c448)): ?>
<?php $attributes = $__attributesOriginal14eb9ac9ab1b9936321678816133c448; ?>
<?php unset($__attributesOriginal14eb9ac9ab1b9936321678816133c448); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal14eb9ac9ab1b9936321678816133c448)): ?>
<?php $component = $__componentOriginal14eb9ac9ab1b9936321678816133c448; ?>
<?php unset($__componentOriginal14eb9ac9ab1b9936321678816133c448); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginal14eb9ac9ab1b9936321678816133c448 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal14eb9ac9ab1b9936321678816133c448 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.detail-row','data' => ['label' => 'Area']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('detail-row'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Area']); ?> <?php echo e($constructionLoanRequest->area); ?>  <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal14eb9ac9ab1b9936321678816133c448)): ?>
<?php $attributes = $__attributesOriginal14eb9ac9ab1b9936321678816133c448; ?>
<?php unset($__attributesOriginal14eb9ac9ab1b9936321678816133c448); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal14eb9ac9ab1b9936321678816133c448)): ?>
<?php $component = $__componentOriginal14eb9ac9ab1b9936321678816133c448; ?>
<?php unset($__componentOriginal14eb9ac9ab1b9936321678816133c448); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginal14eb9ac9ab1b9936321678816133c448 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal14eb9ac9ab1b9936321678816133c448 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.detail-row','data' => ['label' => 'Duration Months']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('detail-row'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Duration Months']); ?> <?php echo e($constructionLoanRequest->duration_months); ?>  <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal14eb9ac9ab1b9936321678816133c448)): ?>
<?php $attributes = $__attributesOriginal14eb9ac9ab1b9936321678816133c448; ?>
<?php unset($__attributesOriginal14eb9ac9ab1b9936321678816133c448); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal14eb9ac9ab1b9936321678816133c448)): ?>
<?php $component = $__componentOriginal14eb9ac9ab1b9936321678816133c448; ?>
<?php unset($__componentOriginal14eb9ac9ab1b9936321678816133c448); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginal14eb9ac9ab1b9936321678816133c448 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal14eb9ac9ab1b9936321678816133c448 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.detail-row','data' => ['label' => 'Address']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('detail-row'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Address']); ?> <?php echo e($constructionLoanRequest->address); ?>  <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal14eb9ac9ab1b9936321678816133c448)): ?>
<?php $attributes = $__attributesOriginal14eb9ac9ab1b9936321678816133c448; ?>
<?php unset($__attributesOriginal14eb9ac9ab1b9936321678816133c448); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal14eb9ac9ab1b9936321678816133c448)): ?>
<?php $component = $__componentOriginal14eb9ac9ab1b9936321678816133c448; ?>
<?php unset($__componentOriginal14eb9ac9ab1b9936321678816133c448); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginal14eb9ac9ab1b9936321678816133c448 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal14eb9ac9ab1b9936321678816133c448 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.detail-row','data' => ['label' => 'Energy Savings']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('detail-row'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Energy Savings']); ?> <?php echo e($constructionLoanRequest->energy_savings); ?>  <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal14eb9ac9ab1b9936321678816133c448)): ?>
<?php $attributes = $__attributesOriginal14eb9ac9ab1b9936321678816133c448; ?>
<?php unset($__attributesOriginal14eb9ac9ab1b9936321678816133c448); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal14eb9ac9ab1b9936321678816133c448)): ?>
<?php $component = $__componentOriginal14eb9ac9ab1b9936321678816133c448; ?>
<?php unset($__componentOriginal14eb9ac9ab1b9936321678816133c448); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginal14eb9ac9ab1b9936321678816133c448 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal14eb9ac9ab1b9936321678816133c448 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.detail-row','data' => ['label' => 'Monetary Savings']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('detail-row'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Monetary Savings']); ?> <?php echo e($constructionLoanRequest->monetary_savings); ?>  <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal14eb9ac9ab1b9936321678816133c448)): ?>
<?php $attributes = $__attributesOriginal14eb9ac9ab1b9936321678816133c448; ?>
<?php unset($__attributesOriginal14eb9ac9ab1b9936321678816133c448); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal14eb9ac9ab1b9936321678816133c448)): ?>
<?php $component = $__componentOriginal14eb9ac9ab1b9936321678816133c448; ?>
<?php unset($__componentOriginal14eb9ac9ab1b9936321678816133c448); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginal14eb9ac9ab1b9936321678816133c448 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal14eb9ac9ab1b9936321678816133c448 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.detail-row','data' => ['label' => 'Property Type']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('detail-row'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Property Type']); ?> <?php echo e($constructionLoanRequest->property_type); ?>  <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal14eb9ac9ab1b9936321678816133c448)): ?>
<?php $attributes = $__attributesOriginal14eb9ac9ab1b9936321678816133c448; ?>
<?php unset($__attributesOriginal14eb9ac9ab1b9936321678816133c448); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal14eb9ac9ab1b9936321678816133c448)): ?>
<?php $component = $__componentOriginal14eb9ac9ab1b9936321678816133c448; ?>
<?php unset($__componentOriginal14eb9ac9ab1b9936321678816133c448); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginal14eb9ac9ab1b9936321678816133c448 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal14eb9ac9ab1b9936321678816133c448 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.detail-row','data' => ['label' => 'Type']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('detail-row'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Type']); ?> <?php echo e($constructionLoanRequest->type); ?>  <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal14eb9ac9ab1b9936321678816133c448)): ?>
<?php $attributes = $__attributesOriginal14eb9ac9ab1b9936321678816133c448; ?>
<?php unset($__attributesOriginal14eb9ac9ab1b9936321678816133c448); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal14eb9ac9ab1b9936321678816133c448)): ?>
<?php $component = $__componentOriginal14eb9ac9ab1b9936321678816133c448; ?>
<?php unset($__componentOriginal14eb9ac9ab1b9936321678816133c448); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginal14eb9ac9ab1b9936321678816133c448 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal14eb9ac9ab1b9936321678816133c448 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.detail-row','data' => ['label' => 'Status']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('detail-row'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Status']); ?> <?php echo e($constructionLoanRequest->status); ?>  <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal14eb9ac9ab1b9936321678816133c448)): ?>
<?php $attributes = $__attributesOriginal14eb9ac9ab1b9936321678816133c448; ?>
<?php unset($__attributesOriginal14eb9ac9ab1b9936321678816133c448); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal14eb9ac9ab1b9936321678816133c448)): ?>
<?php $component = $__componentOriginal14eb9ac9ab1b9936321678816133c448; ?>
<?php unset($__componentOriginal14eb9ac9ab1b9936321678816133c448); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginal14eb9ac9ab1b9936321678816133c448 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal14eb9ac9ab1b9936321678816133c448 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.detail-row','data' => ['label' => 'File']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('detail-row'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'File']); ?>
            <?php if (isset($component)) { $__componentOriginal90eee3f94ef0e1b15e49c277c8700e9b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal90eee3f94ef0e1b15e49c277c8700e9b = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.link','data' => ['target' => '_blank','href' => ''.e($constructionLoanRequest->file).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['target' => '_blank','href' => ''.e($constructionLoanRequest->file).'']); ?> <?php echo e($constructionLoanRequest->file); ?>  <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal90eee3f94ef0e1b15e49c277c8700e9b)): ?>
<?php $attributes = $__attributesOriginal90eee3f94ef0e1b15e49c277c8700e9b; ?>
<?php unset($__attributesOriginal90eee3f94ef0e1b15e49c277c8700e9b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal90eee3f94ef0e1b15e49c277c8700e9b)): ?>
<?php $component = $__componentOriginal90eee3f94ef0e1b15e49c277c8700e9b; ?>
<?php unset($__componentOriginal90eee3f94ef0e1b15e49c277c8700e9b); ?>
<?php endif; ?>
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal14eb9ac9ab1b9936321678816133c448)): ?>
<?php $attributes = $__attributesOriginal14eb9ac9ab1b9936321678816133c448; ?>
<?php unset($__attributesOriginal14eb9ac9ab1b9936321678816133c448); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal14eb9ac9ab1b9936321678816133c448)): ?>
<?php $component = $__componentOriginal14eb9ac9ab1b9936321678816133c448; ?>
<?php unset($__componentOriginal14eb9ac9ab1b9936321678816133c448); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginal14eb9ac9ab1b9936321678816133c448 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal14eb9ac9ab1b9936321678816133c448 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.detail-row','data' => ['label' => 'Created']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('detail-row'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Created']); ?>
            <?php echo e($constructionLoanRequest->created_at->timezone(config('app.timezone'))->format('d.m.Y H:i:s')); ?>

         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal14eb9ac9ab1b9936321678816133c448)): ?>
<?php $attributes = $__attributesOriginal14eb9ac9ab1b9936321678816133c448; ?>
<?php unset($__attributesOriginal14eb9ac9ab1b9936321678816133c448); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal14eb9ac9ab1b9936321678816133c448)): ?>
<?php $component = $__componentOriginal14eb9ac9ab1b9936321678816133c448; ?>
<?php unset($__componentOriginal14eb9ac9ab1b9936321678816133c448); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginal14eb9ac9ab1b9936321678816133c448 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal14eb9ac9ab1b9936321678816133c448 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.detail-row','data' => ['label' => 'Modified','last' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('detail-row'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Modified','last' => true]); ?>
            <?php echo e($constructionLoanRequest->updated_at->timezone(config('app.timezone'))->format('d.m.Y H:i:s')); ?>

         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal14eb9ac9ab1b9936321678816133c448)): ?>
<?php $attributes = $__attributesOriginal14eb9ac9ab1b9936321678816133c448; ?>
<?php unset($__attributesOriginal14eb9ac9ab1b9936321678816133c448); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal14eb9ac9ab1b9936321678816133c448)): ?>
<?php $component = $__componentOriginal14eb9ac9ab1b9936321678816133c448; ?>
<?php unset($__componentOriginal14eb9ac9ab1b9936321678816133c448); ?>
<?php endif; ?>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal53747ceb358d30c0105769f8471417f6)): ?>
<?php $attributes = $__attributesOriginal53747ceb358d30c0105769f8471417f6; ?>
<?php unset($__attributesOriginal53747ceb358d30c0105769f8471417f6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal53747ceb358d30c0105769f8471417f6)): ?>
<?php $component = $__componentOriginal53747ceb358d30c0105769f8471417f6; ?>
<?php unset($__componentOriginal53747ceb358d30c0105769f8471417f6); ?>
<?php endif; ?>
    <?php echo $__env->make('partials.show-actions', [
        'resource' => 'construction-loan-requests',
        'permission' => 'delete-loan-requests',
        'editPermission' => 'edit-loan-requests',
        'model' => $constructionLoanRequest,
    ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal91fdd17964e43374ae18c674f95cdaa3)): ?>
<?php $attributes = $__attributesOriginal91fdd17964e43374ae18c674f95cdaa3; ?>
<?php unset($__attributesOriginal91fdd17964e43374ae18c674f95cdaa3); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal91fdd17964e43374ae18c674f95cdaa3)): ?>
<?php $component = $__componentOriginal91fdd17964e43374ae18c674f95cdaa3; ?>
<?php unset($__componentOriginal91fdd17964e43374ae18c674f95cdaa3); ?>
<?php endif; ?><?php /**PATH /home/vagrant/projects/eco-calc/resources/views/admin/construction-loans-request/show.blade.php ENDPATH**/ ?>