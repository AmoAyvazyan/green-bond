<svg class="w-4 h-4 mr-2 -mt-0.5" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" aria-hidden="true" data-slot="icon">
  <path stroke-linecap="round" stroke-linejoin="round" d="m4.5 18.75 7.5-7.5 7.5 7.5"/>
  <path stroke-linecap="round" stroke-linejoin="round" d="m4.5 12.75 7.5-7.5 7.5 7.5"/>
</svg><?php /**PATH /home/vagrant/projects/eco-calc/storage/framework/views/b597d37f2b73256dedd47c00b9686d1d.blade.php ENDPATH**/ ?>