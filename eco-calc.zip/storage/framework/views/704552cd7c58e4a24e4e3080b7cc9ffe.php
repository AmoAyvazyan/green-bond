<!DOCTYPE html>
<?php ($currentLocale = str_replace('_', '-', app()->getLocale())); ?>
<html lang="<?php echo e($currentLocale); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo $__env->yieldContent('title'); ?></title>

    <?php echo $__env->make('partials.meta-list', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <!-- Fonts -->
    <?php echo $__env->make('partials.fonts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <!-- Styles -->
    <?php echo \Livewire\Mechanisms\FrontendAssets\FrontendAssets::styles(); ?>

    <?php echo app('Illuminate\Foundation\Vite')(['resources/sass/app.scss', 'resources/sass/front.scss']); ?>
    <?php echo $__env->yieldPushContent('styles'); ?>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/js/app.js', 'resources/js/front.js']); ?>
    <?php if(app()->environment('production')): ?>
        <!-- Google Tag Manager -->
    <?php endif; ?>
</head>
<body x-data="{ showBar: false, isVideoModalOpen: false }"
      class="flex flex-col min-h-screen font-sans antialiased text-white overflow-x-hidden scroll-smooth">
<?php if(app()->environment('production')): ?>
    <!-- Google Tag Manager (noscript) -->




<!-- End Google Tag Manager (noscript) -->
<?php endif; ?>
<?php echo $__env->make('partials.header-front', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<main class="min-h-screen lg:pb-20 bg-white grow text-gray-500">
    <?php echo e($slot); ?>

</main>
<?php echo $__env->make('front.video-modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('partials.footer-front', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo \Livewire\Mechanisms\FrontendAssets\FrontendAssets::scriptConfig(); ?>

<?php echo $__env->yieldPushContent('scripts'); ?>
</body>
</html>
<?php /**PATH /home/vagrant/projects/eco-calc/resources/views/layouts/guest.blade.php ENDPATH**/ ?>