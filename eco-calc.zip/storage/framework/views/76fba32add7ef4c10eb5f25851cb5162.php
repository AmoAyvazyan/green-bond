<?php if (isset($component)) { $__componentOriginal550f1aa1aa7e64662bd0417a60bae313 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal550f1aa1aa7e64662bd0417a60bae313 = $attributes; } ?>
<?php $component = App\View\Components\PdftLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('pdft-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\PdftLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="bg-white grid mx-auto rounded-2xl text-black px-4 text-xs md:text-sm">
        <h1 class="text-lg py-4 font-bold"><?php echo e(__('loan.title_renovation')); ?> <?php echo e($request->status === \App\Models\LoanRequest::STATUS_DRAFT
            ? '('.__('loan.draft_report') . ')' : ''); ?></h1>
        <?php switch($request->type):
            case (\App\Models\LoanRequest::TYPE_GREEN): ?>
                <div class="flex lg:-mx-4 p-3 bg-green-500 font-bold text-light items-center justify-center">
                    <?php echo e(__('phrases.loan_type_ee')); ?> <?php echo e(__('loan.loan')); ?>

                </div>
            <?php break; ?>
            <?php case (\App\Models\LoanRequest::TYPE_EE): ?>
                <div class="flex lg:-mx-4 p-3 bg-green-400 font-bold text-light items-center justify-center">
                    <?php echo e(__('phrases.loan_type_ee')); ?> <?php echo e(__('loan.loan')); ?>

                </div>
            <?php break; ?>
            <?php case (\App\Models\LoanRequest::TYPE_STANDARD): ?>
                <div class="flex lg:-mx-4 p-3 bg-green-300 font-bold text-black items-center justify-center">
                    <?php echo e(__('phrases.loan_type_standard')); ?> <?php echo e(__('loan.loan')); ?>

                </div>
            <?php break; ?>
            <?php default: ?>
                <div class="flex lg:-mx-4 p-3 bg-yellow-500 font-bold text-light items-center justify-center">
                    <?php echo e(__('phrases.loan_type_non_standard')); ?> <?php echo e(__('loan.loan')); ?>

                </div>
            <?php break; ?>
        <?php endswitch; ?>
        <div class="text-xs italic text-gray-500 -mx-4 p-4">
            <?php echo e(__('loan.notice')); ?>

        </div>
        <h2 class="font-bold py-4 text-lg">
            <?php echo e(__('loan.info_title')); ?>

        </h2>
        <div class="grid grid-cols-2 gap-8 py-4 border-b border-gray-200">
            <span><?php echo e(__('loan.request_id')); ?></span>
            <span class="text-right"><?php echo e($request->code); ?></span>
        </div>
        <div class="grid grid-cols-2 gap-8 py-4 border-b border-gray-200">
            <span><?php echo e(__('loan.loaner')); ?></span>
            <span class="text-right"><?php echo e($loaner_first_name); ?> <?php echo e($loaner_last_name); ?></span>
        </div>
        <div class="grid grid-cols-2 gap-8 py-4 border-b border-gray-200">
            <span><?php echo e(__('phrases.property_type')); ?></span>
            <span class="text-right"><?php echo e(__('phrases.property_type_'.$request->property_type)); ?></span>
        </div>
        <div class="grid grid-cols-2 gap-8 py-4 border-b border-gray-200">
            <span><?php echo e(__('loan.location')); ?></span>
            <span class="text-right"><?php echo e($request->community ? $request->community->name . ', ' : ''); ?>

                <?php echo e($request->region->name); ?></span>
        </div>
        <div class="grid grid-cols-2 gap-8 py-4 border-b border-gray-200">
            <span><?php echo e(__('loan.address')); ?></span>
            <span class="text-right"><?php echo e($request->address); ?></span>
        </div>
        <div class="grid grid-cols-2 gap-8 py-4 border-b border-gray-200">
            <span><?php echo e(__('loan.area')); ?> (<?php echo e(__('phrases.sqm')); ?>)</span>
            <span class="text-right"><?php echo e($request->area); ?></span>
        </div>
        <h2 class="font-bold py-4 text-lg">
            <?php echo e(__('loan.ee_measures')); ?>

        </h2>
        <?php ( $eeImprovementsTotalAmount = 0 ); ?>
        <?php ( $householdAppliancesTotalAmount = 0 ); ?>
        <?php ( $householdAppliances = \App\Models\EeImprovement::whereSlug(\App\Models\EeImprovement::SLUG_HOUSEHOLD_APPLIANCES)->first()->children->pluck('id') ); ?>
        <table class="w-full">
            <thead class="bg-gray-50 text-left">
                <tr>
                    <th scope="col" class="px-1 md:px-6 py-3 overflow-hidden max-w-20 lg:max-w-full break-words"></th>
                    <th scope="col" class="px-1 md:px-6 py-3 overflow-hidden max-w-20 lg:max-w-full break-words"> <?php echo e(__('phrases.quantity')); ?>

                        (<?php echo e(__('phrases.pcs')); ?>)
                    </th>
                    <th scope="col" class="px-1 md:px-6 py-3 overflow-hidden max-w-20 lg:max-w-full break-words"> <?php echo e(__('phrases.area')); ?> (<?php echo e(__('phrases.sqm')); ?>

                        )
                    </th>
                    <th scope="col" class="px-1 md:px-6 py-3 overflow-hidden max-w-20 lg:max-w-full break-words"> <?php echo e(__('phrases.thickness')); ?>

                        (<?php echo e(__('phrases.cm')); ?>)
                    </th>
                    <th scope="col" class="px-1 md:px-6 py-3 overflow-hidden max-w-20 lg:max-w-full break-words"> <?php echo e(__('phrases.material')); ?> </th>
                    <th scope="col" class="px-1 md:px-6 py-3 overflow-hidden max-w-20 lg:max-w-full break-words"> <?php echo e(__('phrases.power')); ?> </th>
                    <th scope="col" class="px-1 md:px-6 py-3 overflow-hidden max-w-20 lg:max-w-full break-words"> <?php echo e(__('phrases.co2_reduction')); ?> </th>
                    <th scope="col" class="px-1 md:px-6 py-3 overflow-hidden max-w-20 lg:max-w-full break-words"> <?php echo e(__('phrases.energy_savings')); ?> </th>
                    <th scope="col" class="px-1 md:px-6 py-3 overflow-hidden max-w-20 lg:max-w-full break-words"> <?php echo e(__('phrases.price_one')); ?>

                        (<?php echo e(__('phrases.amd')); ?>)
                    </th>
                    <th scope="col" class="px-1 md:px-6 py-3 overflow-hidden max-w-20 lg:max-w-full break-words"> <?php echo e(__('phrases.total_price')); ?>

                        (<?php echo e(__('phrases.amd')); ?>)
                    </th>
                </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $request->eeImprovements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $improvement): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php ($data = json_decode($improvement->pivot->data, true)); ?>
                <?php if($householdAppliances->contains($improvement->id)): ?>
                    <?php ($householdAppliancesTotalAmount += (int) $data['quantity'] * (int) $data['price']); ?>
                <?php endif; ?>
                <tr class="bg-white border-b border-gray-200">
                    <th scope="row" class="px-2 py-4 font-medium text-left"> <?php echo e($improvement->name); ?> </th>
                    <td class="px-2 md:px-6 py-4">
                        <?php if($improvement->has_quantity): ?>
                            <?php echo e($data['quantity']); ?>

                        <?php endif; ?>
                    </td>
                    <td class="px-2 md:px-6 py-4">
                        <?php if($improvement->has_area): ?>
                            <?php echo e($data['area']); ?>

                        <?php endif; ?>
                    </td>
                    <td class="px-2 md:px-6 py-4">
                        <?php if($improvement->has_thickness): ?>
                            <?php echo e($data['thickness']); ?>

                        <?php endif; ?>
                    </td>
                    <td class="px-2 md:px-6 py-4">
                        <?php if($improvement->materials->isNotEmpty()): ?>
                            <?php echo e($improvement->materials->find($data['material'])?->name); ?>

                        <?php endif; ?>
                    </td>
                    <td class="px-2 md:px-6 py-4">
                        <?php if($improvement->has_power): ?>
                            <?php echo e($data['power']); ?>

                            (<?php echo e($improvement->slug === \App\Models\EeImprovement::SLUG_LIGHTING ? __('phrases.Wt') :__('phrases.kWt')); ?>

                            )
                        <?php endif; ?>
                    </td>
                    <td class="px-2 md:px-6 py-4">
                        <?php if($data['savings']): ?>
                            <?php echo e($data['savings']['co2']); ?>

                        <?php endif; ?>
                    </td>
                    <td class="px-2 md:px-6 py-4">
                        <?php if($data['savings']): ?>
                            <?php echo e($data['savings']['energy']); ?>

                        <?php endif; ?>
                    </td>
                    <td class="px-2 md:px-6 py-4">
                        <?php if($improvement->has_price): ?>
                            <?php echo e($data['price']); ?>

                        <?php endif; ?>
                    </td>
                    <td class="px-2 md:px-6 py-4">
                        <?php echo e((float) (($data['quantity'] ?: $data['area']) ?: 1) * (int) $data['price']); ?>

                    </td>
                </tr>
                <?php ($eeImprovementsTotalAmount += (($data['quantity'] ?: $data['area']) ?: 1) * (int) $data['price']); ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        <h2 class="font-bold py-4 text-lg">
            <?php echo e(__('loan.non_ee_measures')); ?>

        </h2>
        <?php ( $improvementsTotalAmount = 0 ); ?>
        <?php if($request->improvements->isNotEmpty()): ?>
            <table class="w-full">
                <thead class="bg-gray-50 text-left">
                    <tr>
                        <th scope="col" class="px-1 md:px-6 py-3"></th>
                        <th scope="col" class="px-1 md:px-6 py-3"> <?php echo e(__('phrases.quantity')); ?></th>
                        <th scope="col" class="px-1 md:px-6 py-3"> <?php echo e(__('phrases.price_one')); ?> (<?php echo e(__('phrases.amd')); ?>)</th>
                        <th scope="col" class="px-1 md:px-6 py-3"> <?php echo e(__('phrases.total_price')); ?> (<?php echo e(__('phrases.amd')); ?>)</th>
                        <th scope="col" class="px-1 md:px-6 py-3"> <?php echo e(__('phrases.labor_cost')); ?> (<?php echo e(__('phrases.amd')); ?>)</th>
                    </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $request->improvements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $improvement): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php ($data = json_decode($improvement->pivot->data, true)); ?>
                    <tr class="bg-white border-b border-gray-200">
                        <th scope="row" class="px-2 py-4 font-medium text-left"> <?php echo e($improvement->name); ?> </th>
                        <?php if($improvement->is_countable): ?>
                            <td class="px-2 md:px-6 py-4"> <?php echo e($data['quantity']); ?> (<?php echo e($improvement->unit); ?>)</td>
                            <td class="px-2 md:px-6 py-4"> <?php echo e($data['price']); ?> </td>
                            <td class="px-2 md:px-6 py-4"> <?php echo e((int) $data['quantity'] * (int) $data['price']); ?> </td>
                            <td class="px-2 md:px-6 py-4"></td>
                            <?php ($improvementsTotalAmount += ((int) $data['quantity'] * (int) $data['price'])); ?>
                        <?php elseif(isset($data['total'])): ?>
                            <td class="px-2 md:px-6 py-4"></td>
                            <td class="px-2 md:px-6 py-4"></td>
                            <td class="px-2 md:px-6 py-4"> <?php echo e($data['total']); ?> </td>
                            <td class="px-2 md:px-6 py-4"></td>
                            <?php ($improvementsTotalAmount += (float) str_replace(' ','',$data['total'])); ?>
                        <?php endif; ?>
                        <?php if($improvement->include_works): ?>
                            <td class="px-2 md:px-6 py-4"></td>
                            <td class="px-2 md:px-6 py-4"></td>
                            <td class="px-2 md:px-6 py-4"></td>
                            <td class="px-2 md:px-6 py-4"> <?php echo e($data['labor_cost']); ?> </td>
                            <?php ($improvementsTotalAmount += $data['labor_cost']); ?>
                        <?php endif; ?>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        <?php endif; ?>
        <h2 class="font-bold py-4 text-lg">
            <?php echo e(__('loan.custom_measures')); ?>

        </h2>
        <?php ( $customMeasuresTotalAmount = 0 ); ?>
        <?php if($request->custom_measures): ?>
            <table class="w-full">
                <tbody>
                <?php $__currentLoopData = $request->custom_measures; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class="bg-white border-b border-gray-200">
                        <th scope="row" class="px-2 py-4 font-medium text-left">
                            <?php echo e($data['name']); ?> (<?php echo e(__('phrases.amd')); ?>)
                        </th>
                        <td class="px-2 md:px-6 py-4"> <?php echo e($data['price']); ?> </td>
                    </tr>
                    <?php ($customMeasuresTotalAmount += $data['price']); ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        <?php endif; ?>
        <h2 class="font-bold py-4 text-lg">
            <?php echo e(__('loan.summary_title')); ?>

        </h2>
        <div class="grid grid-cols-3 gap-8 py-4 border-b border-gray-200">
            <span class="col-span-2"><?php echo e(__('loan.energy_label')); ?></span>
            <div class="grid grid-cols-2 gap-8">
                <span class="text-right"><?php echo e(round(($eeImprovementsTotalAmount / $request->total_amount) * 100)); ?> %</span>
                <span class="text-right"><?php echo e($eeImprovementsTotalAmount, $request->total_amount); ?> <?php echo e(__('phrases.amd')); ?></span>
            </div>
        </div>
        <div class="grid grid-cols-3 gap-8 py-4 pl-4 border-b border-gray-200">
            <span class="col-span-2 italic"><?php echo e(__('loan.household_label')); ?></span>
            <div class="grid grid-cols-2 gap-8">
                <span class="text-right"><?php echo e(round(($householdAppliancesTotalAmount / $request->total_amount) * 100)); ?> %</span>
                <span class="text-right"><?php echo e($householdAppliancesTotalAmount); ?> <?php echo e(__('phrases.amd')); ?></span>
            </div>
        </div>
        <div class="grid grid-cols-3 gap-8 py-4 border-b border-gray-200">
            <span class="col-span-2"><?php echo e(__('loan.not_energy_label')); ?></span>
            <div class="grid grid-cols-2 gap-8">
                <span class="text-right"><?php echo e(round(($improvementsTotalAmount / $request->total_amount) * 100)); ?> %</span>
                <span class="text-right"><?php echo e($improvementsTotalAmount); ?> <?php echo e(__('phrases.amd')); ?></span>
            </div>
        </div>
        <div class="grid grid-cols-3 gap-8 py-4 border-b border-gray-200">
            <span class="col-span-2"><?php echo e(__('loan.other_measures_label')); ?></span>
            <div class="grid grid-cols-2 gap-8">
                <span class="text-right">
                    <?php echo e(100 - round(($improvementsTotalAmount / $request->total_amount) * 100) -
                            round(($householdAppliancesTotalAmount / $request->total_amount) * 100) -
                            round(($eeImprovementsTotalAmount / $request->total_amount) * 100)); ?> %</span>
                <span class="text-right"><?php echo e($customMeasuresTotalAmount); ?> <?php echo e(__('phrases.amd')); ?></span>
            </div>
        </div>
        <div class="grid grid-cols-3 gap-8 py-4 items-center">
            <span class="col-span-2"> <?php echo e(__('phrases.total_calculation')); ?> </span>
            <span class="text-right"><?php echo e(number_format($request->total_amount,0,'.',' ')); ?> <?php echo e(__('phrases.amd')); ?></span>
        </div>
        <h2 class="font-bold py-4 text-lg">
            <?php echo e(__('loan.ee_title')); ?>

        </h2>
        <div class="grid grid-cols-3 gap-8 py-4 border-b border-gray-200">
            <span class="col-span-2"><?php echo e(__('loan.co2_label')); ?></span>
            <span class="text-right"><?php echo e($request->co2_reduction); ?></span>
        </div>
        <div class="grid grid-cols-3 gap-8 py-4 border-b border-gray-200">
            <span class="col-span-2"><?php echo e(__('loan.ee_label')); ?></span>
            <span class="text-right"><?php echo e($request->energy_savings); ?></span>
        </div>
        <div class="grid grid-cols-3 gap-8 py-4 border-b border-gray-200">
            <span class="col-span-2"><?php echo e(__('loan.ee_amount_label')); ?> (<?php echo e(__('phrases.amd')); ?>)</span>
            <span class="text-right"><?php echo e($request->ee_amount); ?></span>
        </div>
        <div class="grid grid-cols-3 gap-8 py-4 border-b border-gray-200">
            <span class="col-span-2"><?php echo e(__('loan.ee_monetary_label')); ?> (<?php echo e(__('phrases.amd')); ?>)</span>
            <span class="text-right"><?php echo e($request->monetary_savings); ?></span>
        </div>
    </div>
    <?php if($print ?? false): ?>
        <?php $__env->startPush('scripts'); ?>
            <script !src="">
                document.addEventListener('DOMContentLoaded', function () {
                    window.print();
                });
            </script>
        <?php $__env->stopPush(); ?>
    <?php endif; ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal550f1aa1aa7e64662bd0417a60bae313)): ?>
<?php $attributes = $__attributesOriginal550f1aa1aa7e64662bd0417a60bae313; ?>
<?php unset($__attributesOriginal550f1aa1aa7e64662bd0417a60bae313); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal550f1aa1aa7e64662bd0417a60bae313)): ?>
<?php $component = $__componentOriginal550f1aa1aa7e64662bd0417a60bae313; ?>
<?php unset($__componentOriginal550f1aa1aa7e64662bd0417a60bae313); ?>
<?php endif; ?>
<?php /**PATH /home/vagrant/projects/eco-calc/resources/views/pdfs/loan_request.blade.php ENDPATH**/ ?>