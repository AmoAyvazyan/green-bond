<div x-data class="flex flex-col">
    <input
        x-ref="input"
        type="text"
        class="m-1 text-sm leading-4 block rounded-md shadow-sm border-gray-300 focus:border-yellow-300 focus:ring focus:ring-yellow-200 focus:ring-opacity-50"
        wire:change="doTextFilter('<?php echo e($index); ?>', $event.target.value)"
        x-on:change="$refs.input.value = ''"
    />
    <div class="flex flex-wrap max-w-48 space-x-1">
        <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $this->activeTextFilters[$index] ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <button wire:click="removeTextFilter('<?php echo e($index); ?>', '<?php echo e($key); ?>')" class="m-1 pl-1 flex items-center uppercase tracking-wide bg-gray-300 text-white hover:bg-red-600 rounded-full focus:outline-none text-xs space-x-1">
            <span><?php echo e($this->getDisplayValue($index, $value)); ?></span>
            <?php if (isset($component)) { $__componentOriginal8526a6d86a5352a81593e1d5c210e406 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8526a6d86a5352a81593e1d5c210e406 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'icons::x-circle','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('icons.x-circle'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8526a6d86a5352a81593e1d5c210e406)): ?>
<?php $attributes = $__attributesOriginal8526a6d86a5352a81593e1d5c210e406; ?>
<?php unset($__attributesOriginal8526a6d86a5352a81593e1d5c210e406); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8526a6d86a5352a81593e1d5c210e406)): ?>
<?php $component = $__componentOriginal8526a6d86a5352a81593e1d5c210e406; ?>
<?php unset($__componentOriginal8526a6d86a5352a81593e1d5c210e406); ?>
<?php endif; ?>
        </button>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> <!--[if ENDBLOCK]><![endif]-->
    </div>
</div>
<?php /**PATH /home/vagrant/projects/eco-calc/resources/views/livewire/datatables/filters/string.blade.php ENDPATH**/ ?>