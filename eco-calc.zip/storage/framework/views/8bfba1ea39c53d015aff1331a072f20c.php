<!--[if BLOCK]><![endif]--><?php if($this->isConstruction): ?>
    <?php echo $__env->make('livewire.partials.construction-summary', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php else: ?>
    <?php echo $__env->make('livewire.partials.renovation-summary', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php endif; ?> <!--[if ENDBLOCK]><![endif]--><?php /**PATH /home/vagrant/projects/eco-calc/resources/views/livewire/partials/summary.blade.php ENDPATH**/ ?>