<?php $__env->startPush('styles'); ?>
    <?php echo app('Illuminate\Foundation\Vite')('resources/sass/fonts.scss'); ?>
<?php $__env->stopPush(); ?>
<link href="<?php echo e(asset('fonts/segoiui/SegoeUI-Light.woff2')); ?>" rel="preload" as="font" crossorigin="anonymous">
<link href="<?php echo e(asset('fonts/segoiui/SegoeUI.woff2')); ?>" rel="preload" as="font" crossorigin="anonymous">
<link href="<?php echo e(asset('fonts/segoiui/SegoeUI-Bold.woff2')); ?>" rel="preload" as="font" crossorigin="anonymous">
<?php /**PATH /home/vagrant/projects/eco-calc/resources/views/partials/fonts.blade.php ENDPATH**/ ?>