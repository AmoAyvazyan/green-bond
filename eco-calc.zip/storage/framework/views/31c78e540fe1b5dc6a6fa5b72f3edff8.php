<?php if (isset($component)) { $__componentOriginala766c2d312d6f7864fe218e2500d2bba = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala766c2d312d6f7864fe218e2500d2bba = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.container','data' => ['class' => 'hidden md:block mb-16']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('container'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'hidden md:block mb-16']); ?>
    <div class="flex items-center px-16 mb-4">
        <div class="rounded-full flex items-center justify-center border-2 border-green-500 min-w-[78px] h-[78px]">
            <div class="rounded-full size-[56px] bg-green-500 flex items-center justify-center">
                <span class="text-white text-3xl leading-none -mt-1">1</span>
            </div>
        </div>
        <div class="border-b-2 w-full <?php echo e($step>1 ? 'border-green-500' : 'border-white/30'); ?>

                        transition duration-150 ease-in"></div>
        <div class="rounded-full flex items-center justify-center border-2
                        transition duration-150 ease-in
                        <?php echo e($step>1 ? 'border-green-500' : 'border-transparent'); ?> min-w-[78px] h-[78px]">
            <div class="rounded-full size-[56px] <?php echo e($step>1 ? 'bg-green-500' : 'bg-white/30'); ?>

                            flex items-center justify-center">
                <span class="text-white text-3xl leading-none -mt-1">2</span>
            </div>
        </div>
        <div class="border-b-2 w-full <?php echo e($step>2.5 ? 'border-green-500' : 'border-white/30'); ?>

                        transition duration-150 ease-in"></div>
        <div class="rounded-full flex items-center justify-center border-2
                        transition duration-150 ease-in
                        <?php echo e($step>2.5 ? 'border-green-500' : 'border-transparent'); ?> min-w-[78px] h-[78px]">
            <div class="rounded-full size-[56px] <?php echo e($step>2.5 ? 'bg-green-500' : 'bg-white/30'); ?>

                            flex items-center justify-center">
                <span class="text-white text-3xl leading-none -mt-1">3</span>
            </div>
        </div>
    </div>
    <div class="flex items-center justify-between mb-2">
        <span class="text-center text-white max-w-[200px] font-bold"><?php echo e(__('phrases.common_info')); ?></span>
        <span class="text-center max-w-[300px] lg:max-w-[400px]
                        <?php echo e($step>1 ? 'text-white font-bold' : 'text-white/60'); ?>"><?php echo e(__('phrases.ee_improvements')); ?></span>
        <span class="text-center max-w-[200px]
                        <?php echo e($step>2 ? 'text-white font-bold' : 'text-white/60'); ?>"><?php echo e(__('phrases.non_ee_improvements')); ?></span>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala766c2d312d6f7864fe218e2500d2bba)): ?>
<?php $attributes = $__attributesOriginala766c2d312d6f7864fe218e2500d2bba; ?>
<?php unset($__attributesOriginala766c2d312d6f7864fe218e2500d2bba); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala766c2d312d6f7864fe218e2500d2bba)): ?>
<?php $component = $__componentOriginala766c2d312d6f7864fe218e2500d2bba; ?>
<?php unset($__componentOriginala766c2d312d6f7864fe218e2500d2bba); ?>
<?php endif; ?>
<div class="md:hidden">
    <div class="flex items-center justify-center mt-2">
        <div class="border-b-2 w-full <?php echo e($step>1 ? 'border-green-500' : 'border-transparent'); ?>

                        transition duration-150 ease-in"></div>
        <div class="rounded-full flex items-center justify-center border-2
                        transition duration-150 ease-in border-green-500 min-w-[78px] h-[78px]">
            <div class="rounded-full size-[56px] bg-green-500
                            flex items-center justify-center">
                <span class="text-white text-3xl leading-none -mt-1"><?php echo e((int) $step); ?></span>
            </div>
        </div>
        <div class="border-b-2 w-full <?php echo e($step<3 ? 'border-green-500' : 'border-transparent'); ?>

                        transition duration-150 ease-in"></div>
    </div>
    <div class="flex items-center justify-center mt-6 mb-16">
        <span class="text-center text-white max-w-[280px] font-bold">
            <?php if($step === 1): ?>
                <?php echo e(__('phrases.common_info')); ?>

            <?php elseif($step > 1): ?>
                <?php echo e(__('phrases.ee_improvements')); ?>

            <?php else: ?>
                <?php echo e(__('phrases.non_ee_improvements')); ?>

            <?php endif; ?> <!--[if ENDBLOCK]><![endif]-->
        </span>
    </div>
</div><?php /**PATH /home/vagrant/projects/eco-calc/resources/views/livewire/partials/steps-nav.blade.php ENDPATH**/ ?>