<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps([
    'closeButton' => false,
    'name' => null,
    'size' => 'hd:w-1/2',
]) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps([
    'closeButton' => false,
    'name' => null,
    'size' => 'hd:w-1/2',
]); ?>
<?php foreach (array_filter(([
    'closeButton' => false,
    'name' => null,
    'size' => 'hd:w-1/2',
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>
<?php ($variableName = "is{$name}ModalOpen"); ?>
<div class="w-full md:w-auto"
     <?php echo e($attributes->except('class')); ?>

     x-on:keydown.escape.window="<?php echo e($variableName); ?> = false"
     x-cloak
     x-init="
        $watch('<?php echo e($variableName); ?>', value => {
            if (value === true) {
                document.body.classList.add('overflow-hidden')
            } else {
                document.body.classList.remove('overflow-hidden')
            }
        });
    "
>
    <div
        x-show="<?php echo e($variableName); ?>"
        x-bind:aria-hidden="! <?php echo e($variableName); ?>"
        class="fixed inset-0 z-40 overflow-y-auto"
    >
        <div class="flex items-center justify-center min-h-screen px-4 pt-4 pb-20 text-center cursor-default sm:block sm:p-0">
            <div
                x-show="<?php echo e($variableName); ?>"
                x-transition:enter="ease-out duration-300"
                x-transition:enter-start="opacity-0"
                x-transition:enter-end="opacity-100"
                x-transition:leave="ease-in duration-200"
                x-transition:leave-start="opacity-100"
                x-transition:leave-end="opacity-0"
                aria-hidden="true"
                class="fixed inset-0 transition-opacity"
            >
                <div class="absolute inset-0 bg-gray-500 opacity-75"></div>
            </div>

            <span class="hidden sm:inline-block sm:align-middle sm:h-screen" aria-hidden="true">​</span>

            <div
                x-show="<?php echo e($variableName); ?>"
                x-transition:enter="ease-out duration-300"
                x-transition:enter-start="opacity-0 translate-y-4 sm:translate-y-0 sm:scale-95"
                x-transition:enter-end="opacity-100 translate-y-0 sm:scale-100"
                x-transition:leave="ease-in duration-200"
                x-transition:leave-start="opacity-100 translate-y-0 sm:scale-100"
                x-transition:leave-end="opacity-0 translate-y-4 sm:translate-y-0 sm:scale-95"
                role="dialog"
                aria-modal="true"
                x-on:click.away="<?php echo e($variableName); ?> = false"
                <?php echo e($attributes->only('class')->merge(['class' => 'modal-window inline-block text-left align-bottom transition-all transform mt-[90px] fhd:my-12 sm:align-middle w-11/12 md:w-7/12 '.$size])); ?>

            >
                <div x-data="{video: false,}" class="bg-white p-6 rounded-3xl shadow-md relative">
                    <?php if($closeButton): ?>
                        <div class="flex items-center justify-end mb-4">
                            <button
                                type="button"
                                x-on:click="<?php echo e($variableName); ?> = false, video = false"
                                class="flex self-center shrink-0 text-gray-900 transition-colors duration-200 hover:text-black"
                            >
                                <?php if (isset($component)) { $__componentOriginal643fe1b47aec0b76658e1a0200b34b2c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c = $attributes; } ?>
<?php $component = BladeUI\Icons\Components\Svg::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('heroicon-o-x-mark'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(BladeUI\Icons\Components\Svg::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'w-6 h-6']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c)): ?>
<?php $attributes = $__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c; ?>
<?php unset($__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal643fe1b47aec0b76658e1a0200b34b2c)): ?>
<?php $component = $__componentOriginal643fe1b47aec0b76658e1a0200b34b2c; ?>
<?php unset($__componentOriginal643fe1b47aec0b76658e1a0200b34b2c); ?>
<?php endif; ?>
                            </button>
                        </div>
                    <?php endif; ?>
                    <?php echo e($slot); ?>

                </div>
            </div>
        </div>
    </div>
</div>
<?php /**PATH /home/vagrant/projects/eco-calc/resources/views/components/modal-dynamic.blade.php ENDPATH**/ ?>