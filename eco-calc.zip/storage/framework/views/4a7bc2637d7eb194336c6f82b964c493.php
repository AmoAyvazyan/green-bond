<?php $__env->startSection('title', 'User Details'); ?>
<?php $__env->startSection('button-class','flex justify-between items-center pb-1'); ?>
<?php $__env->startSection('button'); ?>
    <?php if (isset($component)) { $__componentOriginale24d542b14cdce1c7553e932742a57bc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale24d542b14cdce1c7553e932742a57bc = $attributes; } ?>
<?php $component = App\View\Components\Btn::resolve(['link' => true,'color' => 'green'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('btn'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Btn::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => ''.e(route('back-office.users.edit', $user)).'']); ?>Edit <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale24d542b14cdce1c7553e932742a57bc)): ?>
<?php $attributes = $__attributesOriginale24d542b14cdce1c7553e932742a57bc; ?>
<?php unset($__attributesOriginale24d542b14cdce1c7553e932742a57bc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale24d542b14cdce1c7553e932742a57bc)): ?>
<?php $component = $__componentOriginale24d542b14cdce1c7553e932742a57bc; ?>
<?php unset($__componentOriginale24d542b14cdce1c7553e932742a57bc); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php if (isset($component)) { $__componentOriginal91fdd17964e43374ae18c674f95cdaa3 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal91fdd17964e43374ae18c674f95cdaa3 = $attributes; } ?>
<?php $component = App\View\Components\AdminLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('admin-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AdminLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <?php if (isset($component)) { $__componentOriginal53747ceb358d30c0105769f8471417f6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal53747ceb358d30c0105769f8471417f6 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.card','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
        <?php if (isset($component)) { $__componentOriginal14eb9ac9ab1b9936321678816133c448 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal14eb9ac9ab1b9936321678816133c448 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.detail-row','data' => ['label' => 'Avatar']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('detail-row'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Avatar']); ?>
            <a target="_blank" class="cursor-pointer" href="<?php echo e($user->avatar); ?>">
                <img src="<?php echo e($user->avatar); ?>" alt="<?php echo e($user->full_name); ?>"
                     class="rounded-full w-6 h-6 object-cover object-center">
            </a>
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal14eb9ac9ab1b9936321678816133c448)): ?>
<?php $attributes = $__attributesOriginal14eb9ac9ab1b9936321678816133c448; ?>
<?php unset($__attributesOriginal14eb9ac9ab1b9936321678816133c448); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal14eb9ac9ab1b9936321678816133c448)): ?>
<?php $component = $__componentOriginal14eb9ac9ab1b9936321678816133c448; ?>
<?php unset($__componentOriginal14eb9ac9ab1b9936321678816133c448); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginal14eb9ac9ab1b9936321678816133c448 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal14eb9ac9ab1b9936321678816133c448 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.detail-row','data' => ['label' => 'First Name']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('detail-row'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'First Name']); ?><?php echo e($user->first_name); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal14eb9ac9ab1b9936321678816133c448)): ?>
<?php $attributes = $__attributesOriginal14eb9ac9ab1b9936321678816133c448; ?>
<?php unset($__attributesOriginal14eb9ac9ab1b9936321678816133c448); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal14eb9ac9ab1b9936321678816133c448)): ?>
<?php $component = $__componentOriginal14eb9ac9ab1b9936321678816133c448; ?>
<?php unset($__componentOriginal14eb9ac9ab1b9936321678816133c448); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginal14eb9ac9ab1b9936321678816133c448 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal14eb9ac9ab1b9936321678816133c448 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.detail-row','data' => ['label' => 'Last Name']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('detail-row'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Last Name']); ?><?php echo e($user->last_name); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal14eb9ac9ab1b9936321678816133c448)): ?>
<?php $attributes = $__attributesOriginal14eb9ac9ab1b9936321678816133c448; ?>
<?php unset($__attributesOriginal14eb9ac9ab1b9936321678816133c448); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal14eb9ac9ab1b9936321678816133c448)): ?>
<?php $component = $__componentOriginal14eb9ac9ab1b9936321678816133c448; ?>
<?php unset($__componentOriginal14eb9ac9ab1b9936321678816133c448); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginal14eb9ac9ab1b9936321678816133c448 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal14eb9ac9ab1b9936321678816133c448 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.detail-row','data' => ['label' => 'Email']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('detail-row'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Email']); ?>
            <?php if (isset($component)) { $__componentOriginal90eee3f94ef0e1b15e49c277c8700e9b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal90eee3f94ef0e1b15e49c277c8700e9b = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.link','data' => ['href' => 'mailto:'.e($user->email).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => 'mailto:'.e($user->email).'']); ?><?php echo e($user->email); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal90eee3f94ef0e1b15e49c277c8700e9b)): ?>
<?php $attributes = $__attributesOriginal90eee3f94ef0e1b15e49c277c8700e9b; ?>
<?php unset($__attributesOriginal90eee3f94ef0e1b15e49c277c8700e9b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal90eee3f94ef0e1b15e49c277c8700e9b)): ?>
<?php $component = $__componentOriginal90eee3f94ef0e1b15e49c277c8700e9b; ?>
<?php unset($__componentOriginal90eee3f94ef0e1b15e49c277c8700e9b); ?>
<?php endif; ?>
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal14eb9ac9ab1b9936321678816133c448)): ?>
<?php $attributes = $__attributesOriginal14eb9ac9ab1b9936321678816133c448; ?>
<?php unset($__attributesOriginal14eb9ac9ab1b9936321678816133c448); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal14eb9ac9ab1b9936321678816133c448)): ?>
<?php $component = $__componentOriginal14eb9ac9ab1b9936321678816133c448; ?>
<?php unset($__componentOriginal14eb9ac9ab1b9936321678816133c448); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginal14eb9ac9ab1b9936321678816133c448 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal14eb9ac9ab1b9936321678816133c448 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.detail-row','data' => ['label' => 'Role']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('detail-row'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Role']); ?><?php echo e(ucfirst($user->role?->name) ?? 'N/A'); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal14eb9ac9ab1b9936321678816133c448)): ?>
<?php $attributes = $__attributesOriginal14eb9ac9ab1b9936321678816133c448; ?>
<?php unset($__attributesOriginal14eb9ac9ab1b9936321678816133c448); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal14eb9ac9ab1b9936321678816133c448)): ?>
<?php $component = $__componentOriginal14eb9ac9ab1b9936321678816133c448; ?>
<?php unset($__componentOriginal14eb9ac9ab1b9936321678816133c448); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginal14eb9ac9ab1b9936321678816133c448 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal14eb9ac9ab1b9936321678816133c448 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.detail-row','data' => ['label' => 'Registered']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('detail-row'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Registered']); ?><?php echo e($user->created_at->timezone(config('app.timezone'))->format('d.m.Y H:i:s')); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal14eb9ac9ab1b9936321678816133c448)): ?>
<?php $attributes = $__attributesOriginal14eb9ac9ab1b9936321678816133c448; ?>
<?php unset($__attributesOriginal14eb9ac9ab1b9936321678816133c448); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal14eb9ac9ab1b9936321678816133c448)): ?>
<?php $component = $__componentOriginal14eb9ac9ab1b9936321678816133c448; ?>
<?php unset($__componentOriginal14eb9ac9ab1b9936321678816133c448); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginal14eb9ac9ab1b9936321678816133c448 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal14eb9ac9ab1b9936321678816133c448 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.detail-row','data' => ['label' => 'Modified','last' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('detail-row'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Modified','last' => true]); ?><?php echo e($user->updated_at->timezone(config('app.timezone'))->format('d.m.Y H:i:s')); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal14eb9ac9ab1b9936321678816133c448)): ?>
<?php $attributes = $__attributesOriginal14eb9ac9ab1b9936321678816133c448; ?>
<?php unset($__attributesOriginal14eb9ac9ab1b9936321678816133c448); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal14eb9ac9ab1b9936321678816133c448)): ?>
<?php $component = $__componentOriginal14eb9ac9ab1b9936321678816133c448; ?>
<?php unset($__componentOriginal14eb9ac9ab1b9936321678816133c448); ?>
<?php endif; ?>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal53747ceb358d30c0105769f8471417f6)): ?>
<?php $attributes = $__attributesOriginal53747ceb358d30c0105769f8471417f6; ?>
<?php unset($__attributesOriginal53747ceb358d30c0105769f8471417f6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal53747ceb358d30c0105769f8471417f6)): ?>
<?php $component = $__componentOriginal53747ceb358d30c0105769f8471417f6; ?>
<?php unset($__componentOriginal53747ceb358d30c0105769f8471417f6); ?>
<?php endif; ?>
    <?php echo $__env->make('partials.show-actions', [
        'resource' => 'users',
        'permission' => $user->isAdmin() ? '' : 'delete-users',
        'model' => $user,
    ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal91fdd17964e43374ae18c674f95cdaa3)): ?>
<?php $attributes = $__attributesOriginal91fdd17964e43374ae18c674f95cdaa3; ?>
<?php unset($__attributesOriginal91fdd17964e43374ae18c674f95cdaa3); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal91fdd17964e43374ae18c674f95cdaa3)): ?>
<?php $component = $__componentOriginal91fdd17964e43374ae18c674f95cdaa3; ?>
<?php unset($__componentOriginal91fdd17964e43374ae18c674f95cdaa3); ?>
<?php endif; ?>
<?php /**PATH /home/vagrant/projects/eco-calc/resources/views/admin/users/show.blade.php ENDPATH**/ ?>