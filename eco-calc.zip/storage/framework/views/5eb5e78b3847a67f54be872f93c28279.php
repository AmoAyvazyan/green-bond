<?php $__env->startSection('title', 'Partner Details'); ?>
<?php $__env->startSection('button-class','flex justify-between items-center pb-1'); ?>
<?php $__env->startSection('button'); ?>
    <?php if (isset($component)) { $__componentOriginale24d542b14cdce1c7553e932742a57bc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale24d542b14cdce1c7553e932742a57bc = $attributes; } ?>
<?php $component = App\View\Components\Btn::resolve(['link' => true,'color' => 'green'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('btn'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Btn::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => ''.e(route('back-office.partners.edit', $partner)).'']); ?>Edit <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale24d542b14cdce1c7553e932742a57bc)): ?>
<?php $attributes = $__attributesOriginale24d542b14cdce1c7553e932742a57bc; ?>
<?php unset($__attributesOriginale24d542b14cdce1c7553e932742a57bc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale24d542b14cdce1c7553e932742a57bc)): ?>
<?php $component = $__componentOriginale24d542b14cdce1c7553e932742a57bc; ?>
<?php unset($__componentOriginale24d542b14cdce1c7553e932742a57bc); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php if (isset($component)) { $__componentOriginal91fdd17964e43374ae18c674f95cdaa3 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal91fdd17964e43374ae18c674f95cdaa3 = $attributes; } ?>
<?php $component = App\View\Components\AdminLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('admin-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AdminLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <?php if (isset($component)) { $__componentOriginal53747ceb358d30c0105769f8471417f6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal53747ceb358d30c0105769f8471417f6 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.card','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
        <?php if (isset($component)) { $__componentOriginal14eb9ac9ab1b9936321678816133c448 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal14eb9ac9ab1b9936321678816133c448 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.detail-row','data' => ['label' => 'Sort Order']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('detail-row'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Sort Order']); ?><?php echo e($partner->sort_order); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal14eb9ac9ab1b9936321678816133c448)): ?>
<?php $attributes = $__attributesOriginal14eb9ac9ab1b9936321678816133c448; ?>
<?php unset($__attributesOriginal14eb9ac9ab1b9936321678816133c448); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal14eb9ac9ab1b9936321678816133c448)): ?>
<?php $component = $__componentOriginal14eb9ac9ab1b9936321678816133c448; ?>
<?php unset($__componentOriginal14eb9ac9ab1b9936321678816133c448); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginal14eb9ac9ab1b9936321678816133c448 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal14eb9ac9ab1b9936321678816133c448 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.detail-row','data' => ['label' => 'Slug']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('detail-row'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Slug']); ?><?php echo e($partner->slug); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal14eb9ac9ab1b9936321678816133c448)): ?>
<?php $attributes = $__attributesOriginal14eb9ac9ab1b9936321678816133c448; ?>
<?php unset($__attributesOriginal14eb9ac9ab1b9936321678816133c448); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal14eb9ac9ab1b9936321678816133c448)): ?>
<?php $component = $__componentOriginal14eb9ac9ab1b9936321678816133c448; ?>
<?php unset($__componentOriginal14eb9ac9ab1b9936321678816133c448); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginal14eb9ac9ab1b9936321678816133c448 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal14eb9ac9ab1b9936321678816133c448 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.detail-row','data' => ['label' => 'Partner Image']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('detail-row'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Partner Image']); ?>
            <a target="_blank" class="cursor-pointer" href="<?php echo e($partner->logo); ?>">
                <img src="<?php echo e($partner->logo); ?>" alt="" height="128" width="128"
                     class="h-50 w-auto">
            </a>
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal14eb9ac9ab1b9936321678816133c448)): ?>
<?php $attributes = $__attributesOriginal14eb9ac9ab1b9936321678816133c448; ?>
<?php unset($__attributesOriginal14eb9ac9ab1b9936321678816133c448); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal14eb9ac9ab1b9936321678816133c448)): ?>
<?php $component = $__componentOriginal14eb9ac9ab1b9936321678816133c448; ?>
<?php unset($__componentOriginal14eb9ac9ab1b9936321678816133c448); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginal14eb9ac9ab1b9936321678816133c448 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal14eb9ac9ab1b9936321678816133c448 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.detail-row','data' => ['label' => 'Name']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('detail-row'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Name']); ?>
            <?php $__currentLoopData = $partner->translations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $translation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php echo e($translation->name); ?>

                <span class="text-gray-500">|</span>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal14eb9ac9ab1b9936321678816133c448)): ?>
<?php $attributes = $__attributesOriginal14eb9ac9ab1b9936321678816133c448; ?>
<?php unset($__attributesOriginal14eb9ac9ab1b9936321678816133c448); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal14eb9ac9ab1b9936321678816133c448)): ?>
<?php $component = $__componentOriginal14eb9ac9ab1b9936321678816133c448; ?>
<?php unset($__componentOriginal14eb9ac9ab1b9936321678816133c448); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginal14eb9ac9ab1b9936321678816133c448 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal14eb9ac9ab1b9936321678816133c448 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.detail-row','data' => ['label' => 'Description']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('detail-row'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Description']); ?>
            <?php $__currentLoopData = $partner->translations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $translation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php echo $translation->description; ?>

                <span class="text-gray-500">|</span>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal14eb9ac9ab1b9936321678816133c448)): ?>
<?php $attributes = $__attributesOriginal14eb9ac9ab1b9936321678816133c448; ?>
<?php unset($__attributesOriginal14eb9ac9ab1b9936321678816133c448); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal14eb9ac9ab1b9936321678816133c448)): ?>
<?php $component = $__componentOriginal14eb9ac9ab1b9936321678816133c448; ?>
<?php unset($__componentOriginal14eb9ac9ab1b9936321678816133c448); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginal14eb9ac9ab1b9936321678816133c448 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal14eb9ac9ab1b9936321678816133c448 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.detail-row','data' => ['label' => 'Contact Email']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('detail-row'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Contact Email']); ?>
            <?php if (isset($component)) { $__componentOriginal90eee3f94ef0e1b15e49c277c8700e9b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal90eee3f94ef0e1b15e49c277c8700e9b = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.link','data' => ['href' => 'mailto:'.e($partner->contact_email).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => 'mailto:'.e($partner->contact_email).'']); ?><?php echo e($partner->contact_email); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal90eee3f94ef0e1b15e49c277c8700e9b)): ?>
<?php $attributes = $__attributesOriginal90eee3f94ef0e1b15e49c277c8700e9b; ?>
<?php unset($__attributesOriginal90eee3f94ef0e1b15e49c277c8700e9b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal90eee3f94ef0e1b15e49c277c8700e9b)): ?>
<?php $component = $__componentOriginal90eee3f94ef0e1b15e49c277c8700e9b; ?>
<?php unset($__componentOriginal90eee3f94ef0e1b15e49c277c8700e9b); ?>
<?php endif; ?>
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal14eb9ac9ab1b9936321678816133c448)): ?>
<?php $attributes = $__attributesOriginal14eb9ac9ab1b9936321678816133c448; ?>
<?php unset($__attributesOriginal14eb9ac9ab1b9936321678816133c448); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal14eb9ac9ab1b9936321678816133c448)): ?>
<?php $component = $__componentOriginal14eb9ac9ab1b9936321678816133c448; ?>
<?php unset($__componentOriginal14eb9ac9ab1b9936321678816133c448); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginal14eb9ac9ab1b9936321678816133c448 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal14eb9ac9ab1b9936321678816133c448 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.detail-row','data' => ['label' => 'Contact Phone']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('detail-row'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Contact Phone']); ?>
            <?php if (isset($component)) { $__componentOriginal90eee3f94ef0e1b15e49c277c8700e9b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal90eee3f94ef0e1b15e49c277c8700e9b = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.link','data' => ['href' => 'tel:'.e($partner->contact_phone).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => 'tel:'.e($partner->contact_phone).'']); ?><?php echo e($partner->contact_phone); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal90eee3f94ef0e1b15e49c277c8700e9b)): ?>
<?php $attributes = $__attributesOriginal90eee3f94ef0e1b15e49c277c8700e9b; ?>
<?php unset($__attributesOriginal90eee3f94ef0e1b15e49c277c8700e9b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal90eee3f94ef0e1b15e49c277c8700e9b)): ?>
<?php $component = $__componentOriginal90eee3f94ef0e1b15e49c277c8700e9b; ?>
<?php unset($__componentOriginal90eee3f94ef0e1b15e49c277c8700e9b); ?>
<?php endif; ?>
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal14eb9ac9ab1b9936321678816133c448)): ?>
<?php $attributes = $__attributesOriginal14eb9ac9ab1b9936321678816133c448; ?>
<?php unset($__attributesOriginal14eb9ac9ab1b9936321678816133c448); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal14eb9ac9ab1b9936321678816133c448)): ?>
<?php $component = $__componentOriginal14eb9ac9ab1b9936321678816133c448; ?>
<?php unset($__componentOriginal14eb9ac9ab1b9936321678816133c448); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginal14eb9ac9ab1b9936321678816133c448 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal14eb9ac9ab1b9936321678816133c448 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.detail-row','data' => ['label' => 'Url']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('detail-row'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Url']); ?>
            <?php if (isset($component)) { $__componentOriginal90eee3f94ef0e1b15e49c277c8700e9b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal90eee3f94ef0e1b15e49c277c8700e9b = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.link','data' => ['href' => ''.e($partner->url).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => ''.e($partner->url).'']); ?><?php echo e($partner->url); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal90eee3f94ef0e1b15e49c277c8700e9b)): ?>
<?php $attributes = $__attributesOriginal90eee3f94ef0e1b15e49c277c8700e9b; ?>
<?php unset($__attributesOriginal90eee3f94ef0e1b15e49c277c8700e9b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal90eee3f94ef0e1b15e49c277c8700e9b)): ?>
<?php $component = $__componentOriginal90eee3f94ef0e1b15e49c277c8700e9b; ?>
<?php unset($__componentOriginal90eee3f94ef0e1b15e49c277c8700e9b); ?>
<?php endif; ?>
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal14eb9ac9ab1b9936321678816133c448)): ?>
<?php $attributes = $__attributesOriginal14eb9ac9ab1b9936321678816133c448; ?>
<?php unset($__attributesOriginal14eb9ac9ab1b9936321678816133c448); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal14eb9ac9ab1b9936321678816133c448)): ?>
<?php $component = $__componentOriginal14eb9ac9ab1b9936321678816133c448; ?>
<?php unset($__componentOriginal14eb9ac9ab1b9936321678816133c448); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginal14eb9ac9ab1b9936321678816133c448 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal14eb9ac9ab1b9936321678816133c448 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.detail-row','data' => ['label' => 'Address']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('detail-row'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Address']); ?>
            <?php $__currentLoopData = $partner->translations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $translation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php echo e($translation->address); ?>

                <span class="text-gray-500">|</span>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal14eb9ac9ab1b9936321678816133c448)): ?>
<?php $attributes = $__attributesOriginal14eb9ac9ab1b9936321678816133c448; ?>
<?php unset($__attributesOriginal14eb9ac9ab1b9936321678816133c448); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal14eb9ac9ab1b9936321678816133c448)): ?>
<?php $component = $__componentOriginal14eb9ac9ab1b9936321678816133c448; ?>
<?php unset($__componentOriginal14eb9ac9ab1b9936321678816133c448); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginal14eb9ac9ab1b9936321678816133c448 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal14eb9ac9ab1b9936321678816133c448 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.detail-row','data' => ['label' => 'Active']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('detail-row'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Active']); ?>
            <?php if($partner->is_active): ?>
                <?php if (isset($component)) { $__componentOriginal643fe1b47aec0b76658e1a0200b34b2c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c = $attributes; } ?>
<?php $component = BladeUI\Icons\Components\Svg::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('heroicon-o-check-circle'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(BladeUI\Icons\Components\Svg::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'w-5 h-5 text-green-500']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c)): ?>
<?php $attributes = $__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c; ?>
<?php unset($__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal643fe1b47aec0b76658e1a0200b34b2c)): ?>
<?php $component = $__componentOriginal643fe1b47aec0b76658e1a0200b34b2c; ?>
<?php unset($__componentOriginal643fe1b47aec0b76658e1a0200b34b2c); ?>
<?php endif; ?>
            <?php else: ?>
                <?php if (isset($component)) { $__componentOriginal643fe1b47aec0b76658e1a0200b34b2c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c = $attributes; } ?>
<?php $component = BladeUI\Icons\Components\Svg::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('heroicon-o-no-symbol'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(BladeUI\Icons\Components\Svg::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'w-5 h-5 text-red-500']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c)): ?>
<?php $attributes = $__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c; ?>
<?php unset($__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal643fe1b47aec0b76658e1a0200b34b2c)): ?>
<?php $component = $__componentOriginal643fe1b47aec0b76658e1a0200b34b2c; ?>
<?php unset($__componentOriginal643fe1b47aec0b76658e1a0200b34b2c); ?>
<?php endif; ?>
            <?php endif; ?>
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal14eb9ac9ab1b9936321678816133c448)): ?>
<?php $attributes = $__attributesOriginal14eb9ac9ab1b9936321678816133c448; ?>
<?php unset($__attributesOriginal14eb9ac9ab1b9936321678816133c448); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal14eb9ac9ab1b9936321678816133c448)): ?>
<?php $component = $__componentOriginal14eb9ac9ab1b9936321678816133c448; ?>
<?php unset($__componentOriginal14eb9ac9ab1b9936321678816133c448); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginal14eb9ac9ab1b9936321678816133c448 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal14eb9ac9ab1b9936321678816133c448 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.detail-row','data' => ['label' => 'Created']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('detail-row'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Created']); ?>
            <?php echo e($partner->created_at->timezone(config('app.timezone'))->format('d.m.Y H:i:s')); ?>

         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal14eb9ac9ab1b9936321678816133c448)): ?>
<?php $attributes = $__attributesOriginal14eb9ac9ab1b9936321678816133c448; ?>
<?php unset($__attributesOriginal14eb9ac9ab1b9936321678816133c448); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal14eb9ac9ab1b9936321678816133c448)): ?>
<?php $component = $__componentOriginal14eb9ac9ab1b9936321678816133c448; ?>
<?php unset($__componentOriginal14eb9ac9ab1b9936321678816133c448); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginal14eb9ac9ab1b9936321678816133c448 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal14eb9ac9ab1b9936321678816133c448 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.detail-row','data' => ['label' => 'Modified','last' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('detail-row'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Modified','last' => true]); ?>
            <?php echo e($partner->updated_at->timezone(config('app.timezone'))->format('d.m.Y H:i:s')); ?>

         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal14eb9ac9ab1b9936321678816133c448)): ?>
<?php $attributes = $__attributesOriginal14eb9ac9ab1b9936321678816133c448; ?>
<?php unset($__attributesOriginal14eb9ac9ab1b9936321678816133c448); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal14eb9ac9ab1b9936321678816133c448)): ?>
<?php $component = $__componentOriginal14eb9ac9ab1b9936321678816133c448; ?>
<?php unset($__componentOriginal14eb9ac9ab1b9936321678816133c448); ?>
<?php endif; ?>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal53747ceb358d30c0105769f8471417f6)): ?>
<?php $attributes = $__attributesOriginal53747ceb358d30c0105769f8471417f6; ?>
<?php unset($__attributesOriginal53747ceb358d30c0105769f8471417f6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal53747ceb358d30c0105769f8471417f6)): ?>
<?php $component = $__componentOriginal53747ceb358d30c0105769f8471417f6; ?>
<?php unset($__componentOriginal53747ceb358d30c0105769f8471417f6); ?>
<?php endif; ?>
    <?php echo $__env->make('partials.show-actions', [
        'resource' => 'partners',
        'permission' => 'delete-settings',
        'model' => $partner,
    ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal91fdd17964e43374ae18c674f95cdaa3)): ?>
<?php $attributes = $__attributesOriginal91fdd17964e43374ae18c674f95cdaa3; ?>
<?php unset($__attributesOriginal91fdd17964e43374ae18c674f95cdaa3); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal91fdd17964e43374ae18c674f95cdaa3)): ?>
<?php $component = $__componentOriginal91fdd17964e43374ae18c674f95cdaa3; ?>
<?php unset($__componentOriginal91fdd17964e43374ae18c674f95cdaa3); ?>
<?php endif; ?>
<?php /**PATH /home/vagrant/projects/eco-calc/resources/views/admin/partners/show.blade.php ENDPATH**/ ?>