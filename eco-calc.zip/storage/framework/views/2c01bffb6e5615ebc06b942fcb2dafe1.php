<div class="<?php echo $attributes['class']; ?> lg:mb-6 p-6 bg-white rounded-3xl shadow-md">
    <?php echo e($slot); ?>

</div>
<?php /**PATH /home/vagrant/projects/eco-calc/resources/views/components/card.blade.php ENDPATH**/ ?>