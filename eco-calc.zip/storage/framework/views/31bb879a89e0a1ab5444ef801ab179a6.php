<?php ($isDark = (isset($dark) && $dark)); ?>
<?php ($align = $align ?? 'right'); ?>
<?php if (isset($component)) { $__componentOriginal22af8f4d7d0f6890ef966af626f1c568 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal22af8f4d7d0f6890ef966af626f1c568 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.dropdown-mobile-menu','data' => ['align' => $align,'width' => 'full','contentClasses' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('dropdown-mobile-menu'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['align' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($align),'width' => 'full','content-classes' => true]); ?>
     <?php $__env->slot('trigger', null, []); ?> 
        <button id="hamburger"
                class="inline-flex items-center justify-center focus:outline-none transition duration-150 ease-in-out">
            <svg  viewBox="473.0756 246.9526 20.2994 11.4598" width="24" height="24" xmlns="http://www.w3.org/2000/svg">
                <mask id="mask0_942_6565" style="mask-type:alpha" maskUnits="userSpaceOnUse" x="0" y="0" width="24" height="24">
                    <rect width="24" height="24" fill="currentColor"/>
                </mask>
                <g mask="url(#mask0_942_6565)" transform="matrix(1.1277459859848022, 0, 0, 0.6811169981956482, 469.69233577526575, 244.2281566926286)" style="">
                    <path d="M 9 20.825 L 9 18.021 L 21 18.021 L 21 20.825 L 9 20.825 Z M 3 13.815 L 3 11.011 L 21 11.011 L 21 13.815 L 3 13.815 Z M 9 6.804 L 9 4 L 21 4 L 21 6.804 L 9 6.804 Z" fill="currentColor"/>
                </g>
            </svg>
        </button>
     <?php $__env->endSlot(); ?>
     <?php $__env->slot('content', null, []); ?> 
        <?php echo $__env->make('partials.menu-items', ['mobile' => true], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
     <?php $__env->endSlot(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal22af8f4d7d0f6890ef966af626f1c568)): ?>
<?php $attributes = $__attributesOriginal22af8f4d7d0f6890ef966af626f1c568; ?>
<?php unset($__attributesOriginal22af8f4d7d0f6890ef966af626f1c568); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal22af8f4d7d0f6890ef966af626f1c568)): ?>
<?php $component = $__componentOriginal22af8f4d7d0f6890ef966af626f1c568; ?>
<?php unset($__componentOriginal22af8f4d7d0f6890ef966af626f1c568); ?>
<?php endif; ?>
<?php /**PATH /home/vagrant/projects/eco-calc/resources/views/partials/mobile-menu.blade.php ENDPATH**/ ?>