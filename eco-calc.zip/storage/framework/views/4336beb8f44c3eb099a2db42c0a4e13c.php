<svg <?php echo $attributes; ?> viewBox="0 0 27 27" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path
        d="M0.444111 8.964H6.0414V26.9979H0.444111V8.964ZM3.24222 0C5.03147 0 6.48444 1.45657 6.48444 3.25108C6.48444 5.04559 5.03041 6.50002 3.24222 6.50002C1.45404 6.50002 0 5.04452 0 3.25108C0 1.45764 1.44976 0 3.24222 0Z"
        fill="currentColor"/>
    <path
        d="M9.55051 8.964H14.9172V11.4301H14.9941C15.7414 10.012 17.5669 8.51804 20.2882 8.51804C25.9538 8.51804 27 12.2514 27 17.1077V26.9989H21.407V18.2296C21.407 16.1378 21.3707 13.4481 18.5 13.4481C15.6293 13.4481 15.1435 15.7282 15.1435 18.0799V27H9.55051V8.964Z"
        fill="currentColor"/>
</svg>
<?php /**PATH /home/vagrant/projects/eco-calc/resources/views/components/icon-linkedin.blade.php ENDPATH**/ ?>