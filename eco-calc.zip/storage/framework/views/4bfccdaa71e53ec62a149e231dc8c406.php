<div class="flex flex-col md:flex-row justify-between items-center">
    <?php if (isset($component)) { $__componentOriginale24d542b14cdce1c7553e932742a57bc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale24d542b14cdce1c7553e932742a57bc = $attributes; } ?>
<?php $component = App\View\Components\Btn::resolve(['color' => 'gray','link' => true] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('btn'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Btn::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'mb-3 md:mb-0 w-full md:w-auto','href' => ''.e(back()->getTargetUrl()).'']); ?>Back <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale24d542b14cdce1c7553e932742a57bc)): ?>
<?php $attributes = $__attributesOriginale24d542b14cdce1c7553e932742a57bc; ?>
<?php unset($__attributesOriginale24d542b14cdce1c7553e932742a57bc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale24d542b14cdce1c7553e932742a57bc)): ?>
<?php $component = $__componentOriginale24d542b14cdce1c7553e932742a57bc; ?>
<?php unset($__componentOriginale24d542b14cdce1c7553e932742a57bc); ?>
<?php endif; ?>
    <?php if(isset($permission) && $permission && Auth::user()->can($permission)): ?>
        <?php if (isset($component)) { $__componentOriginal9f64f32e90b9102968f2bc548315018c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9f64f32e90b9102968f2bc548315018c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.modal','data' => ['closeButton' => true,'name' => 'Remove '.e(strtolower(class_basename(get_class($model)))).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['closeButton' => true,'name' => 'Remove '.e(strtolower(class_basename(get_class($model)))).'']); ?>
             <?php $__env->slot('trigger', null, []); ?> 
                <?php if (isset($component)) { $__componentOriginale24d542b14cdce1c7553e932742a57bc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale24d542b14cdce1c7553e932742a57bc = $attributes; } ?>
<?php $component = App\View\Components\Btn::resolve(['color' => 'red'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('btn'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Btn::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'mb-3 md:mb-0 !w-full md:w-auto','type' => 'button','x-on:click' => 'isModalOpen = true']); ?>Delete <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale24d542b14cdce1c7553e932742a57bc)): ?>
<?php $attributes = $__attributesOriginale24d542b14cdce1c7553e932742a57bc; ?>
<?php unset($__attributesOriginale24d542b14cdce1c7553e932742a57bc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale24d542b14cdce1c7553e932742a57bc)): ?>
<?php $component = $__componentOriginale24d542b14cdce1c7553e932742a57bc; ?>
<?php unset($__componentOriginale24d542b14cdce1c7553e932742a57bc); ?>
<?php endif; ?>
             <?php $__env->endSlot(); ?>
            <div class="modal-content">
                <form id="deleteForm" action="<?php echo e(route('back-office.'.$resource.'.destroy', $model)); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('delete'); ?>
                    <div class="py-4">
                        <p class="text-xl text-center text-gray-900">Are you sure, that you want to delete
                            the <?php echo e(strtolower(class_basename(get_class($model)))); ?> absolutely?</p>
                    </div>
                    <hr>
                    <div class="flex justify-between pt-4">
                        <?php if (isset($component)) { $__componentOriginale24d542b14cdce1c7553e932742a57bc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale24d542b14cdce1c7553e932742a57bc = $attributes; } ?>
<?php $component = App\View\Components\Btn::resolve(['color' => 'ghost'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('btn'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Btn::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'button','x-on:click' => 'isModalOpen = false','class' => 'mr-4']); ?>Cancel <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale24d542b14cdce1c7553e932742a57bc)): ?>
<?php $attributes = $__attributesOriginale24d542b14cdce1c7553e932742a57bc; ?>
<?php unset($__attributesOriginale24d542b14cdce1c7553e932742a57bc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale24d542b14cdce1c7553e932742a57bc)): ?>
<?php $component = $__componentOriginale24d542b14cdce1c7553e932742a57bc; ?>
<?php unset($__componentOriginale24d542b14cdce1c7553e932742a57bc); ?>
<?php endif; ?>
                        <?php if (isset($component)) { $__componentOriginale24d542b14cdce1c7553e932742a57bc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale24d542b14cdce1c7553e932742a57bc = $attributes; } ?>
<?php $component = App\View\Components\Btn::resolve(['color' => 'red'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('btn'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Btn::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['form' => 'deleteForm']); ?>Sure <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale24d542b14cdce1c7553e932742a57bc)): ?>
<?php $attributes = $__attributesOriginale24d542b14cdce1c7553e932742a57bc; ?>
<?php unset($__attributesOriginale24d542b14cdce1c7553e932742a57bc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale24d542b14cdce1c7553e932742a57bc)): ?>
<?php $component = $__componentOriginale24d542b14cdce1c7553e932742a57bc; ?>
<?php unset($__componentOriginale24d542b14cdce1c7553e932742a57bc); ?>
<?php endif; ?>
                    </div>
                </form>
            </div>
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9f64f32e90b9102968f2bc548315018c)): ?>
<?php $attributes = $__attributesOriginal9f64f32e90b9102968f2bc548315018c; ?>
<?php unset($__attributesOriginal9f64f32e90b9102968f2bc548315018c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9f64f32e90b9102968f2bc548315018c)): ?>
<?php $component = $__componentOriginal9f64f32e90b9102968f2bc548315018c; ?>
<?php unset($__componentOriginal9f64f32e90b9102968f2bc548315018c); ?>
<?php endif; ?>
    <?php endif; ?>
    <?php if(isset($editPermission) ? Auth::user()->can($editPermission) : true): ?>
        <?php if (isset($component)) { $__componentOriginale24d542b14cdce1c7553e932742a57bc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale24d542b14cdce1c7553e932742a57bc = $attributes; } ?>
<?php $component = App\View\Components\Btn::resolve(['link' => true,'color' => 'green'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('btn'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Btn::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'w-full md:w-auto','href' => ''.e(route('back-office.'.$resource.'.edit', $model)).'']); ?>Edit <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale24d542b14cdce1c7553e932742a57bc)): ?>
<?php $attributes = $__attributesOriginale24d542b14cdce1c7553e932742a57bc; ?>
<?php unset($__attributesOriginale24d542b14cdce1c7553e932742a57bc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale24d542b14cdce1c7553e932742a57bc)): ?>
<?php $component = $__componentOriginale24d542b14cdce1c7553e932742a57bc; ?>
<?php unset($__componentOriginale24d542b14cdce1c7553e932742a57bc); ?>
<?php endif; ?>
    <?php endif; ?>
</div>
<?php /**PATH /home/vagrant/projects/eco-calc/resources/views/partials/show-actions.blade.php ENDPATH**/ ?>