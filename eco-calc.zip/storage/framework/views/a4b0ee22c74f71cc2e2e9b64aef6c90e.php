<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps(['active' => false, 'mobile' => false, 'light' => false]) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps(['active' => false, 'mobile' => false, 'light' => false]); ?>
<?php foreach (array_filter((['active' => false, 'mobile' => false, 'light' => false]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>

<?php if($mobile): ?>
    <?php
        $textColor = $light ? 'text-white' : 'text-gray-900';
        $classes = $active
                    ? 'flex justify-center items-center capitalize px-4 py-2 text-xl ' . $textColor . ' !text-green-500 font-bold focus:outline-none transition duration-150 ease-in-out'
                    : 'flex justify-center items-center capitalize px-4 py-2 text-xl ' . $textColor . ' hover:font-bold focus:outline-none transition duration-150 ease-in-out cursor-pointer';
    ?>
<?php else: ?>
    <?php
        $textColor = $light ? 'text-white !uppercase' : 'text-gray-900';
        $classes = $active
                    ? 'inline-block text-center capitalize pb-0.5 px-0.5 mr-4 text-sm ' . $textColor . ' !text-green-500 font-semibold focus:outline-none transition duration-150 ease-in-out'
                    : 'inline-block text-center capitalize pb-0.5 px-0.5 mr-4 text-sm ' . $textColor . ' font-semibold hover:text-green-500 focus:outline-none transition duration-150 ease-in-out cursor-pointer';
    ?>
<?php endif; ?>
<a <?php echo e($attributes->merge(['class' => $classes])); ?>>
    <?php echo e($slot); ?>

</a>
<?php /**PATH /home/vagrant/projects/eco-calc/resources/views/components/responsive-nav-link.blade.php ENDPATH**/ ?>