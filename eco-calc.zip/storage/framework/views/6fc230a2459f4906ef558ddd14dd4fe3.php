<svg <?php echo e($attributes->merge(['class' => 'h-5 w-5 stroke-current'])); ?> fill="none" viewBox="0 0 24 24" stroke="currentColor">
    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7" />
</svg>
<?php /**PATH /home/vagrant/projects/eco-calc/vendor/arm092/livewire-datatables/src/../resources/views/icons/chevron-down.blade.php ENDPATH**/ ?>