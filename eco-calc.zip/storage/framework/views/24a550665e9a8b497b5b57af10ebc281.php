<?php if (isset($component)) { $__componentOriginal30e9d84a3edfe48dae22daf7d40b486f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal30e9d84a3edfe48dae22daf7d40b486f = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.modal-bulk-approve','data' => ['closeButton' => true,'size' => 'lg:w-6/12']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('modal-bulk-approve'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['closeButton' => true,'size' => 'lg:w-6/12']); ?>
     <?php $__env->slot('trigger', null, []); ?> 
        <?php if (isset($component)) { $__componentOriginale24d542b14cdce1c7553e932742a57bc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale24d542b14cdce1c7553e932742a57bc = $attributes; } ?>
<?php $component = App\View\Components\Btn::resolve(['color' => 'green'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('btn'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Btn::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'button','class' => 'text-base','x-on:click' => 'isBulkApproveModalOpen = true']); ?><?php echo e(__('phrases.bulk_update')); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale24d542b14cdce1c7553e932742a57bc)): ?>
<?php $attributes = $__attributesOriginale24d542b14cdce1c7553e932742a57bc; ?>
<?php unset($__attributesOriginale24d542b14cdce1c7553e932742a57bc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale24d542b14cdce1c7553e932742a57bc)): ?>
<?php $component = $__componentOriginale24d542b14cdce1c7553e932742a57bc; ?>
<?php unset($__componentOriginale24d542b14cdce1c7553e932742a57bc); ?>
<?php endif; ?>
     <?php $__env->endSlot(); ?>
    <div class="modal-content">
        <div class="py-4">
            <p class="text-xl text-center text-gray-900"><?php echo e(__('phrases.bulk_update')); ?></p>
        </div>
        <hr>
        <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('bulk-update', ['type' => $type]);

$__html = app('livewire')->mount($__name, $__params, 'lw-431304048-0', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal30e9d84a3edfe48dae22daf7d40b486f)): ?>
<?php $attributes = $__attributesOriginal30e9d84a3edfe48dae22daf7d40b486f; ?>
<?php unset($__attributesOriginal30e9d84a3edfe48dae22daf7d40b486f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal30e9d84a3edfe48dae22daf7d40b486f)): ?>
<?php $component = $__componentOriginal30e9d84a3edfe48dae22daf7d40b486f; ?>
<?php unset($__componentOriginal30e9d84a3edfe48dae22daf7d40b486f); ?>
<?php endif; ?><?php /**PATH /home/vagrant/projects/eco-calc/resources/views/partials/bulk_approve_button.blade.php ENDPATH**/ ?>