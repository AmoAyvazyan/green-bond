<svg class="w-4 ml-4" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" aria-hidden="true" data-slot="icon">
  <path stroke-linecap="round" stroke-linejoin="round" d="M17.25 8.25 21 12m0 0-3.75 3.75M21 12H3"/>
</svg><?php /**PATH /home/vagrant/projects/eco-calc/storage/framework/views/d9ea1f7d9915054559c99b0a1079d7e5.blade.php ENDPATH**/ ?>