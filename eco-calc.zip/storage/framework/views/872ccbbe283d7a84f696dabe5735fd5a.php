<!--[if BLOCK]><![endif]--><?php if (! ($column['hidden'])): ?>
    <div
        <?php if(isset($column['tooltip']['text'])): ?> title="<?php echo e($column['tooltip']['text']); ?>" <?php endif; ?>
    class="relative table-cell h-12 overflow-hidden align-top"  <?php echo $__env->make('datatables::style-width', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    >
        <!--[if BLOCK]><![endif]--><?php if($column['sortable']): ?>
            <button wire:click="sort('<?php echo e($index); ?>')"
                    class="w-full h-full p-3 border-b border-gray-50 bg-gray-900 text-left text-xs leading-4 font-medium text-gray-50 uppercase tracking-wider flex items-center focus:outline-none <?php if($column['headerAlign'] === 'right'): ?> justify-end <?php elseif($column['headerAlign'] === 'center'): ?> justify-center <?php endif; ?>">
                <span class="inline "><?php echo e(str_replace('_', ' ', $column['label'])); ?></span>
                <span class="inline text-xs text-blue-400">
                    <!--[if BLOCK]><![endif]--><?php if($sortIndex === $index): ?>
                        <!--[if BLOCK]><![endif]--><?php if($direction): ?>
                            <?php if (isset($component)) { $__componentOriginal7c8cb3634876f8430f20291d6ef649c1 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal7c8cb3634876f8430f20291d6ef649c1 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'icons::chevron-up','data' => ['wire:loading.remove' => true,'class' => 'w-6 h-6 text-yellow-500 stroke-current']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('icons.chevron-up'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['wire:loading.remove' => true,'class' => 'w-6 h-6 text-yellow-500 stroke-current']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal7c8cb3634876f8430f20291d6ef649c1)): ?>
<?php $attributes = $__attributesOriginal7c8cb3634876f8430f20291d6ef649c1; ?>
<?php unset($__attributesOriginal7c8cb3634876f8430f20291d6ef649c1); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7c8cb3634876f8430f20291d6ef649c1)): ?>
<?php $component = $__componentOriginal7c8cb3634876f8430f20291d6ef649c1; ?>
<?php unset($__componentOriginal7c8cb3634876f8430f20291d6ef649c1); ?>
<?php endif; ?>
                        <?php else: ?>
                            <?php if (isset($component)) { $__componentOriginalfb5ab559e4014313073efeb5cdff727a = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalfb5ab559e4014313073efeb5cdff727a = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'icons::chevron-down','data' => ['wire:loading.remove' => true,'class' => 'w-6 h-6 text-yellow-500 stroke-current']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('icons.chevron-down'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['wire:loading.remove' => true,'class' => 'w-6 h-6 text-yellow-500 stroke-current']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalfb5ab559e4014313073efeb5cdff727a)): ?>
<?php $attributes = $__attributesOriginalfb5ab559e4014313073efeb5cdff727a; ?>
<?php unset($__attributesOriginalfb5ab559e4014313073efeb5cdff727a); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalfb5ab559e4014313073efeb5cdff727a)): ?>
<?php $component = $__componentOriginalfb5ab559e4014313073efeb5cdff727a; ?>
<?php unset($__componentOriginalfb5ab559e4014313073efeb5cdff727a); ?>
<?php endif; ?>
                        <?php endif; ?> <!--[if ENDBLOCK]><![endif]-->
                    <?php endif; ?> <!--[if ENDBLOCK]><![endif]-->
                </span>
            </button>
        <?php else: ?>
            <div
                class="w-full h-full p-3 border-b border-gray-50 bg-gray-900 text-left text-xs leading-4 font-medium text-gray-50 uppercase tracking-wider flex items-center focus:outline-none <?php if($column['headerAlign'] === 'right'): ?> justify-end <?php elseif($column['headerAlign'] === 'center'): ?> justify-center <?php endif; ?>">
                <span class="inline "><?php echo e(str_replace('_', ' ', $column['label'])); ?></span>
            </div>
        <?php endif; ?> <!--[if ENDBLOCK]><![endif]-->
    </div>
<?php endif; ?> <!--[if ENDBLOCK]><![endif]-->
<?php /**PATH /home/vagrant/projects/eco-calc/resources/views/livewire/datatables/header-no-hide.blade.php ENDPATH**/ ?>