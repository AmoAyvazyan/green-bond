<?php if (! $__env->hasRenderedOnce('819bea7c-d1fb-442e-9062-bfc8eefc65e7')): $__env->markAsRenderedOnce('819bea7c-d1fb-442e-9062-bfc8eefc65e7'); ?>
    <?php $__env->startPush('styles'); ?>
        <?php echo app('Illuminate\Foundation\Vite')('resources/sass/slider.scss'); ?>
    <?php $__env->stopPush(); ?>
<?php endif; ?>
<?php if (! $__env->hasRenderedOnce('119f12c2-04e7-4d51-b5d4-21807b90f9e7')): $__env->markAsRenderedOnce('119f12c2-04e7-4d51-b5d4-21807b90f9e7'); ?>
    <?php $__env->startPush('scripts'); ?>
        <?php echo app('Illuminate\Foundation\Vite')('resources/js/slider.js'); ?>
    <?php $__env->stopPush(); ?>
<?php endif; ?>
<?php /**PATH /home/vagrant/projects/eco-calc/resources/views/components/slider-assets.blade.php ENDPATH**/ ?>