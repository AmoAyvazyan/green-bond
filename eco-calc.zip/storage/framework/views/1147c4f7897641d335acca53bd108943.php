<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps(['improvement' => null]) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps(['improvement' => null]); ?>
<?php foreach (array_filter((['improvement' => null]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>
<div>
    <div class="grid grid-cols-1 lg:grid-cols-3 lg:gap-x-8 gap-y-8 lg:gap-y-0">
        <!--[if BLOCK]><![endif]--><?php if($improvement->has_quantity): ?>
            <div>
                <div
                    class="flex flex-col items-start lg:flex-row lg:items-center justify-start lg:justify-between lg:space-x-6">
                    <?php if (isset($component)) { $__componentOriginald8ba2b4c22a13c55321e34443c386276 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald8ba2b4c22a13c55321e34443c386276 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.label','data' => ['class' => 'mb-4 lg:mb-0','for' => 'quantity_'.e($improvement->id).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'mb-4 lg:mb-0','for' => 'quantity_'.e($improvement->id).'']); ?><?php echo e(__('phrases.quantity')); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald8ba2b4c22a13c55321e34443c386276)): ?>
<?php $attributes = $__attributesOriginald8ba2b4c22a13c55321e34443c386276; ?>
<?php unset($__attributesOriginald8ba2b4c22a13c55321e34443c386276); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald8ba2b4c22a13c55321e34443c386276)): ?>
<?php $component = $__componentOriginald8ba2b4c22a13c55321e34443c386276; ?>
<?php unset($__componentOriginald8ba2b4c22a13c55321e34443c386276); ?>
<?php endif; ?>
                    <?php if (isset($component)) { $__componentOriginal472179c7d38f01ce85abf9cdf38a254a = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal472179c7d38f01ce85abf9cdf38a254a = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-unit','data' => ['id' => 'quantity_'.e($improvement->id).'','type' => 'text','inputmode' => 'numeric','xOn:input' => 'event.target.value = event.target.value.replace(/[^0-9]/g, \'\')','unit' => __('phrases.pcs'),'wire:model.live.debounce.1000' => 'applied_ee_improvement_data.'.e($improvement->id).'.quantity']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('input-unit'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => 'quantity_'.e($improvement->id).'','type' => 'text','inputmode' => 'numeric','x-on:input' => 'event.target.value = event.target.value.replace(/[^0-9]/g, \'\')','unit' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(__('phrases.pcs')),'wire:model.live.debounce.1000' => 'applied_ee_improvement_data.'.e($improvement->id).'.quantity']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal472179c7d38f01ce85abf9cdf38a254a)): ?>
<?php $attributes = $__attributesOriginal472179c7d38f01ce85abf9cdf38a254a; ?>
<?php unset($__attributesOriginal472179c7d38f01ce85abf9cdf38a254a); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal472179c7d38f01ce85abf9cdf38a254a)): ?>
<?php $component = $__componentOriginal472179c7d38f01ce85abf9cdf38a254a; ?>
<?php unset($__componentOriginal472179c7d38f01ce85abf9cdf38a254a); ?>
<?php endif; ?>
                </div>
                <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['applied_ee_improvement_data.'.$improvement->id.'.quantity'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="text-red-500 text-xs mt-2 text-right"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> <!--[if ENDBLOCK]><![endif]-->
            </div>
        <?php endif; ?> <!--[if ENDBLOCK]><![endif]-->
        <!--[if BLOCK]><![endif]--><?php if($improvement->has_power): ?>
            <div>
                <div
                    class="flex flex-col items-start lg:flex-row lg:items-center justify-start lg:justify-between lg:space-x-6">
                    <?php if (isset($component)) { $__componentOriginald8ba2b4c22a13c55321e34443c386276 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald8ba2b4c22a13c55321e34443c386276 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.label','data' => ['class' => 'mb-4 lg:mb-0','for' => 'power_'.e($improvement->id).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'mb-4 lg:mb-0','for' => 'power_'.e($improvement->id).'']); ?><?php echo e(__('phrases.power')); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald8ba2b4c22a13c55321e34443c386276)): ?>
<?php $attributes = $__attributesOriginald8ba2b4c22a13c55321e34443c386276; ?>
<?php unset($__attributesOriginald8ba2b4c22a13c55321e34443c386276); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald8ba2b4c22a13c55321e34443c386276)): ?>
<?php $component = $__componentOriginald8ba2b4c22a13c55321e34443c386276; ?>
<?php unset($__componentOriginald8ba2b4c22a13c55321e34443c386276); ?>
<?php endif; ?>
                    <?php if (isset($component)) { $__componentOriginal472179c7d38f01ce85abf9cdf38a254a = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal472179c7d38f01ce85abf9cdf38a254a = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-unit','data' => ['id' => 'power_'.e($improvement->id).'','type' => 'tex','inputmode' => 'numeric','xOn:input' => 'event.target.value = event.target.value.replace(\'․\', \'.\').replace(/[^0-9.,]/g, \'\')','unit' => $improvement->slug === \App\Models\EeImprovement::SLUG_LIGHTING ? __('phrases.Wt') :__('phrases.kWt'),'wire:model.live.debounce.1000' => 'applied_ee_improvement_data.'.e($improvement->id).'.power']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('input-unit'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => 'power_'.e($improvement->id).'','type' => 'tex','inputmode' => 'numeric','x-on:input' => 'event.target.value = event.target.value.replace(\'․\', \'.\').replace(/[^0-9.,]/g, \'\')','unit' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($improvement->slug === \App\Models\EeImprovement::SLUG_LIGHTING ? __('phrases.Wt') :__('phrases.kWt')),'wire:model.live.debounce.1000' => 'applied_ee_improvement_data.'.e($improvement->id).'.power']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal472179c7d38f01ce85abf9cdf38a254a)): ?>
<?php $attributes = $__attributesOriginal472179c7d38f01ce85abf9cdf38a254a; ?>
<?php unset($__attributesOriginal472179c7d38f01ce85abf9cdf38a254a); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal472179c7d38f01ce85abf9cdf38a254a)): ?>
<?php $component = $__componentOriginal472179c7d38f01ce85abf9cdf38a254a; ?>
<?php unset($__componentOriginal472179c7d38f01ce85abf9cdf38a254a); ?>
<?php endif; ?>
                </div>
                <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['applied_ee_improvement_data.'.$improvement->id.'.power'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="text-red-500 text-xs mt-2 text-right"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> <!--[if ENDBLOCK]><![endif]-->
            </div>
        <?php endif; ?> <!--[if ENDBLOCK]><![endif]-->
        <!--[if BLOCK]><![endif]--><?php if($improvement->has_area): ?>
            <div>
                <div
                    class="flex flex-col items-start lg:flex-row lg:items-center justify-start lg:justify-between lg:space-x-6">
                    <?php if (isset($component)) { $__componentOriginald8ba2b4c22a13c55321e34443c386276 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald8ba2b4c22a13c55321e34443c386276 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.label','data' => ['class' => 'mb-4 lg:mb-0','for' => 'area_'.e($improvement->id).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'mb-4 lg:mb-0','for' => 'area_'.e($improvement->id).'']); ?><?php echo e(__('phrases.area')); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald8ba2b4c22a13c55321e34443c386276)): ?>
<?php $attributes = $__attributesOriginald8ba2b4c22a13c55321e34443c386276; ?>
<?php unset($__attributesOriginald8ba2b4c22a13c55321e34443c386276); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald8ba2b4c22a13c55321e34443c386276)): ?>
<?php $component = $__componentOriginald8ba2b4c22a13c55321e34443c386276; ?>
<?php unset($__componentOriginald8ba2b4c22a13c55321e34443c386276); ?>
<?php endif; ?>
                    <?php if (isset($component)) { $__componentOriginal472179c7d38f01ce85abf9cdf38a254a = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal472179c7d38f01ce85abf9cdf38a254a = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-unit','data' => ['id' => 'area_'.e($improvement->id).'','type' => 'text','unit' => __('phrases.sqm'),'inputmode' => 'numeric','xOn:input' => 'event.target.value = event.target.value.replace(/[,․,]/g, \'.\').replace(/[^0-9.]/g, \'\')','wire:model.live.debounce.1000' => 'applied_ee_improvement_data.'.e($improvement->id).'.area']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('input-unit'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => 'area_'.e($improvement->id).'','type' => 'text','unit' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(__('phrases.sqm')),'inputmode' => 'numeric','x-on:input' => 'event.target.value = event.target.value.replace(/[,․,]/g, \'.\').replace(/[^0-9.]/g, \'\')','wire:model.live.debounce.1000' => 'applied_ee_improvement_data.'.e($improvement->id).'.area']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal472179c7d38f01ce85abf9cdf38a254a)): ?>
<?php $attributes = $__attributesOriginal472179c7d38f01ce85abf9cdf38a254a; ?>
<?php unset($__attributesOriginal472179c7d38f01ce85abf9cdf38a254a); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal472179c7d38f01ce85abf9cdf38a254a)): ?>
<?php $component = $__componentOriginal472179c7d38f01ce85abf9cdf38a254a; ?>
<?php unset($__componentOriginal472179c7d38f01ce85abf9cdf38a254a); ?>
<?php endif; ?>
                </div>
                <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['applied_ee_improvement_data.'.$improvement->id.'.area'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="text-red-500 text-xs mt-2 text-right"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> <!--[if ENDBLOCK]><![endif]-->
            </div>
        <?php endif; ?> <!--[if ENDBLOCK]><![endif]-->
        <!--[if BLOCK]><![endif]--><?php if($improvement->has_volume): ?>
            <div class="lg:col-span-2">
                <div
                    class="flex flex-col items-start lg:flex-row lg:items-center justify-start lg:justify-between lg:space-x-6">
                    <?php if (isset($component)) { $__componentOriginald8ba2b4c22a13c55321e34443c386276 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald8ba2b4c22a13c55321e34443c386276 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.label','data' => ['class' => 'mb-4 lg:mb-0 lg:whitespace-nowrap','for' => 'volume_'.e($improvement->id).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'mb-4 lg:mb-0 lg:whitespace-nowrap','for' => 'volume_'.e($improvement->id).'']); ?><?php echo e(__('phrases.volume')); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald8ba2b4c22a13c55321e34443c386276)): ?>
<?php $attributes = $__attributesOriginald8ba2b4c22a13c55321e34443c386276; ?>
<?php unset($__attributesOriginald8ba2b4c22a13c55321e34443c386276); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald8ba2b4c22a13c55321e34443c386276)): ?>
<?php $component = $__componentOriginald8ba2b4c22a13c55321e34443c386276; ?>
<?php unset($__componentOriginald8ba2b4c22a13c55321e34443c386276); ?>
<?php endif; ?>
                    <?php if (isset($component)) { $__componentOriginal472179c7d38f01ce85abf9cdf38a254a = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal472179c7d38f01ce85abf9cdf38a254a = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-unit','data' => ['id' => 'volume_'.e($improvement->id).'','type' => 'text','unit' => __('phrases.liter'),'inputmode' => 'numeric','xOn:input' => 'event.target.value = event.target.value.replace(/[^0-9]/g, \'\')','wire:model.live.debounce.1000' => 'applied_ee_improvement_data.'.e($improvement->id).'.volume']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('input-unit'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => 'volume_'.e($improvement->id).'','type' => 'text','unit' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(__('phrases.liter')),'inputmode' => 'numeric','x-on:input' => 'event.target.value = event.target.value.replace(/[^0-9]/g, \'\')','wire:model.live.debounce.1000' => 'applied_ee_improvement_data.'.e($improvement->id).'.volume']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal472179c7d38f01ce85abf9cdf38a254a)): ?>
<?php $attributes = $__attributesOriginal472179c7d38f01ce85abf9cdf38a254a; ?>
<?php unset($__attributesOriginal472179c7d38f01ce85abf9cdf38a254a); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal472179c7d38f01ce85abf9cdf38a254a)): ?>
<?php $component = $__componentOriginal472179c7d38f01ce85abf9cdf38a254a; ?>
<?php unset($__componentOriginal472179c7d38f01ce85abf9cdf38a254a); ?>
<?php endif; ?>
                </div>
                <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['applied_ee_improvement_data.'.$improvement->id.'.volume'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="text-red-500 text-xs mt-2 text-right"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> <!--[if ENDBLOCK]><![endif]-->
            </div>
        <?php endif; ?> <!--[if ENDBLOCK]><![endif]-->
        <!--[if BLOCK]><![endif]--><?php if($improvement->has_thickness): ?>
            <div>
                <div
                    class="flex flex-col items-start lg:flex-row lg:items-center justify-start lg:justify-between lg:space-x-6">
                    <?php if (isset($component)) { $__componentOriginald8ba2b4c22a13c55321e34443c386276 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald8ba2b4c22a13c55321e34443c386276 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.label','data' => ['class' => 'mb-4 lg:mb-0','for' => 'volume_'.e($improvement->id).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'mb-4 lg:mb-0','for' => 'volume_'.e($improvement->id).'']); ?><?php echo e(__('phrases.thickness')); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald8ba2b4c22a13c55321e34443c386276)): ?>
<?php $attributes = $__attributesOriginald8ba2b4c22a13c55321e34443c386276; ?>
<?php unset($__attributesOriginald8ba2b4c22a13c55321e34443c386276); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald8ba2b4c22a13c55321e34443c386276)): ?>
<?php $component = $__componentOriginald8ba2b4c22a13c55321e34443c386276; ?>
<?php unset($__componentOriginald8ba2b4c22a13c55321e34443c386276); ?>
<?php endif; ?>
                    <?php if (isset($component)) { $__componentOriginal472179c7d38f01ce85abf9cdf38a254a = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal472179c7d38f01ce85abf9cdf38a254a = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-unit','data' => ['id' => 'volume_'.e($improvement->id).'','type' => 'text','unit' => __('phrases.cm'),'inputmode' => 'numeric','xOn:input' => 'event.target.value = event.target.value.replace(\'․\', \'.\').replace(/[^0-9.,]/g, \'\')','wire:model.live.debounce.1000' => 'applied_ee_improvement_data.'.e($improvement->id).'.thickness']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('input-unit'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => 'volume_'.e($improvement->id).'','type' => 'text','unit' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(__('phrases.cm')),'inputmode' => 'numeric','x-on:input' => 'event.target.value = event.target.value.replace(\'․\', \'.\').replace(/[^0-9.,]/g, \'\')','wire:model.live.debounce.1000' => 'applied_ee_improvement_data.'.e($improvement->id).'.thickness']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal472179c7d38f01ce85abf9cdf38a254a)): ?>
<?php $attributes = $__attributesOriginal472179c7d38f01ce85abf9cdf38a254a; ?>
<?php unset($__attributesOriginal472179c7d38f01ce85abf9cdf38a254a); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal472179c7d38f01ce85abf9cdf38a254a)): ?>
<?php $component = $__componentOriginal472179c7d38f01ce85abf9cdf38a254a; ?>
<?php unset($__componentOriginal472179c7d38f01ce85abf9cdf38a254a); ?>
<?php endif; ?>
                </div>
                <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['applied_ee_improvement_data.'.$improvement->id.'.thickness'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="text-red-500 text-xs mt-2 text-right"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> <!--[if ENDBLOCK]><![endif]-->
            </div>
        <?php endif; ?> <!--[if ENDBLOCK]><![endif]-->
        <!--[if BLOCK]><![endif]--><?php if($improvement->has_price): ?>
            <div>
                <div
                    class="flex flex-col items-start lg:flex-row lg:items-center justify-start lg:justify-between lg:space-x-6">
                    <?php if (isset($component)) { $__componentOriginald8ba2b4c22a13c55321e34443c386276 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald8ba2b4c22a13c55321e34443c386276 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.label','data' => ['class' => 'mb-4 lg:mb-0 whitespace-nowrap','for' => 'cost_'.e($improvement->id).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'mb-4 lg:mb-0 whitespace-nowrap','for' => 'cost_'.e($improvement->id).'']); ?><?php echo e(($improvement->has_volume || (!$improvement->has_quantity && !$improvement->has_area)) ? __('phrases.system_price') : __('phrases.price_one')); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald8ba2b4c22a13c55321e34443c386276)): ?>
<?php $attributes = $__attributesOriginald8ba2b4c22a13c55321e34443c386276; ?>
<?php unset($__attributesOriginald8ba2b4c22a13c55321e34443c386276); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald8ba2b4c22a13c55321e34443c386276)): ?>
<?php $component = $__componentOriginald8ba2b4c22a13c55321e34443c386276; ?>
<?php unset($__componentOriginald8ba2b4c22a13c55321e34443c386276); ?>
<?php endif; ?>
                    <?php if (isset($component)) { $__componentOriginal472179c7d38f01ce85abf9cdf38a254a = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal472179c7d38f01ce85abf9cdf38a254a = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-unit','data' => ['id' => 'cost_'.e($improvement->id).'','type' => 'text','inputmode' => 'numeric','xOn:input' => 'event.target.value = event.target.value.replace(/[^0-9]/g, \'\')','unit' => __('phrases.amd'),'xOn:blur' => 'event.target.value = window.formatter.format(event.target.value.replace(/[^0-9]/g, \'\'))','wire:model.live.debounce.1000' => 'applied_ee_improvement_data.'.e($improvement->id).'.price']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('input-unit'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => 'cost_'.e($improvement->id).'','type' => 'text','inputmode' => 'numeric','x-on:input' => 'event.target.value = event.target.value.replace(/[^0-9]/g, \'\')','unit' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(__('phrases.amd')),'x-on:blur' => 'event.target.value = window.formatter.format(event.target.value.replace(/[^0-9]/g, \'\'))','wire:model.live.debounce.1000' => 'applied_ee_improvement_data.'.e($improvement->id).'.price']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal472179c7d38f01ce85abf9cdf38a254a)): ?>
<?php $attributes = $__attributesOriginal472179c7d38f01ce85abf9cdf38a254a; ?>
<?php unset($__attributesOriginal472179c7d38f01ce85abf9cdf38a254a); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal472179c7d38f01ce85abf9cdf38a254a)): ?>
<?php $component = $__componentOriginal472179c7d38f01ce85abf9cdf38a254a; ?>
<?php unset($__componentOriginal472179c7d38f01ce85abf9cdf38a254a); ?>
<?php endif; ?>
                </div>
                <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['applied_ee_improvement_data.'.$improvement->id.'.price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="text-red-500 text-xs mt-2 text-right"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> <!--[if ENDBLOCK]><![endif]-->
            </div>
        <?php endif; ?> <!--[if ENDBLOCK]><![endif]-->
    </div>
    <!--[if BLOCK]><![endif]--><?php if($improvement->materials->isNotEmpty()): ?>
        <p class="mt-12 mb-6 text-black"><?php echo e(__('phrases.material')); ?></p>
        <div class="flex flex-wrap items-center max-w-[70%]"
             x-data="{<?php $__currentLoopData = $improvement->materials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $material): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> showMaterialPic_<?php echo e($improvement->id); ?>_<?php echo e($material->id); ?>: false, <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>}"
        >
            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $improvement->materials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $material): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <label for="material_<?php echo e($improvement->id); ?>_<?php echo e($material->id); ?>"
                       class="flex mr-2 mb-2 rounded-2xl border p-2 xs:p-4 items-center justify-center
                                              <?php echo e($applied_ee_improvement_data[$improvement->id]['material'] == $material->id
                                                    ? 'border-green-500 bg-white text-black'
                                                    : 'border-gray-400 text-gray-500 cursor-pointer'); ?>"
                       x-on:mouseenter="showMaterialPic_<?php echo e($improvement->id); ?>_<?php echo e($material->id); ?> = true"
                       x-on:mouseleave="showMaterialPic_<?php echo e($improvement->id); ?>_<?php echo e($material->id); ?> = false"
                >
                    <?php echo e($material->name); ?>

                </label>
                <input
                    class="hidden" value="<?php echo e($material->id); ?>" type="radio"
                    id="material_<?php echo e($improvement->id); ?>_<?php echo e($material->id); ?>">
                <div x-cloak
                     x-show="showMaterialPic_<?php echo e($improvement->id); ?>_<?php echo e($material->id); ?>"
                     class="absolute right-1 top-1 rounded-xl p-2 bg-white shadow-md w-[250px] md:w-[400px] h-[300px]">
                    <img data-src="<?php echo e($material->image); ?>" class="lazyload w-full h-full object-cover object-center rounded-xl"
                         alt="<?php echo e($material->name); ?>">
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> <!--[if ENDBLOCK]><![endif]-->
        </div>
        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['applied_ee_improvement_data.'.$improvement->id.'.material'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <p class="text-red-500 text-xs mt-2"><?php echo e($message); ?></p>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> <!--[if ENDBLOCK]><![endif]-->
    <?php endif; ?> <!--[if ENDBLOCK]><![endif]-->
    <div class="flex items-center space-x-2 mt-12">
        <div class="border-b border-gray-400 w-full"></div>
        <span class="text-gray-400 whitespace-nowrap"><?php echo e(__('phrases.total_amount')); ?> <span
                class="text-black"><?php echo e(number_format((float)(($applied_ee_improvement_data[$improvement->id]['quantity']
                                                        ?: $applied_ee_improvement_data[$improvement->id]['area']) ?: 1)
                                                        * (int) preg_replace("/[^0-9]/", '', $applied_ee_improvement_data[$improvement->id]['price']), 0, '.', ' ')); ?></span> <?php echo e(__('phrases.amd')); ?></span>
        <div class="border-b border-gray-400 w-full"></div>
    </div>
</div>
<?php /**PATH /home/vagrant/projects/eco-calc/resources/views/livewire/partials/ee-improvement-form.blade.php ENDPATH**/ ?>