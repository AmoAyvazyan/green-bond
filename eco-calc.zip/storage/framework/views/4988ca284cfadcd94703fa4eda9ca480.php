<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps([
    'closeButton' => false,
    'name' => null,
    'size' => 'lg:w-6/12',
]) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps([
    'closeButton' => false,
    'name' => null,
    'size' => 'lg:w-6/12',
]); ?>
<?php foreach (array_filter(([
    'closeButton' => false,
    'name' => null,
    'size' => 'lg:w-6/12',
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>

<div class="w-full md:w-auto"
     <?php echo e($attributes->except('class')); ?>

     x-data="{ isBulkApproveModalOpen: false }"
     x-init="
        $watch('isBulkApproveModalOpen', value => {
            if (value === true) {
                document.body.classList.add('overflow-hidden')
            } else {
                document.body.classList.remove('overflow-hidden')
            }
        });
    "
     x-on:keydown.escape.window="isBulkApproveModalOpen = false"
     x-on:isBulkApproveModalOpen.window="if ('<?php echo e($name); ?>' && $event.detail === '<?php echo e((string) Str::of($name)->replace('\\', '\\\\')); ?>') isBulkApproveModalOpen = true"
     x-on:close.window="if ('<?php echo e($name); ?>' && $event.detail === '<?php echo e((string) Str::of($name)->replace('\\', '\\\\')); ?>') isBulkApproveModalOpen = false"
     x-cloak
>
    <?php echo e($trigger ?? null); ?>


    <div
        x-show="isBulkApproveModalOpen"
        x-bind:aria-hidden="! isBulkApproveModalOpen"
        class="fixed inset-0 z-40 overflow-y-auto"
    >
        <div class="flex items-center justify-center min-h-screen px-4 pt-4 pb-20 text-center cursor-default sm:block sm:p-0">
            <div
                x-show="isBulkApproveModalOpen"
                x-transition:enter="ease-out duration-300"
                x-transition:enter-start="opacity-0"
                x-transition:enter-end="opacity-100"
                x-transition:leave="ease-in duration-200"
                x-transition:leave-start="opacity-100"
                x-transition:leave-end="opacity-0"
                aria-hidden="true"
                class="fixed inset-0 transition-opacity"
            >
                <div class="absolute inset-0 bg-gray-500 opacity-75"></div>
            </div>

            <span class="hidden sm:inline-block sm:align-middle sm:h-screen" aria-hidden="true">​</span>

            <div
                x-show="isBulkApproveModalOpen"
                x-transition:enter="ease-out duration-300"
                x-transition:enter-start="opacity-0 translate-y-4 sm:translate-y-0 sm:scale-95"
                x-transition:enter-end="opacity-100 translate-y-0 sm:scale-100"
                x-transition:leave="ease-in duration-200"
                x-transition:leave-start="opacity-100 translate-y-0 sm:scale-100"
                x-transition:leave-end="opacity-0 translate-y-4 sm:translate-y-0 sm:scale-95"
                role="dialog"
                aria-modal="true"
                x-on:click.away="isBulkApproveModalOpen = false"
                <?php echo e($attributes->only('class')->merge(['class' => 'modal-window inline-block text-left align-bottom transition-all transform sm:my-8 sm:align-middle w-11/12 md:w-6/12 '.$size])); ?>

            >
                <div
                    class="flex flex-col space-y-4"
                >
                    <?php if($closeButton): ?>
                        <button
                            type="button"
                            x-on:click="isBulkApproveModalOpen = false"
                            class="flex self-center shrink-0 text-gray-900 transition-colors duration-200 hover:text-white"
                        >
                            <?php if (isset($component)) { $__componentOriginal643fe1b47aec0b76658e1a0200b34b2c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c = $attributes; } ?>
<?php $component = BladeUI\Icons\Components\Svg::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('heroicon-o-x-mark'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(BladeUI\Icons\Components\Svg::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'w-6 h-6']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c)): ?>
<?php $attributes = $__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c; ?>
<?php unset($__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal643fe1b47aec0b76658e1a0200b34b2c)): ?>
<?php $component = $__componentOriginal643fe1b47aec0b76658e1a0200b34b2c; ?>
<?php unset($__componentOriginal643fe1b47aec0b76658e1a0200b34b2c); ?>
<?php endif; ?>
                        </button>
                    <?php endif; ?>

                    <div  class="grow bg-white p-4 md:p-6 rounded-3xl shadow-md">
                        <?php echo e($slot); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php /**PATH /home/vagrant/projects/eco-calc/resources/views/components/modal-bulk-approve.blade.php ENDPATH**/ ?>