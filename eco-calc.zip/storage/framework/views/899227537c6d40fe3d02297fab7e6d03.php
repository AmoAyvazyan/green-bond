<div>
    <!--[if BLOCK]><![endif]--><?php if($isImported): ?>
        <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded relative flex flex-col space-y-6 items-center justify-center" role="alert">
            <strong class="font-bold">Հաջողվեց!</strong>
            <span class="text-base"><?php echo e($message); ?></span>
        </div>
    <?php else: ?>
        <form wire:submit.prevent="submit" class="space-y-7 mt-10 text-base">
            <div class="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
                <div class="flex flex-col">
                    <label for="refinance_file" class="mb-2 font-bold text-lg text-gray-900">Refinance File:</label>
                    <?php if (isset($component)) { $__componentOriginale632e4e6446a156ddec0f062c71453c0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale632e4e6446a156ddec0f062c71453c0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-file','data' => ['class' => '!bg-gray-50','id' => 'refinance_file','wire:model' => 'refinance_file','value' => 'Browse','placeholder' => 'Excel file (xls,xlsx)']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('input-file'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => '!bg-gray-50','id' => 'refinance_file','wire:model' => 'refinance_file','value' => 'Browse','placeholder' => 'Excel file (xls,xlsx)']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale632e4e6446a156ddec0f062c71453c0)): ?>
<?php $attributes = $__attributesOriginale632e4e6446a156ddec0f062c71453c0; ?>
<?php unset($__attributesOriginale632e4e6446a156ddec0f062c71453c0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale632e4e6446a156ddec0f062c71453c0)): ?>
<?php $component = $__componentOriginale632e4e6446a156ddec0f062c71453c0; ?>
<?php unset($__componentOriginale632e4e6446a156ddec0f062c71453c0); ?>
<?php endif; ?>
                    <!--[if BLOCK]><![endif]--><?php if($errors->has('refinance_file')): ?>
                        <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $errors->get('refinance_file'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <span class="text-red-500 text-sm"><?php echo e($error); ?></span><br>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> <!--[if ENDBLOCK]><![endif]-->
                    <?php endif; ?> <!--[if ENDBLOCK]><![endif]-->
                </div>
                <div class="flex flex-col">
                    <label for="reject_file" class="mb-2 font-bold text-lg text-gray-900">Reject File:</label>
                    <?php if (isset($component)) { $__componentOriginale632e4e6446a156ddec0f062c71453c0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale632e4e6446a156ddec0f062c71453c0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-file','data' => ['class' => '!bg-gray-50','id' => 'reject_file','wire:model' => 'reject_file','value' => 'Browse','placeholder' => 'Excel file (xls,xlsx)']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('input-file'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => '!bg-gray-50','id' => 'reject_file','wire:model' => 'reject_file','value' => 'Browse','placeholder' => 'Excel file (xls,xlsx)']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale632e4e6446a156ddec0f062c71453c0)): ?>
<?php $attributes = $__attributesOriginale632e4e6446a156ddec0f062c71453c0; ?>
<?php unset($__attributesOriginale632e4e6446a156ddec0f062c71453c0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale632e4e6446a156ddec0f062c71453c0)): ?>
<?php $component = $__componentOriginale632e4e6446a156ddec0f062c71453c0; ?>
<?php unset($__componentOriginale632e4e6446a156ddec0f062c71453c0); ?>
<?php endif; ?>
                    <!--[if BLOCK]><![endif]--><?php if($errors->has('reject_file')): ?>
                        <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $errors->get('reject_file'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <span class="text-red-500 text-sm"><?php echo e($error); ?></span><br>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> <!--[if ENDBLOCK]><![endif]-->
                    <?php endif; ?> <!--[if ENDBLOCK]><![endif]-->
                </div>
                <div class="col-span-full">
                    <?php if (isset($component)) { $__componentOriginal74b62b190a03153f11871f645315f4de = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal74b62b190a03153f11871f645315f4de = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.checkbox','data' => ['checked' => true,'id' => 'need_validation','wire:model' => 'need_validation','value' => '1']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('checkbox'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['checked' => true,'id' => 'need_validation','wire:model' => 'need_validation','value' => '1']); ?>Need Validation
                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal74b62b190a03153f11871f645315f4de)): ?>
<?php $attributes = $__attributesOriginal74b62b190a03153f11871f645315f4de; ?>
<?php unset($__attributesOriginal74b62b190a03153f11871f645315f4de); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal74b62b190a03153f11871f645315f4de)): ?>
<?php $component = $__componentOriginal74b62b190a03153f11871f645315f4de; ?>
<?php unset($__componentOriginal74b62b190a03153f11871f645315f4de); ?>
<?php endif; ?>
                </div>
            </div>
            <div class="flex justify-center">
                <?php if (isset($component)) { $__componentOriginale24d542b14cdce1c7553e932742a57bc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale24d542b14cdce1c7553e932742a57bc = $attributes; } ?>
<?php $component = App\View\Components\Btn::resolve(['color' => 'green'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('btn'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Btn::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'px-4 py-2 bg-green-500 text-white rounded-lg hover:bg-green-600']); ?>Submit
                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale24d542b14cdce1c7553e932742a57bc)): ?>
<?php $attributes = $__attributesOriginale24d542b14cdce1c7553e932742a57bc; ?>
<?php unset($__attributesOriginale24d542b14cdce1c7553e932742a57bc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale24d542b14cdce1c7553e932742a57bc)): ?>
<?php $component = $__componentOriginale24d542b14cdce1c7553e932742a57bc; ?>
<?php unset($__componentOriginale24d542b14cdce1c7553e932742a57bc); ?>
<?php endif; ?>
            </div>
        </form>
    <?php endif; ?> <!--[if ENDBLOCK]><![endif]-->
</div><?php /**PATH /home/vagrant/projects/eco-calc/resources/views/livewire/bulk-update.blade.php ENDPATH**/ ?>