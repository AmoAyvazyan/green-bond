<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps(['align' => 'right', 'width' => '48', 'contentClasses' => 'py-0 bg-white']) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps(['align' => 'right', 'width' => '48', 'contentClasses' => 'py-0 bg-white']); ?>
<?php foreach (array_filter((['align' => 'right', 'width' => '48', 'contentClasses' => 'py-0 bg-white']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>

<?php
    $alignmentClasses = match ($align) {
        'left'  => 'origin-top-left left-0',
        'top'   => 'origin-top',
        default => 'origin-top-right right-0'
    };
    $width = match ($width) {
        'full'  => 'w-full',
        default => 'w-48',
    };
?>

<div class="relative" x-data="{ isDropdownMobileOpen: false }" @click.away="isDropdownMobileOpen = false"
     @close.stop="isDropdownMobileOpen = false">
    <div @click="isDropdownMobileOpen = ! isDropdownMobileOpen">
        <?php echo e($trigger); ?>

    </div>

    <div x-show="isDropdownMobileOpen" x-cloak
         x-transition:enter="transition ease-out duration-300 transform"
         x-transition:enter-start="opacity-0 scale-95 translate-x-full"
         x-transition:enter-end="opacity-100 scale-100 translate-x-0"
         x-transition:leave="transition ease-out duration-300 transform"
         x-transition:leave-start="opacity-100 scale-100 translate-x-0"
         x-transition:leave-end="opacity-100 scale-100 translate-x-full"
         class="fixed z-[-1] -mt-20 <?php echo e($width); ?> rounded-lg <?php echo e($alignmentClasses); ?>"
         >
        <div
            class="relative shadow-xl <?php echo e($contentClasses); ?> h-full bg-black flex flex-col items-center pt-44 pb-20">
            <?php echo e($content); ?>

        </div>
    </div>
</div><?php /**PATH /home/vagrant/projects/eco-calc/resources/views/components/dropdown-mobile-menu.blade.php ENDPATH**/ ?>