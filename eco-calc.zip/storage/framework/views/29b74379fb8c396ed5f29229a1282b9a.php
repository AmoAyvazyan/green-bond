<?php $__env->startSection('title', 'Mortgage Loan Request Details'); ?>
<?php $__env->startSection('button-class','flex justify-between items-center pb-1'); ?>
<?php $__env->startSection('button'); ?>
    <?php if (isset($component)) { $__componentOriginale24d542b14cdce1c7553e932742a57bc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale24d542b14cdce1c7553e932742a57bc = $attributes; } ?>
<?php $component = App\View\Components\Btn::resolve(['link' => true,'color' => 'green'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('btn'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Btn::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => ''.e(route('back-office.mortgage-loans-request.edit', $mortgageLoanRequest)).'']); ?>Edit <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale24d542b14cdce1c7553e932742a57bc)): ?>
<?php $attributes = $__attributesOriginale24d542b14cdce1c7553e932742a57bc; ?>
<?php unset($__attributesOriginale24d542b14cdce1c7553e932742a57bc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale24d542b14cdce1c7553e932742a57bc)): ?>
<?php $component = $__componentOriginale24d542b14cdce1c7553e932742a57bc; ?>
<?php unset($__componentOriginale24d542b14cdce1c7553e932742a57bc); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php if (isset($component)) { $__componentOriginal91fdd17964e43374ae18c674f95cdaa3 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal91fdd17964e43374ae18c674f95cdaa3 = $attributes; } ?>
<?php $component = App\View\Components\AdminLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('admin-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AdminLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <?php if (isset($component)) { $__componentOriginal53747ceb358d30c0105769f8471417f6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal53747ceb358d30c0105769f8471417f6 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.card','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
        <?php if (isset($component)) { $__componentOriginal14eb9ac9ab1b9936321678816133c448 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal14eb9ac9ab1b9936321678816133c448 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.detail-row','data' => ['label' => 'Loaner']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('detail-row'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Loaner']); ?> <?php echo e($loaner->email); ?>  <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal14eb9ac9ab1b9936321678816133c448)): ?>
<?php $attributes = $__attributesOriginal14eb9ac9ab1b9936321678816133c448; ?>
<?php unset($__attributesOriginal14eb9ac9ab1b9936321678816133c448); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal14eb9ac9ab1b9936321678816133c448)): ?>
<?php $component = $__componentOriginal14eb9ac9ab1b9936321678816133c448; ?>
<?php unset($__componentOriginal14eb9ac9ab1b9936321678816133c448); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginal14eb9ac9ab1b9936321678816133c448 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal14eb9ac9ab1b9936321678816133c448 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.detail-row','data' => ['label' => 'Partner']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('detail-row'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Partner']); ?>
            <?php if (isset($component)) { $__componentOriginal90eee3f94ef0e1b15e49c277c8700e9b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal90eee3f94ef0e1b15e49c277c8700e9b = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.link','data' => ['href' => ''.e(route('back-office.partners.show', $partner)).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => ''.e(route('back-office.partners.show', $partner)).'']); ?>
                <?php echo e($partner->translate('hy') ? $partner->translate('hy')->name : ''); ?> |
                <?php echo e($partner->translate('en') ? $partner->translate('en')->name : ''); ?>

             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal90eee3f94ef0e1b15e49c277c8700e9b)): ?>
<?php $attributes = $__attributesOriginal90eee3f94ef0e1b15e49c277c8700e9b; ?>
<?php unset($__attributesOriginal90eee3f94ef0e1b15e49c277c8700e9b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal90eee3f94ef0e1b15e49c277c8700e9b)): ?>
<?php $component = $__componentOriginal90eee3f94ef0e1b15e49c277c8700e9b; ?>
<?php unset($__componentOriginal90eee3f94ef0e1b15e49c277c8700e9b); ?>
<?php endif; ?>
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal14eb9ac9ab1b9936321678816133c448)): ?>
<?php $attributes = $__attributesOriginal14eb9ac9ab1b9936321678816133c448; ?>
<?php unset($__attributesOriginal14eb9ac9ab1b9936321678816133c448); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal14eb9ac9ab1b9936321678816133c448)): ?>
<?php $component = $__componentOriginal14eb9ac9ab1b9936321678816133c448; ?>
<?php unset($__componentOriginal14eb9ac9ab1b9936321678816133c448); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginal14eb9ac9ab1b9936321678816133c448 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal14eb9ac9ab1b9936321678816133c448 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.detail-row','data' => ['label' => 'Region']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('detail-row'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Region']); ?>
            <?php if (isset($component)) { $__componentOriginal90eee3f94ef0e1b15e49c277c8700e9b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal90eee3f94ef0e1b15e49c277c8700e9b = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.link','data' => ['href' => ''.e(route('back-office.regions.show', $region)).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => ''.e(route('back-office.regions.show', $region)).'']); ?>
                <?php echo e($region->translate('hy') ? $region->translate('hy')->name : ''); ?> |
                <?php echo e($region->translate('en') ? $region->translate('en')->name : ''); ?>

             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal90eee3f94ef0e1b15e49c277c8700e9b)): ?>
<?php $attributes = $__attributesOriginal90eee3f94ef0e1b15e49c277c8700e9b; ?>
<?php unset($__attributesOriginal90eee3f94ef0e1b15e49c277c8700e9b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal90eee3f94ef0e1b15e49c277c8700e9b)): ?>
<?php $component = $__componentOriginal90eee3f94ef0e1b15e49c277c8700e9b; ?>
<?php unset($__componentOriginal90eee3f94ef0e1b15e49c277c8700e9b); ?>
<?php endif; ?>
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal14eb9ac9ab1b9936321678816133c448)): ?>
<?php $attributes = $__attributesOriginal14eb9ac9ab1b9936321678816133c448; ?>
<?php unset($__attributesOriginal14eb9ac9ab1b9936321678816133c448); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal14eb9ac9ab1b9936321678816133c448)): ?>
<?php $component = $__componentOriginal14eb9ac9ab1b9936321678816133c448; ?>
<?php unset($__componentOriginal14eb9ac9ab1b9936321678816133c448); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginal14eb9ac9ab1b9936321678816133c448 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal14eb9ac9ab1b9936321678816133c448 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.detail-row','data' => ['label' => 'Building']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('detail-row'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Building']); ?>
            <?php if (isset($component)) { $__componentOriginal90eee3f94ef0e1b15e49c277c8700e9b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal90eee3f94ef0e1b15e49c277c8700e9b = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.link','data' => ['href' => ''.e(route('back-office.buildings.show', $building)).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => ''.e(route('back-office.buildings.show', $building)).'']); ?>
                <?php echo e($building->translate('hy') ? $building->translate('hy')->title : ''); ?> |
                <?php echo e($building->translate('en') ? $building->translate('en')->title : ''); ?>

             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal90eee3f94ef0e1b15e49c277c8700e9b)): ?>
<?php $attributes = $__attributesOriginal90eee3f94ef0e1b15e49c277c8700e9b; ?>
<?php unset($__attributesOriginal90eee3f94ef0e1b15e49c277c8700e9b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal90eee3f94ef0e1b15e49c277c8700e9b)): ?>
<?php $component = $__componentOriginal90eee3f94ef0e1b15e49c277c8700e9b; ?>
<?php unset($__componentOriginal90eee3f94ef0e1b15e49c277c8700e9b); ?>
<?php endif; ?>
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal14eb9ac9ab1b9936321678816133c448)): ?>
<?php $attributes = $__attributesOriginal14eb9ac9ab1b9936321678816133c448; ?>
<?php unset($__attributesOriginal14eb9ac9ab1b9936321678816133c448); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal14eb9ac9ab1b9936321678816133c448)): ?>
<?php $component = $__componentOriginal14eb9ac9ab1b9936321678816133c448; ?>
<?php unset($__componentOriginal14eb9ac9ab1b9936321678816133c448); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginal14eb9ac9ab1b9936321678816133c448 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal14eb9ac9ab1b9936321678816133c448 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.detail-row','data' => ['label' => 'Address']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('detail-row'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Address']); ?> <?php echo e($mortgageLoanRequest->address); ?>  <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal14eb9ac9ab1b9936321678816133c448)): ?>
<?php $attributes = $__attributesOriginal14eb9ac9ab1b9936321678816133c448; ?>
<?php unset($__attributesOriginal14eb9ac9ab1b9936321678816133c448); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal14eb9ac9ab1b9936321678816133c448)): ?>
<?php $component = $__componentOriginal14eb9ac9ab1b9936321678816133c448; ?>
<?php unset($__componentOriginal14eb9ac9ab1b9936321678816133c448); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginal14eb9ac9ab1b9936321678816133c448 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal14eb9ac9ab1b9936321678816133c448 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.detail-row','data' => ['label' => 'Area']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('detail-row'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Area']); ?> <?php echo e($mortgageLoanRequest->area); ?>  <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal14eb9ac9ab1b9936321678816133c448)): ?>
<?php $attributes = $__attributesOriginal14eb9ac9ab1b9936321678816133c448; ?>
<?php unset($__attributesOriginal14eb9ac9ab1b9936321678816133c448); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal14eb9ac9ab1b9936321678816133c448)): ?>
<?php $component = $__componentOriginal14eb9ac9ab1b9936321678816133c448; ?>
<?php unset($__componentOriginal14eb9ac9ab1b9936321678816133c448); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginal14eb9ac9ab1b9936321678816133c448 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal14eb9ac9ab1b9936321678816133c448 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.detail-row','data' => ['label' => 'Amount']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('detail-row'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Amount']); ?> <?php echo e($mortgageLoanRequest->amount); ?>  <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal14eb9ac9ab1b9936321678816133c448)): ?>
<?php $attributes = $__attributesOriginal14eb9ac9ab1b9936321678816133c448; ?>
<?php unset($__attributesOriginal14eb9ac9ab1b9936321678816133c448); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal14eb9ac9ab1b9936321678816133c448)): ?>
<?php $component = $__componentOriginal14eb9ac9ab1b9936321678816133c448; ?>
<?php unset($__componentOriginal14eb9ac9ab1b9936321678816133c448); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginal14eb9ac9ab1b9936321678816133c448 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal14eb9ac9ab1b9936321678816133c448 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.detail-row','data' => ['label' => 'Property Type']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('detail-row'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Property Type']); ?> <?php echo e($mortgageLoanRequest->property_type); ?>  <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal14eb9ac9ab1b9936321678816133c448)): ?>
<?php $attributes = $__attributesOriginal14eb9ac9ab1b9936321678816133c448; ?>
<?php unset($__attributesOriginal14eb9ac9ab1b9936321678816133c448); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal14eb9ac9ab1b9936321678816133c448)): ?>
<?php $component = $__componentOriginal14eb9ac9ab1b9936321678816133c448; ?>
<?php unset($__componentOriginal14eb9ac9ab1b9936321678816133c448); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginal14eb9ac9ab1b9936321678816133c448 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal14eb9ac9ab1b9936321678816133c448 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.detail-row','data' => ['label' => 'Type']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('detail-row'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Type']); ?> <?php echo e($mortgageLoanRequest->type); ?>  <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal14eb9ac9ab1b9936321678816133c448)): ?>
<?php $attributes = $__attributesOriginal14eb9ac9ab1b9936321678816133c448; ?>
<?php unset($__attributesOriginal14eb9ac9ab1b9936321678816133c448); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal14eb9ac9ab1b9936321678816133c448)): ?>
<?php $component = $__componentOriginal14eb9ac9ab1b9936321678816133c448; ?>
<?php unset($__componentOriginal14eb9ac9ab1b9936321678816133c448); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginal14eb9ac9ab1b9936321678816133c448 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal14eb9ac9ab1b9936321678816133c448 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.detail-row','data' => ['label' => 'Status']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('detail-row'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Status']); ?> <?php echo e($mortgageLoanRequest->status); ?>  <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal14eb9ac9ab1b9936321678816133c448)): ?>
<?php $attributes = $__attributesOriginal14eb9ac9ab1b9936321678816133c448; ?>
<?php unset($__attributesOriginal14eb9ac9ab1b9936321678816133c448); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal14eb9ac9ab1b9936321678816133c448)): ?>
<?php $component = $__componentOriginal14eb9ac9ab1b9936321678816133c448; ?>
<?php unset($__componentOriginal14eb9ac9ab1b9936321678816133c448); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginal14eb9ac9ab1b9936321678816133c448 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal14eb9ac9ab1b9936321678816133c448 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.detail-row','data' => ['label' => 'File']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('detail-row'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'File']); ?>
            <?php if (isset($component)) { $__componentOriginal90eee3f94ef0e1b15e49c277c8700e9b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal90eee3f94ef0e1b15e49c277c8700e9b = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.link','data' => ['target' => '_blank','href' => ''.e($mortgageLoanRequest->file).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['target' => '_blank','href' => ''.e($mortgageLoanRequest->file).'']); ?> <?php echo e($mortgageLoanRequest->file); ?>  <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal90eee3f94ef0e1b15e49c277c8700e9b)): ?>
<?php $attributes = $__attributesOriginal90eee3f94ef0e1b15e49c277c8700e9b; ?>
<?php unset($__attributesOriginal90eee3f94ef0e1b15e49c277c8700e9b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal90eee3f94ef0e1b15e49c277c8700e9b)): ?>
<?php $component = $__componentOriginal90eee3f94ef0e1b15e49c277c8700e9b; ?>
<?php unset($__componentOriginal90eee3f94ef0e1b15e49c277c8700e9b); ?>
<?php endif; ?>
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal14eb9ac9ab1b9936321678816133c448)): ?>
<?php $attributes = $__attributesOriginal14eb9ac9ab1b9936321678816133c448; ?>
<?php unset($__attributesOriginal14eb9ac9ab1b9936321678816133c448); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal14eb9ac9ab1b9936321678816133c448)): ?>
<?php $component = $__componentOriginal14eb9ac9ab1b9936321678816133c448; ?>
<?php unset($__componentOriginal14eb9ac9ab1b9936321678816133c448); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginal14eb9ac9ab1b9936321678816133c448 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal14eb9ac9ab1b9936321678816133c448 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.detail-row','data' => ['label' => 'Estimated Finish At']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('detail-row'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Estimated Finish At']); ?>
            <?php echo e($mortgageLoanRequest->estimated_finish_at->timezone(config('app.timezone'))->format('d.m.Y H:i:s')); ?>

         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal14eb9ac9ab1b9936321678816133c448)): ?>
<?php $attributes = $__attributesOriginal14eb9ac9ab1b9936321678816133c448; ?>
<?php unset($__attributesOriginal14eb9ac9ab1b9936321678816133c448); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal14eb9ac9ab1b9936321678816133c448)): ?>
<?php $component = $__componentOriginal14eb9ac9ab1b9936321678816133c448; ?>
<?php unset($__componentOriginal14eb9ac9ab1b9936321678816133c448); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginal14eb9ac9ab1b9936321678816133c448 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal14eb9ac9ab1b9936321678816133c448 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.detail-row','data' => ['label' => 'Created']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('detail-row'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Created']); ?>
            <?php echo e($mortgageLoanRequest->created_at->timezone(config('app.timezone'))->format('d.m.Y H:i:s')); ?>

         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal14eb9ac9ab1b9936321678816133c448)): ?>
<?php $attributes = $__attributesOriginal14eb9ac9ab1b9936321678816133c448; ?>
<?php unset($__attributesOriginal14eb9ac9ab1b9936321678816133c448); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal14eb9ac9ab1b9936321678816133c448)): ?>
<?php $component = $__componentOriginal14eb9ac9ab1b9936321678816133c448; ?>
<?php unset($__componentOriginal14eb9ac9ab1b9936321678816133c448); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginal14eb9ac9ab1b9936321678816133c448 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal14eb9ac9ab1b9936321678816133c448 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.detail-row','data' => ['label' => 'Modified','last' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('detail-row'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'Modified','last' => true]); ?>
            <?php echo e($mortgageLoanRequest->updated_at->timezone(config('app.timezone'))->format('d.m.Y H:i:s')); ?>

         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal14eb9ac9ab1b9936321678816133c448)): ?>
<?php $attributes = $__attributesOriginal14eb9ac9ab1b9936321678816133c448; ?>
<?php unset($__attributesOriginal14eb9ac9ab1b9936321678816133c448); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal14eb9ac9ab1b9936321678816133c448)): ?>
<?php $component = $__componentOriginal14eb9ac9ab1b9936321678816133c448; ?>
<?php unset($__componentOriginal14eb9ac9ab1b9936321678816133c448); ?>
<?php endif; ?>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal53747ceb358d30c0105769f8471417f6)): ?>
<?php $attributes = $__attributesOriginal53747ceb358d30c0105769f8471417f6; ?>
<?php unset($__attributesOriginal53747ceb358d30c0105769f8471417f6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal53747ceb358d30c0105769f8471417f6)): ?>
<?php $component = $__componentOriginal53747ceb358d30c0105769f8471417f6; ?>
<?php unset($__componentOriginal53747ceb358d30c0105769f8471417f6); ?>
<?php endif; ?>
    <?php echo $__env->make('partials.show-actions', [
        'resource' => 'mortgage-loans-request',
        'permission' => 'delete-loan-requests',
        'editPermission' => 'edit-loan-requests',
        'model' => $mortgageLoanRequest,
    ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal91fdd17964e43374ae18c674f95cdaa3)): ?>
<?php $attributes = $__attributesOriginal91fdd17964e43374ae18c674f95cdaa3; ?>
<?php unset($__attributesOriginal91fdd17964e43374ae18c674f95cdaa3); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal91fdd17964e43374ae18c674f95cdaa3)): ?>
<?php $component = $__componentOriginal91fdd17964e43374ae18c674f95cdaa3; ?>
<?php unset($__componentOriginal91fdd17964e43374ae18c674f95cdaa3); ?>
<?php endif; ?><?php /**PATH /home/vagrant/projects/eco-calc/resources/views/admin/mortgage-loans-request/show.blade.php ENDPATH**/ ?>