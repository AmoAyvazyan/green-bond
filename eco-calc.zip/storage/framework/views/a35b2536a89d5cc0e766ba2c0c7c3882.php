<div class="rounded-3xl bg-white p-3 text-gray-500 shadow-md sticky top-[150px]">
    <div class="flex flex-col space-y-6 p-3 mb-3 text-gray-500">
        <p><strong><?php echo e($this->eeAmountPercent); ?>%</strong> <?php echo e(__('loan.ee_measures')); ?></p>
        <p><strong><?php echo e($this->totalAmount > 0 ? 100 - $this->eeAmountPercent : 0); ?>%</strong> <?php echo e(__('loan.non_ee_measures')); ?></p>
        <p><strong><?php echo e($this->householdAppliancesSumPercent); ?>%</strong> <?php echo e(__('loan.household_appliances')); ?></p>
        <p><?php echo e(__('phrases.co2_reduction')); ?><?php echo e(__('phrases.colon')); ?>

            <strong><?php echo e(round(array_sum(array_column(array_column($applied_ee_improvement_data, 'savings'),'co2')), 2)); ?></strong>
            <?php echo e(__('phrases.tons_year')); ?>

        </p>
        <p><?php echo e(__('phrases.energy_savings')); ?><?php echo e(__('phrases.colon')); ?>

            <strong><?php echo e(round(array_sum(array_column(array_column($applied_ee_improvement_data, 'savings'), 'energy')))); ?></strong>
            <?php echo e(__('phrases.kWh_year')); ?>

        </p>
    </div>
    <div class="border border-gray-200 rounded-t-2xl p-3 text-black">
        <p class="text-lg mb-1"><?php echo e(__('phrases.total_ee')); ?><?php echo e(__('phrases.colon')); ?></p>
        <p class="text-right text-green-500 text-4xl font-bold"><?php echo e(number_format($this->getTotalEeAmount(),0,'.', ' ')); ?> <?php echo e(__('phrases.amd')); ?></p>
    </div>
    <div class="border border-t-0 border-gray-200 rounded-b-2xl text-black p-3 mb-3">
        <p class="text-lg mb-1"><?php echo e(__('phrases.total_non_ee')); ?><?php echo e(__('phrases.colon')); ?></p>
        <p class="text-right text-4xl font-bold"><?php echo e(number_format($this->totalAmount - $this->getTotalEeAmount(),0,'.', ' ')); ?> <?php echo e(__('phrases.amd')); ?></p>
    </div>
    <div class="bg-black rounded-t-2xl p-3 text-white">
        <p class="text-lg mb-1"><?php echo e(__('phrases.total_calculation')); ?><?php echo e(__('phrases.colon')); ?></p>
        <p class="text-right text-4xl font-bold"><?php echo e(number_format($this->totalAmount,0,'.', ' ')); ?> <?php echo e(__('phrases.amd')); ?></p>
    </div>
    <!--[if BLOCK]><![endif]--><?php if($this->isLoanTypeGreen): ?>
        <div class="rounded-b-2xl text-white p-3 bg-green-500">
            <p><?php echo e(__('phrases.loan_type')); ?><?php echo e(__('phrases.colon')); ?>

                <?php echo e(__('phrases.loan_type_green')); ?>

            </p>
        </div>
    <?php elseif($this->isLoanTypeEe): ?>
        <div class="rounded-b-2xl text-black p-3 bg-green-400">
            <p><?php echo e(__('phrases.loan_type')); ?><?php echo e(__('phrases.colon')); ?>

                <?php echo e(__('phrases.loan_type_ee')); ?>

            </p>
        </div>
    <?php elseif($this->isLoanTypeStandard): ?>
        <div
            class="rounded-b-2xl text-white p-3 bg-yellow-500">
            <p><?php echo e(__('phrases.loan_type')); ?><?php echo e(__('phrases.colon')); ?>

                <?php echo e(__('phrases.loan_type_standard')); ?>

            </p>
        </div>
    <?php else: ?>
        <div
            class="rounded-b-2xl text-white p-3 bg-red-500">
            <p><?php echo e(__('phrases.loan_type')); ?><?php echo e(__('phrases.colon')); ?>

                <?php echo e(__('phrases.loan_type_nok')); ?>

            </p>
        </div>
    <?php endif; ?> <!--[if ENDBLOCK]><![endif]-->
</div><?php /**PATH /home/vagrant/projects/eco-calc/resources/views/livewire/partials/renovation-summary.blade.php ENDPATH**/ ?>