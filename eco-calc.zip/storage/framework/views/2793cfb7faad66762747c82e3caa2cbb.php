<div class="w-full h-full flex flex-col justify-between px-5">
    <div class="flex flex-col items-center justify-center">
        <div class="flex flex-col space-y-10 items-center">
            <?php if (isset($component)) { $__componentOriginald69b52d99510f1e7cd3d80070b28ca18 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald69b52d99510f1e7cd3d80070b28ca18 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.responsive-nav-link','data' => ['class' => 'text-white hover:text-white !text-2xl','href' => ''.e(route('front.calculators.mortgage')).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('responsive-nav-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'text-white hover:text-white !text-2xl','href' => ''.e(route('front.calculators.mortgage')).'']); ?><?php echo e(__('phrases.property_acquisition_title')); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald69b52d99510f1e7cd3d80070b28ca18)): ?>
<?php $attributes = $__attributesOriginald69b52d99510f1e7cd3d80070b28ca18; ?>
<?php unset($__attributesOriginald69b52d99510f1e7cd3d80070b28ca18); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald69b52d99510f1e7cd3d80070b28ca18)): ?>
<?php $component = $__componentOriginald69b52d99510f1e7cd3d80070b28ca18; ?>
<?php unset($__componentOriginald69b52d99510f1e7cd3d80070b28ca18); ?>
<?php endif; ?>
            <?php if (isset($component)) { $__componentOriginald69b52d99510f1e7cd3d80070b28ca18 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald69b52d99510f1e7cd3d80070b28ca18 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.responsive-nav-link','data' => ['class' => 'text-white hover:text-white !text-2xl','href' => ''.e(route('front.calculators.renovation')).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('responsive-nav-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'text-white hover:text-white !text-2xl','href' => ''.e(route('front.calculators.renovation')).'']); ?><?php echo e(__('phrases.repair_title')); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald69b52d99510f1e7cd3d80070b28ca18)): ?>
<?php $attributes = $__attributesOriginald69b52d99510f1e7cd3d80070b28ca18; ?>
<?php unset($__attributesOriginald69b52d99510f1e7cd3d80070b28ca18); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald69b52d99510f1e7cd3d80070b28ca18)): ?>
<?php $component = $__componentOriginald69b52d99510f1e7cd3d80070b28ca18; ?>
<?php unset($__componentOriginald69b52d99510f1e7cd3d80070b28ca18); ?>
<?php endif; ?>
            <?php if (isset($component)) { $__componentOriginald69b52d99510f1e7cd3d80070b28ca18 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald69b52d99510f1e7cd3d80070b28ca18 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.responsive-nav-link','data' => ['class' => 'text-white hover:text-white !text-2xl','href' => ''.e(route('front.calculators.construction')).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('responsive-nav-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'text-white hover:text-white !text-2xl','href' => ''.e(route('front.calculators.construction')).'']); ?><?php echo e(__('phrases.construction_residential_house_title')); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald69b52d99510f1e7cd3d80070b28ca18)): ?>
<?php $attributes = $__attributesOriginald69b52d99510f1e7cd3d80070b28ca18; ?>
<?php unset($__attributesOriginald69b52d99510f1e7cd3d80070b28ca18); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald69b52d99510f1e7cd3d80070b28ca18)): ?>
<?php $component = $__componentOriginald69b52d99510f1e7cd3d80070b28ca18; ?>
<?php unset($__componentOriginald69b52d99510f1e7cd3d80070b28ca18); ?>
<?php endif; ?>
        </div>
        <div class="flex items-center justify-between space-x-4 mb-40 mt-40">
            <?php if (! (request()->is('back-office/login'))): ?>
                <div class="lang-switcher lg:flex items-center border p-2 rounded-[48px]"
                     x-data="{locale:{hy:false}}"
                     x-init="locale['<?php echo e(app()->getLocale()); ?>'] = true"
                >
                    <?php $__currentLoopData = config('laravellocalization.supportedLocales'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $code => $locale): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <a class="capitalize text-white text-lg font-mono hover:bg-white transition duration-150 rounded-[36px] px-4 py-1 md:py-2 hover:text-black
                            <?php echo e($code === app()->getLocale() ? 'active' : ''); ?>"
                           hreflang="<?php echo e($code); ?>"
                           href="<?php echo e(LaravelLocalization::getLocalizedURL($code)); ?>"
                        ><?php echo e($locale['shortname']); ?></a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            <?php endif; ?>
        </div>
        <div class="col-span-5 md:col-auto h-full flex flex-col items-center md:items-start space-y-5 md:hidden">
            <div class="flex space-x-7">
                <?php if (isset($component)) { $__componentOriginalf3e2e88103a43e9e072739ac6625d63a = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf3e2e88103a43e9e072739ac6625d63a = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icon-link','data' => ['ariaLabel' => 'Official business page on LinkedIn','href' => '','rel' => 'nofollow','target' => '_blank']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('icon-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['aria-label' => 'Official business page on LinkedIn','href' => '','rel' => 'nofollow','target' => '_blank']); ?>
                    <?php if (isset($component)) { $__componentOriginalf887a8bd15c5a211b880c96f0e212bc5 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf887a8bd15c5a211b880c96f0e212bc5 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icons.linkedin','data' => ['class' => 'size-5']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('icons.linkedin'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'size-5']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf887a8bd15c5a211b880c96f0e212bc5)): ?>
<?php $attributes = $__attributesOriginalf887a8bd15c5a211b880c96f0e212bc5; ?>
<?php unset($__attributesOriginalf887a8bd15c5a211b880c96f0e212bc5); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf887a8bd15c5a211b880c96f0e212bc5)): ?>
<?php $component = $__componentOriginalf887a8bd15c5a211b880c96f0e212bc5; ?>
<?php unset($__componentOriginalf887a8bd15c5a211b880c96f0e212bc5); ?>
<?php endif; ?>
                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf3e2e88103a43e9e072739ac6625d63a)): ?>
<?php $attributes = $__attributesOriginalf3e2e88103a43e9e072739ac6625d63a; ?>
<?php unset($__attributesOriginalf3e2e88103a43e9e072739ac6625d63a); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf3e2e88103a43e9e072739ac6625d63a)): ?>
<?php $component = $__componentOriginalf3e2e88103a43e9e072739ac6625d63a; ?>
<?php unset($__componentOriginalf3e2e88103a43e9e072739ac6625d63a); ?>
<?php endif; ?>
                <?php if (isset($component)) { $__componentOriginalf3e2e88103a43e9e072739ac6625d63a = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf3e2e88103a43e9e072739ac6625d63a = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icon-link','data' => ['ariaLabel' => 'Official page on Facebook','href' => '','rel' => 'nofollow','target' => '_blank']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('icon-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['aria-label' => 'Official page on Facebook','href' => '','rel' => 'nofollow','target' => '_blank']); ?>
                    <?php if (isset($component)) { $__componentOriginalf48a60e2578bf31eaf6642e35766a26a = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf48a60e2578bf31eaf6642e35766a26a = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icons.fb','data' => ['class' => 'h-5']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('icons.fb'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'h-5']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf48a60e2578bf31eaf6642e35766a26a)): ?>
<?php $attributes = $__attributesOriginalf48a60e2578bf31eaf6642e35766a26a; ?>
<?php unset($__attributesOriginalf48a60e2578bf31eaf6642e35766a26a); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf48a60e2578bf31eaf6642e35766a26a)): ?>
<?php $component = $__componentOriginalf48a60e2578bf31eaf6642e35766a26a; ?>
<?php unset($__componentOriginalf48a60e2578bf31eaf6642e35766a26a); ?>
<?php endif; ?>
                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf3e2e88103a43e9e072739ac6625d63a)): ?>
<?php $attributes = $__attributesOriginalf3e2e88103a43e9e072739ac6625d63a; ?>
<?php unset($__attributesOriginalf3e2e88103a43e9e072739ac6625d63a); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf3e2e88103a43e9e072739ac6625d63a)): ?>
<?php $component = $__componentOriginalf3e2e88103a43e9e072739ac6625d63a; ?>
<?php unset($__componentOriginalf3e2e88103a43e9e072739ac6625d63a); ?>
<?php endif; ?>
            </div>
            <div class="flex items-center space-x-2">
                <?php if (isset($component)) { $__componentOriginal01373fe5e2aaee47705ab1cbef2eac77 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal01373fe5e2aaee47705ab1cbef2eac77 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icons.mail','data' => ['class' => 'w-3 h-auto text-white']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('icons.mail'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'w-3 h-auto text-white']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal01373fe5e2aaee47705ab1cbef2eac77)): ?>
<?php $attributes = $__attributesOriginal01373fe5e2aaee47705ab1cbef2eac77; ?>
<?php unset($__attributesOriginal01373fe5e2aaee47705ab1cbef2eac77); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal01373fe5e2aaee47705ab1cbef2eac77)): ?>
<?php $component = $__componentOriginal01373fe5e2aaee47705ab1cbef2eac77; ?>
<?php unset($__componentOriginal01373fe5e2aaee47705ab1cbef2eac77); ?>
<?php endif; ?>
                <?php if (isset($component)) { $__componentOriginal5ad705f2d2340be52309155e084c1436 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5ad705f2d2340be52309155e084c1436 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.link-light','data' => ['href' => 'mailto:'.e(settings('info_email')).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('link-light'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => 'mailto:'.e(settings('info_email')).'']); ?><?php echo e(settings('info_email')); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5ad705f2d2340be52309155e084c1436)): ?>
<?php $attributes = $__attributesOriginal5ad705f2d2340be52309155e084c1436; ?>
<?php unset($__attributesOriginal5ad705f2d2340be52309155e084c1436); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5ad705f2d2340be52309155e084c1436)): ?>
<?php $component = $__componentOriginal5ad705f2d2340be52309155e084c1436; ?>
<?php unset($__componentOriginal5ad705f2d2340be52309155e084c1436); ?>
<?php endif; ?>
            </div>
            <div class="flex items-center space-x-2">
                <?php if (isset($component)) { $__componentOriginalda6a6e700391614c5210d6249f833787 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalda6a6e700391614c5210d6249f833787 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icons.phone','data' => ['class' => 'w-3 h-auto text-white']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('icons.phone'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'w-3 h-auto text-white']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalda6a6e700391614c5210d6249f833787)): ?>
<?php $attributes = $__attributesOriginalda6a6e700391614c5210d6249f833787; ?>
<?php unset($__attributesOriginalda6a6e700391614c5210d6249f833787); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalda6a6e700391614c5210d6249f833787)): ?>
<?php $component = $__componentOriginalda6a6e700391614c5210d6249f833787; ?>
<?php unset($__componentOriginalda6a6e700391614c5210d6249f833787); ?>
<?php endif; ?>
                <?php if (isset($component)) { $__componentOriginal5ad705f2d2340be52309155e084c1436 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5ad705f2d2340be52309155e084c1436 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.link-light','data' => ['href' => 'tel:'.e(settings('info_phone')).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('link-light'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => 'tel:'.e(settings('info_phone')).'']); ?><?php echo e(settings('info_phone')); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5ad705f2d2340be52309155e084c1436)): ?>
<?php $attributes = $__attributesOriginal5ad705f2d2340be52309155e084c1436; ?>
<?php unset($__attributesOriginal5ad705f2d2340be52309155e084c1436); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5ad705f2d2340be52309155e084c1436)): ?>
<?php $component = $__componentOriginal5ad705f2d2340be52309155e084c1436; ?>
<?php unset($__componentOriginal5ad705f2d2340be52309155e084c1436); ?>
<?php endif; ?>
            </div>
        </div>
    </div>
</div>
<?php /**PATH /home/vagrant/projects/eco-calc/resources/views/partials/menu-items.blade.php ENDPATH**/ ?>