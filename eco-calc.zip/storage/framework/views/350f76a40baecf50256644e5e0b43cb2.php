<div <?php echo $attributes->merge(['class'=>'container px-4 lg:px-8 hd:px-16 fhd:px-24 mx-auto']); ?>>
    <?php echo e($slot); ?>

</div>
<?php /**PATH /home/vagrant/projects/eco-calc/resources/views/components/container.blade.php ENDPATH**/ ?>