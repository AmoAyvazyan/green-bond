<section id="partners" class="splide partner-slider pb-24" aria-label="Partners" data-splide='<?php echo json_encode($options, 15, 512) ?>'>
    <div class="splide__track">
        <ul class="splide__list">
            <?php $__currentLoopData = $partners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $partner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li class="splide__slide">
                    <div>
                        <?php if($partner->url): ?>
                            <a target="_blank" class="cursor-pointer block" rel="nofollow" href="<?php echo e($partner->url); ?>">
                                <img data-src="<?php echo e($partner->logo); ?>"
                                     alt="<?php echo e($partner->name); ?>"
                                     class="lazyload rounded h-[40px] mx-9">
                            </a>
                        <?php else: ?>
                            <div>
                                <img data-src="<?php echo e($partner->logo); ?>"
                                     alt="<?php echo e($partner->name); ?>"
                                     class="lazyload rounded h-[40px] mx-9">
                            </div>
                        <?php endif; ?>
                    </div>
                </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
    <ul class="splide__pagination mt-6"></ul>
</section>
<?php if (isset($component)) { $__componentOriginal63b3d2e59e3a82396557541d7152da5e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal63b3d2e59e3a82396557541d7152da5e = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.slider-assets','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('slider-assets'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal63b3d2e59e3a82396557541d7152da5e)): ?>
<?php $attributes = $__attributesOriginal63b3d2e59e3a82396557541d7152da5e; ?>
<?php unset($__attributesOriginal63b3d2e59e3a82396557541d7152da5e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal63b3d2e59e3a82396557541d7152da5e)): ?>
<?php $component = $__componentOriginal63b3d2e59e3a82396557541d7152da5e; ?>
<?php unset($__componentOriginal63b3d2e59e3a82396557541d7152da5e); ?>
<?php endif; ?><?php /**PATH /home/vagrant/projects/eco-calc/resources/views/components/partners-slider.blade.php ENDPATH**/ ?>