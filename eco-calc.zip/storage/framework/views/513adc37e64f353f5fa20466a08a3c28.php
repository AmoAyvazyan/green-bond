<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps([
    'type' => 'warning',
]) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps([
    'type' => 'warning',
]); ?>
<?php foreach (array_filter(([
    'type' => 'warning',
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>
<?php ($bgColor = match($type) {
    'warning' => 'bg-yellow-500',
    'error' => 'bg-red-500',
    'success' => 'bg-green-500',
    default => 'bg-black',
}); ?>
<?php ($borderColor = match($type) {
    'warning' => 'border-yellow-500',
    'error' => 'border-red-500',
    'success' => 'border-green-500',
    default => 'border-black',
}); ?>

<div <?php echo $attributes; ?>>
    <div class="w-full rounded-2xl flex border <?php echo e($borderColor); ?> notice shadow-md">
        <div class="<?php echo e($bgColor); ?> rounded-l-2xl flex items-center justify-center min-w-8">
            <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M8.51485 15.9794C6.40758 16.1243 4.53229 15.5042 2.92589 14.1764C1.22754 12.7719 0.242519 10.941 0.0377135 8.72981C-0.169182 6.49002 0.477279 4.49754 1.92555 2.79209C3.28743 1.18696 5.0436 0.258995 7.14321 0.0472068C9.48872 -0.189661 11.5814 0.463816 13.3438 2.03132C14.8764 3.39471 15.7631 5.12663 15.9582 7.17763C16.1721 9.42509 15.5674 11.4406 14.0968 13.1655C12.6339 14.8807 10.758 15.8017 8.51554 15.9801L8.51485 15.9794ZM14.3943 7.99831C14.3636 6.09291 13.6691 4.47037 12.2383 3.208C10.8102 1.94772 9.11394 1.4503 7.22192 1.65443C5.85447 1.80212 4.6521 2.35876 3.6636 3.30205C2.14289 4.75252 1.44349 6.54714 1.64899 8.65248C1.94505 11.6809 4.46193 14.2851 7.77922 14.3847C11.5075 14.4968 14.4173 11.5026 14.3943 7.99831Z" fill="white"/>
                <path d="M7.22337 7.19286H8.79424C8.84092 7.24999 8.82071 7.31478 8.82071 7.37469C8.82211 8.84745 8.81863 10.3202 8.82559 11.793C8.82629 11.9602 8.78031 12.0027 8.61661 11.9985C8.15614 11.9867 7.69498 11.9943 7.22407 11.9943V7.19356L7.22337 7.19286Z" fill="white"/>
                <path d="M7.22059 5.57868V3.99236H8.80539V5.57868H7.22059Z" fill="white"/>
            </svg>
        </div>
        <div class="text-sm sm:text-base p-2 sm:p-4 bg-white text-gray-500 rounded-r-2xl flex-1">
            <?php echo e($slot); ?>

        </div>
    </div>
</div>
<?php /**PATH /home/vagrant/projects/eco-calc/resources/views/components/notice.blade.php ENDPATH**/ ?>