<div <?php echo $attributes->only('class'); ?>>
    <label for="phone_base_<?php echo $attributes['id']; ?>" class="hidden"><?php echo e(__('terms.phone_number')); ?></label>
    <span wire:ignore>
        <input id="phone_base_<?php echo $attributes['id']; ?>" type="tel" name="phone_base"
               <?php echo $attributes->only(['placeholder','required']); ?>

               data-target="<?php echo $attributes['id']; ?>" autocomplete="off"
               <?php echo $attributes->merge(['class'=>'block mt-1 w-full rounded-xl px-3 py-3 h-12 border-gray-500
                                                 focus:border-gray-500 placeholder:text-gray-50 bg-white
                                                 focus-visible:outline-none focus:ring focus:ring-gray-200
                                                 focus:ring-opacity-50 disabled:cursor-not-allowed disabled:opacity-75'])
                                                 ->only('class'); ?>

               <?php if($attributes->has('value')): ?>
                   value="<?php echo e($attributes['value'] ?? old($attributes['name'])); ?>"
               <?php endif; ?>
        >
    </span>
    <input type="hidden" <?php echo $attributes->except(['class','placeholder','required']); ?>>
</div><?php /**PATH /home/vagrant/projects/eco-calc/resources/views/components/input-phone.blade.php ENDPATH**/ ?>