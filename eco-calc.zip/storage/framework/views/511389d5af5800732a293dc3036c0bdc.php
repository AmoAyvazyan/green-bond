<?php if($active ?? false): ?>
    <a <?php echo e($attributes->merge(['class' => 'block px-6 py-4 text-sm text-gray-900 font-semibold bg-green-500 cursor-default'])); ?>><?php echo e($slot); ?></a>
<?php else: ?>
    <a <?php echo e($attributes->merge(['class' => 'block px-6 py-4 text-sm text-gray-900 font-semibold hover:bg-green-50 focus:outline-none focus:bg-gray-50 transition duration-200 ease-in-out'])); ?>><?php echo e($slot); ?></a>
<?php endif; ?>
<?php /**PATH /home/vagrant/projects/eco-calc/resources/views/components/dropdown-link.blade.php ENDPATH**/ ?>