<div class="rounded-3xl bg-white p-3 text-gray-500 shadow-md sticky top-[150px]">
    <div class="flex flex-col space-y-6 text-gray-500 mb-6">
        <div class="border border-green-500 rounded-2xl flex flex-col space-y-6 p-3">
            <h2 class="text-green-500 text-center text-xs font-medium bg-white -mt-5 px-1 w-[max-content] self-center"><?php echo e(__('phrases.events')); ?></h2>
            <div class="flex space-x-2">
                <span><?php echo e(__('phrases.walls_insulation_thickness')); ?><?php echo e(__('phrases.colon')); ?></span>
                <?php if(($applied_ee_improvement_data[$wallInsulationId]['thickness'] ?? 0) >= 5): ?>
                    <span class="text-green-500 font-bold h-6 w-auto"><?php if (isset($component)) { $__componentOriginal643fe1b47aec0b76658e1a0200b34b2c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c = $attributes; } ?>
<?php $component = BladeUI\Icons\Components\Svg::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('heroicon-o-check'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(BladeUI\Icons\Components\Svg::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'h-6 w-auto']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c)): ?>
<?php $attributes = $__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c; ?>
<?php unset($__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal643fe1b47aec0b76658e1a0200b34b2c)): ?>
<?php $component = $__componentOriginal643fe1b47aec0b76658e1a0200b34b2c; ?>
<?php unset($__componentOriginal643fe1b47aec0b76658e1a0200b34b2c); ?>
<?php endif; ?></span>
                <?php else: ?>
                    <span class="text-red-500 font-bold">&#60; 5</span>
                <?php endif; ?> <!--[if ENDBLOCK]><![endif]-->
            </div>
            <div class="flex space-x-2">
                <span><?php echo e(__('phrases.roof_insulation_thickness')); ?><?php echo e(__('phrases.colon')); ?></span>
                <?php if(($applied_ee_improvement_data[$roofInsulationId]['thickness'] ?? 0) >= 15): ?>
                    <span class="text-green-500 font-bold h-6 w-auto"><?php if (isset($component)) { $__componentOriginal643fe1b47aec0b76658e1a0200b34b2c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c = $attributes; } ?>
<?php $component = BladeUI\Icons\Components\Svg::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('heroicon-o-check'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(BladeUI\Icons\Components\Svg::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'h-6 w-auto']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c)): ?>
<?php $attributes = $__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c; ?>
<?php unset($__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal643fe1b47aec0b76658e1a0200b34b2c)): ?>
<?php $component = $__componentOriginal643fe1b47aec0b76658e1a0200b34b2c; ?>
<?php unset($__componentOriginal643fe1b47aec0b76658e1a0200b34b2c); ?>
<?php endif; ?></span>
                <?php else: ?>
                    <span class="text-red-500 font-bold h-6 w-auto">&#60; 15</span>
                <?php endif; ?> <!--[if ENDBLOCK]><![endif]-->
            </div>
            <div class="flex space-x-2">
                <span><?php echo e(__('phrases.windows_installation')); ?><?php echo e(__('phrases.colon')); ?></span>
                <?php if(($applied_ee_improvement_data[$windowsInstallId]['area'] ?? 0) > 0): ?>
                    <span class="text-green-500 font-bold h-6 w-auto"><?php if (isset($component)) { $__componentOriginal643fe1b47aec0b76658e1a0200b34b2c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c = $attributes; } ?>
<?php $component = BladeUI\Icons\Components\Svg::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('heroicon-o-check'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(BladeUI\Icons\Components\Svg::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'h-6 w-auto']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c)): ?>
<?php $attributes = $__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c; ?>
<?php unset($__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal643fe1b47aec0b76658e1a0200b34b2c)): ?>
<?php $component = $__componentOriginal643fe1b47aec0b76658e1a0200b34b2c; ?>
<?php unset($__componentOriginal643fe1b47aec0b76658e1a0200b34b2c); ?>
<?php endif; ?></span>
                <?php else: ?>
                    <span class="text-red-500 font-bold h-6 w-auto"><?php if (isset($component)) { $__componentOriginal643fe1b47aec0b76658e1a0200b34b2c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c = $attributes; } ?>
<?php $component = BladeUI\Icons\Components\Svg::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('heroicon-o-x-mark'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(BladeUI\Icons\Components\Svg::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'h-6 w-auto']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c)): ?>
<?php $attributes = $__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c; ?>
<?php unset($__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal643fe1b47aec0b76658e1a0200b34b2c)): ?>
<?php $component = $__componentOriginal643fe1b47aec0b76658e1a0200b34b2c; ?>
<?php unset($__componentOriginal643fe1b47aec0b76658e1a0200b34b2c); ?>
<?php endif; ?></span>
                <?php endif; ?> <!--[if ENDBLOCK]><![endif]-->
            </div>
            <div class="flex space-x-2">
                <span><?php echo e(__('phrases.door_installation')); ?><?php echo e(__('phrases.colon')); ?></span>
                <?php if(($applied_ee_improvement_data[$doorInstallId]['area'] ?? 0) > 0): ?>
                    <span class="text-green-500 font-bold h-6 w-auto"><?php if (isset($component)) { $__componentOriginal643fe1b47aec0b76658e1a0200b34b2c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c = $attributes; } ?>
<?php $component = BladeUI\Icons\Components\Svg::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('heroicon-o-check'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(BladeUI\Icons\Components\Svg::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'h-6 w-auto']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c)): ?>
<?php $attributes = $__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c; ?>
<?php unset($__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal643fe1b47aec0b76658e1a0200b34b2c)): ?>
<?php $component = $__componentOriginal643fe1b47aec0b76658e1a0200b34b2c; ?>
<?php unset($__componentOriginal643fe1b47aec0b76658e1a0200b34b2c); ?>
<?php endif; ?></span>
                <?php else: ?>
                    <span class="text-red-500 font-bold h-6 w-auto"><?php if (isset($component)) { $__componentOriginal643fe1b47aec0b76658e1a0200b34b2c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c = $attributes; } ?>
<?php $component = BladeUI\Icons\Components\Svg::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('heroicon-o-x-mark'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(BladeUI\Icons\Components\Svg::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'h-6 w-auto']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c)): ?>
<?php $attributes = $__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c; ?>
<?php unset($__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal643fe1b47aec0b76658e1a0200b34b2c)): ?>
<?php $component = $__componentOriginal643fe1b47aec0b76658e1a0200b34b2c; ?>
<?php unset($__componentOriginal643fe1b47aec0b76658e1a0200b34b2c); ?>
<?php endif; ?></span>
                <?php endif; ?> <!--[if ENDBLOCK]><![endif]-->
            </div>
        </div>
        <p class="px-3"><?php echo e(__('phrases.co2_reduction')); ?>

            <strong><?php echo e(round(array_sum(array_column(array_column($applied_ee_improvement_data, 'savings'),'co2')), 2)); ?></strong>
            <?php echo e(__('phrases.tons_year')); ?>

        </p>
        <p class="px-3"><?php echo e(__('phrases.energy_savings')); ?>

            <strong><?php echo e(round(array_sum(array_column(array_column($applied_ee_improvement_data, 'savings'), 'energy')))); ?></strong>
            <?php echo e(__('phrases.kWh_year')); ?>

        </p>
    </div>
    <div class="bg-black rounded-t-2xl p-3 text-white">
        <p class="text-lg mb-1"><?php echo e(__('phrases.total_calculation')); ?><?php echo e(__('phrases.colon')); ?></p>
        <p class="text-right text-4xl font-bold"><?php echo e(number_format($this->totalAmount,0,'.', ' ')); ?> <?php echo e(__('phrases.amd')); ?></p>
    </div>
    <!--[if BLOCK]><![endif]--><?php if($this->isLoanTypeGreen): ?>
        <div class="rounded-b-2xl text-white p-3 bg-green-500">
            <p><?php echo e(__('phrases.loan_type')); ?><?php echo e(__('phrases.colon')); ?>

                <?php echo e(__('phrases.loan_type_green')); ?>

            </p>
        </div>
    <?php elseif($this->isLoanTypeStandard): ?>
        <div
            class="rounded-b-2xl text-yellow-500 p-3 border-yellow-500">
            <p><?php echo e(__('phrases.loan_type')); ?><?php echo e(__('phrases.colon')); ?>

                <?php echo e(__('phrases.loan_type_standard')); ?>

            </p>
        </div>
    <?php elseif($this->isLoanTypeNonStandard): ?>
        <div
            class="rounded-b-2xl text-white p-3 bg-yellow-500">
            <p><?php echo e(__('phrases.loan_type')); ?><?php echo e(__('phrases.colon')); ?>

                <?php echo e(__('phrases.loan_type_non_standard')); ?>

            </p>
        </div>
    <?php else: ?>
        <div
            class="rounded-b-2xl text-white p-3 bg-red-500">
            <p><?php echo e(__('phrases.loan_type')); ?><?php echo e(__('phrases.colon')); ?>

                <?php echo e(__('phrases.loan_type_nok')); ?>

            </p>
        </div>
    <?php endif; ?> <!--[if ENDBLOCK]><![endif]-->
</div><?php /**PATH /home/vagrant/projects/eco-calc/resources/views/livewire/partials/construction-summary.blade.php ENDPATH**/ ?>