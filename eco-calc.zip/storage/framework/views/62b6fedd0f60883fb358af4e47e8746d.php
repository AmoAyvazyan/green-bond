<?php if (isset($component)) { $__componentOriginalea110a4dc9a05234d27a64f8ec54bbc6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalea110a4dc9a05234d27a64f8ec54bbc6 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.modal-dynamic','data' => ['name' => 'Video','closeButton' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('modal-dynamic'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'Video','close-button' => true]); ?>
    <h2 class="text-xl sm:text-3xl text-black absolute top-6 font-semibold"> <?php echo e(__('phrases.our_videos')); ?> </h2>
    <div class="grid grid-cols-1 md:grid-cols-2 gap-y-12 gap-x-5 mt-12"
         x-data="{
                frameHy1 : 'https://www.youtube.com/embed/N82AqYxRQnE?autoplay=1',
                frameHy2 : 'https://www.youtube.com/embed/n12D4ZrQTDQ?autoplay=1',
                frameHy3 : 'https://www.youtube.com/embed/T3zbViAe3wQ?autoplay=1',
                frameEn1 : 'https://www.youtube.com/embed/LYTFSd_eIuA?autoplay=1',
                frameEn2 : 'https://www.youtube.com/embed/1re3syKVTKQ?autoplay=1',
                frameEn3 : 'https://www.youtube.com/embed/yVWBM5mMcUk?autoplay=1',
                videoUrl: 'https://www.youtube.com/embed/N82AqYxRQnE?autoplay=1',
                videoTitles: {
                    'https://www.youtube.com/embed/N82AqYxRQnE?autoplay=1': '<?php echo e(__('phrases.video_name_1')); ?>',
                    'https://www.youtube.com/embed/n12D4ZrQTDQ?autoplay=1': '<?php echo e(__('phrases.video_name_2')); ?>',
                    'https://www.youtube.com/embed/T3zbViAe3wQ?autoplay=1': '<?php echo e(__('phrases.video_name_3')); ?>',
                    'https://www.youtube.com/embed/LYTFSd_eIuA?autoplay=1': '<?php echo e(__('phrases.video_name_1')); ?>',
                    'https://www.youtube.com/embed/1re3syKVTKQ?autoplay=1': '<?php echo e(__('phrases.video_name_2')); ?>',
                    'https://www.youtube.com/embed/yVWBM5mMcUk?autoplay=1': '<?php echo e(__('phrases.video_name_3')); ?>',
                },
                language: '<?php echo e(app()->getLocale()); ?>'
            }">
        <div class="md:col-span-2">
            <div class="relative rounded-3xl overflow-hidden">
                <img data-src="<?php echo e(asset('images/video-mask.png')); ?>" alt=""
                     class="lazyload w-full max-h-[720px] object-cover object-center rounded-3xl">
                <div class="absolute inset-0 flex items-center justify-center">
                    <button @click="video = true;  videoUrl = (language === 'hy') ? frameHy1 : frameEn1;">
                        <svg width="89" height="88" viewBox="0 0 89 88" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <g clip-path="url(#clip0_1241_5955)">
                                <path
                                    d="M44.5001 -0.00195312C35.7973 -0.00195312 27.29 2.57872 20.0539 7.41372C12.8178 12.2487 7.17793 19.1209 3.84752 27.1612C0.517112 35.2015 -0.354274 44.0489 1.34355 52.5844C3.04138 61.12 7.23217 68.9604 13.386 75.1142C19.5398 81.268 27.3802 85.4588 35.9157 87.1566C44.4513 88.8544 53.2986 87.983 61.3389 84.6526C69.3792 81.3222 76.2514 75.6824 81.0864 68.4463C85.9214 61.2102 88.5021 52.7028 88.5021 44.0001C88.4894 32.3339 83.8494 21.1492 75.6001 12.9C67.3509 4.65079 56.1662 0.0107887 44.5001 -0.00195312ZM44.5001 80.6684C37.2478 80.6684 30.1583 78.5179 24.1282 74.4887C18.0982 70.4595 13.3983 64.7327 10.6229 58.0324C7.84761 51.3322 7.12145 43.9594 8.53631 36.8464C9.95116 29.7335 13.4435 23.1998 18.5716 18.0716C23.6998 12.9435 30.2335 9.45115 37.3464 8.03629C44.4594 6.62143 51.8322 7.34759 58.5325 10.1229C65.2327 12.8983 70.9595 17.5981 74.9887 23.6282C79.0179 29.6583 81.1684 36.7477 81.1684 44.0001C81.1575 53.7218 77.2907 63.0421 70.4165 69.9164C63.5422 76.7907 54.2218 80.6575 44.5001 80.6684Z"
                                    fill="white"/>
                                <path
                                    d="M59.0729 39.1873L42.5091 27.6254C41.6294 27.0119 40.5984 26.6512 39.5281 26.5826C38.4578 26.5139 37.3892 26.74 36.4383 27.2361C35.4874 27.7322 34.6907 28.4794 34.1348 29.3965C33.5788 30.3136 33.2848 31.3656 33.2847 32.4381V55.5621C33.284 56.6349 33.5774 57.6874 34.1333 58.605C34.6891 59.5227 35.4859 60.2703 36.4371 60.7665C37.3882 61.2628 38.4573 61.4886 39.5279 61.4195C40.5985 61.3504 41.6296 60.989 42.5091 60.3746L59.0729 48.8126V48.8097C59.8476 48.269 60.4804 47.5493 60.9173 46.7116C61.3542 45.874 61.5824 44.9432 61.5824 43.9984C61.5824 43.0537 61.3542 42.1229 60.9173 41.2852C60.4804 40.4475 59.8476 39.728 59.0729 39.1873Z"
                                    fill="white"/>
                            </g>
                            <defs>
                                <clipPath id="clip0_1241_5955">
                                    <rect width="88.004" height="88.004" fill="white"
                                          transform="translate(0.498047 -0.00195312)"/>
                                </clipPath>
                            </defs>
                        </svg>
                    </button>
                </div>
                <div class="absolute inset-0" x-cloak x-show="video">
                    <iframe id="video-iframe" width="1280" height="720" title="Ուղեցույց -- Կառուցման վարկեր"
                            frameborder="0"
                            :src="videoUrl" class="w-full h-full lazyload"
                            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
                            referrerpolicy="strict-origin-when-cross-origin" allowfullscreen></iframe>
                </div>
            </div>
            <h2 class="text-xl sm:text-3xl text-black font-semibold mt-5"
                x-text="videoTitles[videoUrl]"><?php echo e(__('phrases.video_name_1')); ?></h2>
        </div>
        <div>
            <div class="relative">
                <img data-src="<?php echo e(asset('images/video-mask.png')); ?>" alt=""
                     class="lazyload w-full max-h-[720px] object-cover object-center rounded-3xl">
                <div class="absolute inset-0 flex items-center justify-center">
                    <button
                        @click="video = true; videoUrl = (language === 'hy') ? (videoUrl === frameHy2 ? frameHy1 : frameHy2) : (videoUrl === frameEn2 ? frameEn1 : frameEn2)">
                        <svg width="89" height="88" viewBox="0 0 89 88" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <g clip-path="url(#clip0_1241_5955)">
                                <path
                                    d="M44.5001 -0.00195312C35.7973 -0.00195312 27.29 2.57872 20.0539 7.41372C12.8178 12.2487 7.17793 19.1209 3.84752 27.1612C0.517112 35.2015 -0.354274 44.0489 1.34355 52.5844C3.04138 61.12 7.23217 68.9604 13.386 75.1142C19.5398 81.268 27.3802 85.4588 35.9157 87.1566C44.4513 88.8544 53.2986 87.983 61.3389 84.6526C69.3792 81.3222 76.2514 75.6824 81.0864 68.4463C85.9214 61.2102 88.5021 52.7028 88.5021 44.0001C88.4894 32.3339 83.8494 21.1492 75.6001 12.9C67.3509 4.65079 56.1662 0.0107887 44.5001 -0.00195312ZM44.5001 80.6684C37.2478 80.6684 30.1583 78.5179 24.1282 74.4887C18.0982 70.4595 13.3983 64.7327 10.6229 58.0324C7.84761 51.3322 7.12145 43.9594 8.53631 36.8464C9.95116 29.7335 13.4435 23.1998 18.5716 18.0716C23.6998 12.9435 30.2335 9.45115 37.3464 8.03629C44.4594 6.62143 51.8322 7.34759 58.5325 10.1229C65.2327 12.8983 70.9595 17.5981 74.9887 23.6282C79.0179 29.6583 81.1684 36.7477 81.1684 44.0001C81.1575 53.7218 77.2907 63.0421 70.4165 69.9164C63.5422 76.7907 54.2218 80.6575 44.5001 80.6684Z"
                                    fill="white"/>
                                <path
                                    d="M59.0729 39.1873L42.5091 27.6254C41.6294 27.0119 40.5984 26.6512 39.5281 26.5826C38.4578 26.5139 37.3892 26.74 36.4383 27.2361C35.4874 27.7322 34.6907 28.4794 34.1348 29.3965C33.5788 30.3136 33.2848 31.3656 33.2847 32.4381V55.5621C33.284 56.6349 33.5774 57.6874 34.1333 58.605C34.6891 59.5227 35.4859 60.2703 36.4371 60.7665C37.3882 61.2628 38.4573 61.4886 39.5279 61.4195C40.5985 61.3504 41.6296 60.989 42.5091 60.3746L59.0729 48.8126V48.8097C59.8476 48.269 60.4804 47.5493 60.9173 46.7116C61.3542 45.874 61.5824 44.9432 61.5824 43.9984C61.5824 43.0537 61.3542 42.1229 60.9173 41.2852C60.4804 40.4475 59.8476 39.728 59.0729 39.1873Z"
                                    fill="white"/>
                            </g>
                            <defs>
                                <clipPath id="clip0_1241_5955">
                                    <rect width="88.004" height="88.004" fill="white"
                                          transform="translate(0.498047 -0.00195312)"/>
                                </clipPath>
                            </defs>
                        </svg>
                    </button>
                </div>
            </div>
            <h2 class="text-xl sm:text-3xl text-black font-semibold mt-5"
                x-text="(videoUrl === frameHy2 && language === 'hy') ? '<?php echo e(__('phrases.video_name_1')); ?>' : (videoUrl === frameEn2 && language === 'en') ? '<?php echo e(__('phrases.video_name_1')); ?>' : '<?php echo e(__('phrases.video_name_2')); ?>'"></h2>
        </div>

        <div>
            <div class="relative">
                <img data-src="<?php echo e(asset('images/video-mask.png')); ?>" alt=""
                     class="lazyload w-full max-h-[720px] object-cover object-center rounded-3xl">
                <div class="absolute inset-0 flex items-center justify-center">
                    <button
                        @click="video = true; videoUrl = (language === 'hy') ? (videoUrl === frameHy3 ? frameHy1 : frameHy3) : (videoUrl === frameEn3 ? frameEn1 : frameEn3);">
                        <svg width="89" height="88" viewBox="0 0 89 88" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <g clip-path="url(#clip0_1241_5955)">
                                <path
                                    d="M44.5001 -0.00195312C35.7973 -0.00195312 27.29 2.57872 20.0539 7.41372C12.8178 12.2487 7.17793 19.1209 3.84752 27.1612C0.517112 35.2015 -0.354274 44.0489 1.34355 52.5844C3.04138 61.12 7.23217 68.9604 13.386 75.1142C19.5398 81.268 27.3802 85.4588 35.9157 87.1566C44.4513 88.8544 53.2986 87.983 61.3389 84.6526C69.3792 81.3222 76.2514 75.6824 81.0864 68.4463C85.9214 61.2102 88.5021 52.7028 88.5021 44.0001C88.4894 32.3339 83.8494 21.1492 75.6001 12.9C67.3509 4.65079 56.1662 0.0107887 44.5001 -0.00195312ZM44.5001 80.6684C37.2478 80.6684 30.1583 78.5179 24.1282 74.4887C18.0982 70.4595 13.3983 64.7327 10.6229 58.0324C7.84761 51.3322 7.12145 43.9594 8.53631 36.8464C9.95116 29.7335 13.4435 23.1998 18.5716 18.0716C23.6998 12.9435 30.2335 9.45115 37.3464 8.03629C44.4594 6.62143 51.8322 7.34759 58.5325 10.1229C65.2327 12.8983 70.9595 17.5981 74.9887 23.6282C79.0179 29.6583 81.1684 36.7477 81.1684 44.0001C81.1575 53.7218 77.2907 63.0421 70.4165 69.9164C63.5422 76.7907 54.2218 80.6575 44.5001 80.6684Z"
                                    fill="white"/>
                                <path
                                    d="M59.0729 39.1873L42.5091 27.6254C41.6294 27.0119 40.5984 26.6512 39.5281 26.5826C38.4578 26.5139 37.3892 26.74 36.4383 27.2361C35.4874 27.7322 34.6907 28.4794 34.1348 29.3965C33.5788 30.3136 33.2848 31.3656 33.2847 32.4381V55.5621C33.284 56.6349 33.5774 57.6874 34.1333 58.605C34.6891 59.5227 35.4859 60.2703 36.4371 60.7665C37.3882 61.2628 38.4573 61.4886 39.5279 61.4195C40.5985 61.3504 41.6296 60.989 42.5091 60.3746L59.0729 48.8126V48.8097C59.8476 48.269 60.4804 47.5493 60.9173 46.7116C61.3542 45.874 61.5824 44.9432 61.5824 43.9984C61.5824 43.0537 61.3542 42.1229 60.9173 41.2852C60.4804 40.4475 59.8476 39.728 59.0729 39.1873Z"
                                    fill="white"/>
                            </g>
                            <defs>
                                <clipPath id="clip0_1241_5955">
                                    <rect width="88.004" height="88.004" fill="white"
                                          transform="translate(0.498047 -0.00195312)"/>
                                </clipPath>
                            </defs>
                        </svg>
                    </button>
                </div>
            </div>
            <h2 class="text-xl sm:text-3xl text-black font-semibold mt-5"
                x-text="(videoUrl === frameHy3 && language === 'hy') ? '<?php echo e(__('phrases.video_name_1')); ?>' : (videoUrl === frameEn3 && language === 'en') ? '<?php echo e(__('phrases.video_name_1')); ?>' : '<?php echo e(__('phrases.video_name_3')); ?>'"></h2>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalea110a4dc9a05234d27a64f8ec54bbc6)): ?>
<?php $attributes = $__attributesOriginalea110a4dc9a05234d27a64f8ec54bbc6; ?>
<?php unset($__attributesOriginalea110a4dc9a05234d27a64f8ec54bbc6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalea110a4dc9a05234d27a64f8ec54bbc6)): ?>
<?php $component = $__componentOriginalea110a4dc9a05234d27a64f8ec54bbc6; ?>
<?php unset($__componentOriginalea110a4dc9a05234d27a64f8ec54bbc6); ?>
<?php endif; ?><?php /**PATH /home/vagrant/projects/eco-calc/resources/views/front/video-modal.blade.php ENDPATH**/ ?>